/**
 * Property-based tests for Tetromino class
 * Using fast-check for property testing
 */

import fc from 'fast-check';
import { Tetromino, TETROMINO_DEFINITIONS } from '../../src/core/Tetromino.js';

describe('Tetromino Property Tests', () => {
    /**
     * **Feature: tetris-game, Property 1: 方块水平移动**
     * **Validates: Requirements 1.1, 1.2**
     * 
     * For any game state and valid horizontal movement direction, the movement operation should move the active block 
     * one space in that direction, unless collision occurs
     */
    describe('Property 1: Block Horizontal Movement', () => {
        test('should move blocks horizontally by exactly one unit', () => {
            fc.assert(
                fc.property(
                    fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
                    fc.integer({ min: -50, max: 50 }), // x position
                    fc.integer({ min: -50, max: 50 }), // y position
                    fc.integer({ min: 0, max: 3 }),    // rotation
                    fc.constantFrom(-1, 1),            // direction (-1 for left, 1 for right)
                    (type, x, y, rotation, direction) => {
                        const original = new Tetromino(type, x, y, rotation);
                        const moved = original.move(direction, 0);
                        
                        // Position should change by exactly the direction amount
                        expect(moved.x).toBe(original.x + direction);
                        expect(moved.y).toBe(original.y); // Y should not change
                        
                        // Other properties should remain unchanged
                        expect(moved.type).toBe(original.type);
                        expect(moved.rotation).toBe(original.rotation);
                        expect(moved.getColor()).toBe(original.getColor());
                        
                        // Should be a new instance
                        expect(moved).not.toBe(original);
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should preserve block shape and properties during horizontal movement', () => {
            fc.assert(
                fc.property(
                    fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
                    fc.integer({ min: 0, max: 10 }),
                    fc.integer({ min: 0, max: 10 }),
                    fc.integer({ min: 0, max: 3 }),
                    (type, x, y, rotation) => {
                        const original = new Tetromino(type, x, y, rotation);
                        const movedLeft = original.moveLeft();
                        const movedRight = original.moveRight();
                        
                        // Shape should be identical
                        expect(movedLeft.getShape()).toEqual(original.getShape());
                        expect(movedRight.getShape()).toEqual(original.getShape());
                        
                        // Block count should be the same
                        expect(movedLeft.getBlocks().length).toBe(original.getBlocks().length);
                        expect(movedRight.getBlocks().length).toBe(original.getBlocks().length);
                        
                        // Color and type should be preserved
                        expect(movedLeft.getColor()).toBe(original.getColor());
                        expect(movedRight.getColor()).toBe(original.getColor());
                        expect(movedLeft.type).toBe(original.type);
                        expect(movedRight.type).toBe(original.type);
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should maintain relative block positions during horizontal movement', () => {
            fc.assert(
                fc.property(
                    fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
                    fc.integer({ min: 5, max: 15 }),
                    fc.integer({ min: 5, max: 15 }),
                    fc.integer({ min: 0, max: 3 }),
                    (type, x, y, rotation) => {
                        const original = new Tetromino(type, x, y, rotation);
                        const moved = original.moveLeft();
                        
                        const originalBlocks = original.getBlocks();
                        const movedBlocks = moved.getBlocks();
                        
                        // Should have same number of blocks
                        expect(movedBlocks.length).toBe(originalBlocks.length);
                        
                        // Each block should be shifted by exactly -1 in x direction
                        for (let i = 0; i < originalBlocks.length; i++) {
                            expect(movedBlocks[i].x).toBe(originalBlocks[i].x - 1);
                            expect(movedBlocks[i].y).toBe(originalBlocks[i].y);
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });
    });

    /**
     * **Feature: tetris-game, Property 2: 方块旋转**
     * **Validates: Requirements 1.4**
     * 
     * For any active block and rotation direction, the rotation operation should transform the block 
     * to the next rotation state, unless collision occurs
     */
    describe('Property 2: Block Rotation', () => {
        test('should advance rotation state correctly', () => {
            fc.assert(
                fc.property(
                    fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
                    fc.integer({ min: 0, max: 10 }),
                    fc.integer({ min: 0, max: 10 }),
                    fc.integer({ min: 0, max: 3 }),
                    (type, x, y, rotation) => {
                        const original = new Tetromino(type, x, y, rotation);
                        const rotatedCW = original.rotate();
                        const rotatedCCW = original.rotateCounterClockwise();
                        
                        // Clockwise rotation should advance rotation state
                        const expectedCW = (rotation + 1) % 4;
                        expect(rotatedCW.rotation).toBe(expectedCW);
                        
                        // Counter-clockwise rotation should go back
                        const expectedCCW = (rotation + 3) % 4; // equivalent to -1 mod 4
                        expect(rotatedCCW.rotation).toBe(expectedCCW);
                        
                        // Position should remain the same
                        expect(rotatedCW.x).toBe(original.x);
                        expect(rotatedCW.y).toBe(original.y);
                        expect(rotatedCCW.x).toBe(original.x);
                        expect(rotatedCCW.y).toBe(original.y);
                        
                        // Type and color should be preserved
                        expect(rotatedCW.type).toBe(original.type);
                        expect(rotatedCCW.type).toBe(original.type);
                        expect(rotatedCW.getColor()).toBe(original.getColor());
                        expect(rotatedCCW.getColor()).toBe(original.getColor());
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should maintain block count during rotation', () => {
            fc.assert(
                fc.property(
                    fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
                    fc.integer({ min: 0, max: 10 }),
                    fc.integer({ min: 0, max: 10 }),
                    fc.integer({ min: 0, max: 3 }),
                    (type, x, y, rotation) => {
                        const original = new Tetromino(type, x, y, rotation);
                        const rotated = original.rotate();
                        
                        // Block count should remain the same
                        expect(rotated.getBlocks().length).toBe(original.getBlocks().length);
                        
                        // Should always have 4 blocks (tetromino property)
                        expect(rotated.getBlocks().length).toBe(4);
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should cycle through all rotation states correctly', () => {
            fc.assert(
                fc.property(
                    fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
                    fc.integer({ min: 0, max: 10 }),
                    fc.integer({ min: 0, max: 10 }),
                    (type, x, y) => {
                        const original = new Tetromino(type, x, y, 0);
                        
                        // Rotate 4 times clockwise should return to original state
                        let current = original;
                        for (let i = 0; i < 4; i++) {
                            current = current.rotate();
                        }
                        
                        expect(current.rotation).toBe(original.rotation);
                        expect(current.getShape()).toEqual(original.getShape());
                        
                        // Same test for counter-clockwise
                        current = original;
                        for (let i = 0; i < 4; i++) {
                            current = current.rotateCounterClockwise();
                        }
                        
                        expect(current.rotation).toBe(original.rotation);
                        expect(current.getShape()).toEqual(original.getShape());
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should have valid shape data for all rotation states', () => {
            fc.assert(
                fc.property(
                    fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
                    fc.integer({ min: 0, max: 10 }),
                    fc.integer({ min: 0, max: 10 }),
                    (type, x, y) => {
                        const tetromino = new Tetromino(type, x, y, 0);
                        
                        // Test all 4 rotation states
                        for (let rotation = 0; rotation < 4; rotation++) {
                            const rotated = new Tetromino(type, x, y, rotation);
                            const shape = rotated.getShape();
                            
                            // Shape should be 4x4 matrix
                            expect(shape.length).toBe(4);
                            expect(shape[0].length).toBe(4);
                            
                            // Should have exactly 4 filled blocks
                            let blockCount = 0;
                            for (let row = 0; row < 4; row++) {
                                for (let col = 0; col < 4; col++) {
                                    if (shape[row][col] === 1) {
                                        blockCount++;
                                    }
                                }
                            }
                            expect(blockCount).toBe(4);
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });
    });

    /**
     * **Feature: tetris-game, Property 12: 旋转规则正确性**
     * **Validates: Requirements 4.3**
     * 
     * For any block type and rotation operation, the system should change the shape according to 
     * the standard rotation rules for that type
     */
    describe('Property 12: Rotation Rules Correctness', () => {
        test('should follow defined rotation shapes for each type', () => {
            fc.assert(
                fc.property(
                    fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
                    fc.integer({ min: 0, max: 10 }),
                    fc.integer({ min: 0, max: 10 }),
                    fc.integer({ min: 0, max: 3 }),
                    (type, x, y, rotation) => {
                        const tetromino = new Tetromino(type, x, y, rotation);
                        const shape = tetromino.getShape();
                        
                        // Shape should match the defined shape for this type and rotation
                        const expectedShape = TETROMINO_DEFINITIONS[type].shapes[rotation];
                        expect(shape).toEqual(expectedShape);
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should use correct shape after rotation', () => {
            fc.assert(
                fc.property(
                    fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
                    fc.integer({ min: 0, max: 10 }),
                    fc.integer({ min: 0, max: 10 }),
                    fc.integer({ min: 0, max: 3 }),
                    (type, x, y, startRotation) => {
                        const original = new Tetromino(type, x, y, startRotation);
                        const rotated = original.rotate();
                        
                        const expectedRotation = (startRotation + 1) % 4;
                        const expectedShape = TETROMINO_DEFINITIONS[type].shapes[expectedRotation];
                        
                        expect(rotated.getShape()).toEqual(expectedShape);
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should maintain type-specific properties during rotation', () => {
            fc.assert(
                fc.property(
                    fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
                    fc.integer({ min: 0, max: 10 }),
                    fc.integer({ min: 0, max: 10 }),
                    (type, x, y) => {
                        const tetromino = new Tetromino(type, x, y, 0);
                        
                        // Test all rotations maintain type-specific properties
                        let current = tetromino;
                        for (let i = 0; i < 4; i++) {
                            // Should always reference the correct definition
                            expect(current.definition).toBe(TETROMINO_DEFINITIONS[type]);
                            
                            // Should have the correct kick data
                            expect(current.getKickData()).toBe(TETROMINO_DEFINITIONS[type].kickData);
                            
                            current = current.rotate();
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should have distinct shapes for different rotation states (except O piece)', () => {
            fc.assert(
                fc.property(
                    fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS).filter(t => t !== 'O')),
                    fc.integer({ min: 0, max: 10 }),
                    fc.integer({ min: 0, max: 10 }),
                    (type, x, y) => {
                        const shapes = [];
                        for (let rotation = 0; rotation < 4; rotation++) {
                            const tetromino = new Tetromino(type, x, y, rotation);
                            shapes.push(JSON.stringify(tetromino.getShape()));
                        }
                        
                        // For non-O pieces, at least some rotations should be different
                        // (I piece has 2 unique states, others have 4 or 2)
                        const uniqueShapes = new Set(shapes);
                        expect(uniqueShapes.size).toBeGreaterThan(1);
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('O piece should have identical shapes for all rotations', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 0, max: 10 }),
                    fc.integer({ min: 0, max: 10 }),
                    (x, y) => {
                        const shapes = [];
                        for (let rotation = 0; rotation < 4; rotation++) {
                            const tetromino = new Tetromino('O', x, y, rotation);
                            shapes.push(JSON.stringify(tetromino.getShape()));
                        }
                        
                        // O piece should have identical shapes for all rotations
                        const uniqueShapes = new Set(shapes);
                        expect(uniqueShapes.size).toBe(1);
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });
    });

    /**
     * **Feature: tetris-game, Property 11: 方块属性一致性**
     * **Validates: Requirements 4.2, 4.4**
     * 
     * For any block operation (movement, rotation), the block's type and color should remain unchanged
     */
    describe('Property 11: Block Attribute Consistency', () => {
        test('should preserve type and color during all operations', () => {
            fc.assert(
                fc.property(
                    fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
                    fc.integer({ min: -10, max: 10 }),
                    fc.integer({ min: -10, max: 10 }),
                    fc.integer({ min: 0, max: 3 }),
                    fc.integer({ min: -5, max: 5 }),
                    fc.integer({ min: -5, max: 5 }),
                    (type, x, y, rotation, dx, dy) => {
                        const original = new Tetromino(type, x, y, rotation);
                        const originalColor = original.getColor();
                        const originalType = original.type;
                        
                        // Test movement operations
                        const moved = original.move(dx, dy);
                        expect(moved.type).toBe(originalType);
                        expect(moved.getColor()).toBe(originalColor);
                        expect(moved.getName()).toBe(originalType);
                        
                        // Test specific movement methods
                        const movedLeft = original.moveLeft();
                        const movedRight = original.moveRight();
                        const movedDown = original.moveDown();
                        
                        expect(movedLeft.type).toBe(originalType);
                        expect(movedLeft.getColor()).toBe(originalColor);
                        expect(movedRight.type).toBe(originalType);
                        expect(movedRight.getColor()).toBe(originalColor);
                        expect(movedDown.type).toBe(originalType);
                        expect(movedDown.getColor()).toBe(originalColor);
                        
                        // Test rotation operations
                        const rotatedCW = original.rotate();
                        const rotatedCCW = original.rotateCounterClockwise();
                        
                        expect(rotatedCW.type).toBe(originalType);
                        expect(rotatedCW.getColor()).toBe(originalColor);
                        expect(rotatedCCW.type).toBe(originalType);
                        expect(rotatedCCW.getColor()).toBe(originalColor);
                        
                        // Test clone operation
                        const cloned = original.clone();
                        expect(cloned.type).toBe(originalType);
                        expect(cloned.getColor()).toBe(originalColor);
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should maintain consistent color mapping for each type', () => {
            fc.assert(
                fc.property(
                    fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
                    fc.integer({ min: 0, max: 10 }),
                    fc.integer({ min: 0, max: 10 }),
                    fc.integer({ min: 0, max: 3 }),
                    (type, x, y, rotation) => {
                        const tetromino = new Tetromino(type, x, y, rotation);
                        const expectedColor = TETROMINO_DEFINITIONS[type].color;
                        
                        expect(tetromino.getColor()).toBe(expectedColor);
                        
                        // Color should be consistent across all operations
                        const operations = [
                            tetromino.move(1, 0),
                            tetromino.move(-1, 0),
                            tetromino.move(0, 1),
                            tetromino.rotate(),
                            tetromino.rotateCounterClockwise(),
                            tetromino.clone()
                        ];
                        
                        operations.forEach(op => {
                            expect(op.getColor()).toBe(expectedColor);
                        });
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should maintain type-specific definition reference', () => {
            fc.assert(
                fc.property(
                    fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
                    fc.integer({ min: 0, max: 10 }),
                    fc.integer({ min: 0, max: 10 }),
                    (type, x, y) => {
                        const tetromino = new Tetromino(type, x, y, 0);
                        const expectedDefinition = TETROMINO_DEFINITIONS[type];
                        
                        // Should always reference the correct definition
                        expect(tetromino.definition).toBe(expectedDefinition);
                        
                        // Test through multiple operations
                        let current = tetromino;
                        for (let i = 0; i < 10; i++) {
                            current = current.move(1, 1).rotate();
                            expect(current.definition).toBe(expectedDefinition);
                            expect(current.type).toBe(type);
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should preserve immutability - operations create new instances', () => {
            fc.assert(
                fc.property(
                    fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
                    fc.integer({ min: 0, max: 10 }),
                    fc.integer({ min: 0, max: 10 }),
                    fc.integer({ min: 0, max: 3 }),
                    (type, x, y, rotation) => {
                        const original = new Tetromino(type, x, y, rotation);
                        
                        // All operations should create new instances
                        const moved = original.move(1, 0);
                        const rotated = original.rotate();
                        const cloned = original.clone();
                        
                        expect(moved).not.toBe(original);
                        expect(rotated).not.toBe(original);
                        expect(cloned).not.toBe(original);
                        
                        // Original should be unchanged
                        expect(original.x).toBe(x);
                        expect(original.y).toBe(y);
                        expect(original.rotation).toBe(rotation);
                        expect(original.type).toBe(type);
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should maintain consistent block count for each type', () => {
            fc.assert(
                fc.property(
                    fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
                    fc.integer({ min: 0, max: 10 }),
                    fc.integer({ min: 0, max: 10 }),
                    (type, x, y) => {
                        const tetromino = new Tetromino(type, x, y, 0);
                        
                        // All tetrominoes should have exactly 4 blocks
                        expect(tetromino.getBlocks().length).toBe(4);
                        
                        // This should remain consistent through all operations
                        const operations = [
                            tetromino.move(2, 3),
                            tetromino.rotate(),
                            tetromino.rotateCounterClockwise(),
                            tetromino.moveLeft(),
                            tetromino.moveRight(),
                            tetromino.moveDown()
                        ];
                        
                        operations.forEach(op => {
                            expect(op.getBlocks().length).toBe(4);
                        });
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });
    });

    /**
     * **Feature: tetris-game, Property 10: 方块类型随机性和有效性**
     * **Validates: Requirements 4.1**
     * 
     * For any new tetromino generation, the system should randomly select one of the seven valid Tetromino types
     */
    describe('Property 10: Tetromino Type Randomness and Validity', () => {
        test('should always generate valid tetromino types', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 0, max: 100 }), // x position
                    fc.integer({ min: 0, max: 100 }), // y position
                    (x, y) => {
                        const tetromino = Tetromino.createRandom(x, y);
                        
                        // The generated tetromino should be a valid instance
                        expect(tetromino).toBeInstanceOf(Tetromino);
                        
                        // The type should be one of the seven valid types
                        const validTypes = Object.keys(TETROMINO_DEFINITIONS);
                        expect(validTypes).toContain(tetromino.type);
                        
                        // Position should be preserved
                        expect(tetromino.x).toBe(x);
                        expect(tetromino.y).toBe(y);
                        
                        // Should have valid properties
                        expect(tetromino.getColor()).toBeTruthy();
                        expect(tetromino.getName()).toBeTruthy();
                        expect(tetromino.getShape()).toBeTruthy();
                        expect(Array.isArray(tetromino.getBlocks())).toBe(true);
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should generate all seven types over multiple runs', () => {
            const generatedTypes = new Set();
            const validTypes = Object.keys(TETROMINO_DEFINITIONS);
            
            // Generate many tetrominoes to ensure we see all types
            for (let i = 0; i < 1000; i++) {
                const tetromino = Tetromino.createRandom();
                generatedTypes.add(tetromino.type);
            }
            
            // We should have seen all seven types
            expect(generatedTypes.size).toBe(7);
            validTypes.forEach(type => {
                expect(generatedTypes.has(type)).toBe(true);
            });
        });

        test('should maintain type consistency after creation', () => {
            fc.assert(
                fc.property(
                    fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
                    fc.integer({ min: -10, max: 10 }),
                    fc.integer({ min: -10, max: 10 }),
                    fc.integer({ min: 0, max: 3 }),
                    (type, x, y, rotation) => {
                        const tetromino = new Tetromino(type, x, y, rotation);
                        
                        // Type should remain consistent
                        expect(tetromino.type).toBe(type);
                        expect(tetromino.getName()).toBe(type);
                        
                        // Should have the correct definition
                        expect(tetromino.definition).toBe(TETROMINO_DEFINITIONS[type]);
                        expect(tetromino.getColor()).toBe(TETROMINO_DEFINITIONS[type].color);
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });
    });
});