/**
 * Property-based tests for line clearing functionality
 * **Feature: tetris-game, Property 7: 完整行消除**
 * **Validates: Requirements 3.1, 3.2**
 */

import fc from 'fast-check';
import { GameBoard } from '../../src/core/GameBoard.js';
import { Tetromino, TETROMINO_DEFINITIONS } from '../../src/core/Tetromino.js';

describe('Line Clear Properties', () => {
    /**
     * **Feature: tetris-game, Property 7: 完整行消除**
     * For any game board containing complete lines, the system should remove
     * all complete lines and move upper lines down to fill gaps
     */
    test('complete line removal and gap filling', () => {
        fc.assert(fc.property(
            // Generate random board state with some complete lines
            fc.array(fc.array(fc.constantFrom(0, '#FF0000', '#00FF00', '#0000FF'), { minLength: 10, maxLength: 10 }), { minLength: 20, maxLength: 20 }),
            (boardData) => {
                const gameBoard = new GameBoard();
                
                // Set up the board with the generated data
                for (let y = 0; y < 20; y++) {
                    for (let x = 0; x < 10; x++) {
                        gameBoard.setCell(x, y, boardData[y][x]);
                    }
                }
                
                // Record initial state
                const initialBoard = gameBoard.getBoard();
                const initialCompletedLines = gameBoard.getCompletedLines();
                const initialHeight = gameBoard.height;
                
                // Perform line clearing
                const linesCleared = gameBoard.clearLines();
                const finalBoard = gameBoard.getBoard();
                
                // Property 1: Number of lines cleared should match initial complete lines
                expect(linesCleared).toBe(initialCompletedLines.length);
                
                // Property 2: Board height should remain the same
                expect(finalBoard.length).toBe(initialHeight);
                
                // Property 3: No complete lines should remain after clearing
                expect(gameBoard.getCompletedLines().length).toBe(0);
                
                // Property 4: Total number of non-empty cells should decrease by (lines cleared * width)
                const initialNonEmptyCells = initialBoard.flat().filter(cell => cell !== 0).length;
                const finalNonEmptyCells = finalBoard.flat().filter(cell => cell !== 0).length;
                const expectedDecrease = linesCleared * gameBoard.width;
                expect(initialNonEmptyCells - finalNonEmptyCells).toBe(expectedDecrease);
                
                // Property 5: Top rows should be empty after clearing
                for (let y = 0; y < linesCleared; y++) {
                    for (let x = 0; x < gameBoard.width; x++) {
                        expect(finalBoard[y][x]).toBe(0);
                    }
                }
            }
        ), { numRuns: 100 });
    });

    /**
     * Test that line clearing preserves non-complete lines in correct order
     */
    test('line clearing preserves non-complete lines order', () => {
        fc.assert(fc.property(
            fc.integer({ min: 0, max: 19 }),
            fc.integer({ min: 0, max: 19 }),
            (line1, line2) => {
                const gameBoard = new GameBoard();
                
                // Create a pattern where we can track line order
                const pattern1 = '#FF0000';
                const pattern2 = '#00FF00';
                
                // Fill two non-complete lines with distinct patterns
                for (let x = 0; x < 9; x++) { // Leave one cell empty to make it non-complete
                    gameBoard.setCell(x, line1, pattern1);
                    gameBoard.setCell(x, line2, pattern2);
                }
                
                // Add a complete line between them if possible
                const middleLine = Math.floor((line1 + line2) / 2);
                if (middleLine !== line1 && middleLine !== line2) {
                    for (let x = 0; x < 10; x++) {
                        gameBoard.setCell(x, middleLine, '#0000FF');
                    }
                }
                
                const initialBoard = gameBoard.getBoard();
                gameBoard.clearLines();
                const finalBoard = gameBoard.getBoard();
                
                // Find the patterns in the final board
                let pattern1Row = -1;
                let pattern2Row = -1;
                
                for (let y = 0; y < gameBoard.height; y++) {
                    let pattern1Count = 0;
                    let pattern2Count = 0;
                    
                    for (let x = 0; x < gameBoard.width; x++) {
                        if (finalBoard[y][x] === pattern1) pattern1Count++;
                        if (finalBoard[y][x] === pattern2) pattern2Count++;
                    }
                    
                    if (pattern1Count === 9) pattern1Row = y;
                    if (pattern2Count === 9) pattern2Row = y;
                }
                
                // Property: If both patterns exist, their relative order should be preserved
                if (pattern1Row !== -1 && pattern2Row !== -1) {
                    if (line1 < line2) {
                        expect(pattern1Row).toBeLessThan(pattern2Row);
                    } else if (line1 > line2) {
                        expect(pattern1Row).toBeGreaterThan(pattern2Row);
                    }
                }
            }
        ), { numRuns: 100 });
    });

    /**
     * Test multiple simultaneous line clears
     */
    test('multiple simultaneous line clearing', () => {
        fc.assert(fc.property(
            fc.array(fc.integer({ min: 0, max: 19 }), { minLength: 1, maxLength: 4 }),
            (lineIndices) => {
                const gameBoard = new GameBoard();
                const uniqueLines = [...new Set(lineIndices)].sort((a, b) => a - b);
                
                // Fill the specified lines completely
                for (const lineIndex of uniqueLines) {
                    for (let x = 0; x < 10; x++) {
                        gameBoard.setCell(x, lineIndex, '#FF0000');
                    }
                }
                
                // Add some partial lines to test they're preserved
                const partialLine = uniqueLines[uniqueLines.length - 1] + 1;
                if (partialLine < 20) {
                    for (let x = 0; x < 5; x++) {
                        gameBoard.setCell(x, partialLine, '#00FF00');
                    }
                }
                
                const linesCleared = gameBoard.clearLines();
                
                // Property: Should clear exactly the number of complete lines
                expect(linesCleared).toBe(uniqueLines.length);
                
                // Property: No complete lines should remain
                expect(gameBoard.getCompletedLines().length).toBe(0);
                
                // Property: Partial lines should still exist
                if (partialLine < 20) {
                    let foundPartialLine = false;
                    for (let y = 0; y < gameBoard.height; y++) {
                        let greenCount = 0;
                        for (let x = 0; x < gameBoard.width; x++) {
                            if (gameBoard.getCell(x, y) === '#00FF00') {
                                greenCount++;
                            }
                        }
                        if (greenCount === 5) {
                            foundPartialLine = true;
                            break;
                        }
                    }
                    expect(foundPartialLine).toBe(true);
                }
            }
        ), { numRuns: 100 });
    });

    /**
     * Test line clearing simulation doesn't modify original board
     */
    test('line clearing simulation is non-destructive', () => {
        fc.assert(fc.property(
            fc.array(fc.array(fc.constantFrom(0, '#FF0000', '#00FF00'), { minLength: 10, maxLength: 10 }), { minLength: 20, maxLength: 20 }),
            (boardData) => {
                const gameBoard = new GameBoard();
                
                // Set up the board
                for (let y = 0; y < 20; y++) {
                    for (let x = 0; x < 10; x++) {
                        gameBoard.setCell(x, y, boardData[y][x]);
                    }
                }
                
                const originalBoard = gameBoard.getBoard();
                const simulation = gameBoard.simulateLineClear();
                const boardAfterSimulation = gameBoard.getBoard();
                
                // Property: Original board should be unchanged after simulation
                expect(boardAfterSimulation).toEqual(originalBoard);
                
                // Property: Simulation should predict actual clearing result
                const actualLinesCleared = gameBoard.clearLines();
                expect(simulation.linesCleared).toBe(actualLinesCleared);
            }
        ), { numRuns: 100 });
    });

    /**
     * Test that empty boards don't clear any lines
     */
    test('empty board line clearing', () => {
        fc.assert(fc.property(
            fc.constant(null), // Just a placeholder to run the test
            () => {
                const gameBoard = new GameBoard();
                
                const linesCleared = gameBoard.clearLines();
                const completedLines = gameBoard.getCompletedLines();
                
                // Property: Empty board should have no lines to clear
                expect(linesCleared).toBe(0);
                expect(completedLines.length).toBe(0);
                expect(gameBoard.hasCompletedLines()).toBe(false);
                
                // Property: Board should remain empty
                const board = gameBoard.getBoard();
                for (let y = 0; y < gameBoard.height; y++) {
                    for (let x = 0; x < gameBoard.width; x++) {
                        expect(board[y][x]).toBe(0);
                    }
                }
            }
        ), { numRuns: 10 });
    });

    /**
     * Test line fill count accuracy
     */
    test('line fill count accuracy', () => {
        fc.assert(fc.property(
            fc.integer({ min: 0, max: 19 }),
            fc.array(fc.constantFrom(0, '#FF0000'), { minLength: 10, maxLength: 10 }),
            (lineIndex, lineData) => {
                const gameBoard = new GameBoard();
                
                // Set up the line
                for (let x = 0; x < 10; x++) {
                    gameBoard.setCell(x, lineIndex, lineData[x]);
                }
                
                const fillCount = gameBoard.getLineFillCount(lineIndex);
                const expectedCount = lineData.filter(cell => cell !== 0).length;
                
                // Property: Fill count should match actual non-zero cells
                expect(fillCount).toBe(expectedCount);
                
                // Property: Line is complete if and only if fill count equals width
                const isComplete = gameBoard.isLineComplete(lineIndex);
                expect(isComplete).toBe(fillCount === gameBoard.width);
            }
        ), { numRuns: 100 });
    });
});