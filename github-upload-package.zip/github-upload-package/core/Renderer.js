/**
 * Renderer class for drawing the Tetris game using HTML5 Canvas
 * Handles all visual rendering including game board, tetrominoes, and UI elements
 */

export class Renderer {
    /**
     * Create a new Renderer
     * @param {HTMLCanvasElement} canvas - The main game canvas
     * @param {HTMLCanvasElement} nextPieceCanvas - Canvas for next piece preview
     * @param {Object} config - Game configuration
     */
    constructor(canvas, nextPieceCanvas, config) {
        this.canvas = canvas;
        this.ctx = canvas ? canvas.getContext('2d') : null;
        this.nextPieceCanvas = nextPieceCanvas;
        this.nextPieceCtx = nextPieceCanvas ? nextPieceCanvas.getContext('2d') : null;
        this.config = config;
        
        // Calculate cell size based on canvas dimensions and board size
        this.cellSize = canvas ? Math.min(
            canvas.width / config.boardWidth,
            canvas.height / config.boardHeight
        ) : 20; // Default cell size for testing
        
        // Grid styling
        this.gridColor = '#333333';
        this.borderColor = '#666666';
        this.backgroundColor = '#000000';
        
        // Animation state
        this.animations = [];
        this.effects = [];
        
        // Performance optimization flags
        this.needsRedraw = true;
        this.lastRenderTime = 0;
        this.renderThrottle = 16; // ~60 FPS
        this.dirtyRegions = [];
        
        // Cached rendering data
        this.cachedBoard = null;
        this.cachedBoardHash = null;
        
        // Initialize canvas settings
        this.initializeCanvas();
    }

    /**
     * Initialize canvas settings and properties
     */
    initializeCanvas() {
        if (!this.ctx || !this.canvas) {
            return;
        }
        
        // Set canvas background
        this.ctx.fillStyle = this.backgroundColor;
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Enable crisp pixel rendering
        this.ctx.imageSmoothingEnabled = false;
        if (this.nextPieceCtx) {
            this.nextPieceCtx.imageSmoothingEnabled = false;
            this.nextPieceCtx.lineWidth = 1;
        }
        
        // Set default line width for grid
        this.ctx.lineWidth = 1;
    }

    /**
     * Clear the entire canvas
     */
    clear() {
        if (!this.ctx || !this.canvas) {
            return;
        }
        this.ctx.fillStyle = this.backgroundColor;
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    }

    /**
     * Clear the next piece canvas
     */
    clearNextPiece() {
        if (!this.nextPieceCtx || !this.nextPieceCanvas) {
            return;
        }
        this.nextPieceCtx.fillStyle = this.backgroundColor;
        this.nextPieceCtx.fillRect(0, 0, this.nextPieceCanvas.width, this.nextPieceCanvas.height);
    }

    /**
     * Draw the game board grid and placed pieces
     * @param {GameBoard} gameBoard - The game board to render
     */
    drawBoard(gameBoard) {
        const board = gameBoard.getBoard();
        
        // Draw placed pieces
        for (let y = 0; y < board.length; y++) {
            for (let x = 0; x < board[y].length; x++) {
                const cell = board[y][x];
                if (cell !== 0) {
                    this.drawCell(x, y, cell);
                }
            }
        }
        
        // Draw grid lines
        this.drawGrid(gameBoard.width, gameBoard.height);
    }

    /**
     * Draw a single cell with the specified color
     * @param {number} x - Grid x coordinate
     * @param {number} y - Grid y coordinate
     * @param {string} color - Cell color (hex string)
     * @param {number} alpha - Opacity (0-1, default 1)
     */
    drawCell(x, y, color, alpha = 1) {
        if (!this.ctx) {
            return;
        }
        
        const pixelX = x * this.cellSize;
        const pixelY = y * this.cellSize;
        
        // Save current context state
        this.ctx.save();
        
        // Set alpha if specified
        if (alpha < 1) {
            this.ctx.globalAlpha = alpha;
        }
        
        // Fill the cell with the main color
        this.ctx.fillStyle = color;
        this.ctx.fillRect(pixelX, pixelY, this.cellSize, this.cellSize);
        
        // Add a subtle border for better visual separation
        this.ctx.strokeStyle = this.darkenColor(color, 0.3);
        this.ctx.lineWidth = 1;
        this.ctx.strokeRect(pixelX + 0.5, pixelY + 0.5, this.cellSize - 1, this.cellSize - 1);
        
        // Add a highlight for 3D effect
        this.ctx.fillStyle = this.lightenColor(color, 0.2);
        this.ctx.fillRect(pixelX + 1, pixelY + 1, this.cellSize - 2, 2);
        this.ctx.fillRect(pixelX + 1, pixelY + 1, 2, this.cellSize - 2);
        
        // Restore context state
        this.ctx.restore();
    }

    /**
     * Draw a tetromino at its current position
     * @param {Tetromino} tetromino - The tetromino to draw
     * @param {number} alpha - Opacity (0-1, default 1)
     */
    drawTetromino(tetromino, alpha = 1) {
        if (!tetromino) return;
        
        console.log('🎨 Drawing tetromino:', tetromino.type, 'at', `(${tetromino.x},${tetromino.y})`);
        
        const blocks = tetromino.getBlocks();
        const color = tetromino.getColor();
        
        console.log('🎨 Tetromino blocks:', blocks);
        console.log('🎨 Tetromino color:', color);
        
        for (const block of blocks) {
            // Only draw blocks that are within the visible area
            if (block.y >= 0) {
                console.log('🎨 Drawing block at:', block.x, block.y);
                this.drawCell(block.x, block.y, color, alpha);
            }
        }
    }

    /**
     * Draw a ghost piece (preview of where piece will land)
     * @param {Tetromino} tetromino - The ghost tetromino to draw
     */
    drawGhostPiece(tetromino) {
        if (!tetromino) return;
        
        const blocks = tetromino.getBlocks();
        const color = tetromino.getColor();
        
        for (const block of blocks) {
            if (block.y >= 0) {
                this.drawGhostCell(block.x, block.y, color);
            }
        }
    }

    /**
     * Draw a ghost cell (outline only)
     * @param {number} x - Grid x coordinate
     * @param {number} y - Grid y coordinate
     * @param {string} color - Cell color
     */
    drawGhostCell(x, y, color) {
        if (!this.ctx) {
            return;
        }
        
        const pixelX = x * this.cellSize;
        const pixelY = y * this.cellSize;
        
        this.ctx.save();
        this.ctx.strokeStyle = color;
        this.ctx.lineWidth = 2;
        this.ctx.globalAlpha = 0.5;
        this.ctx.strokeRect(pixelX + 1, pixelY + 1, this.cellSize - 2, this.cellSize - 2);
        this.ctx.restore();
    }

    /**
     * Draw the grid lines
     * @param {number} width - Board width in cells
     * @param {number} height - Board height in cells
     */
    drawGrid(width, height) {
        if (!this.ctx) {
            return;
        }
        
        this.ctx.save();
        this.ctx.strokeStyle = this.gridColor;
        this.ctx.lineWidth = 1;
        this.ctx.globalAlpha = 0.3;
        
        // Draw vertical lines
        for (let x = 0; x <= width; x++) {
            const pixelX = x * this.cellSize + 0.5;
            this.ctx.beginPath();
            this.ctx.moveTo(pixelX, 0);
            this.ctx.lineTo(pixelX, height * this.cellSize);
            this.ctx.stroke();
        }
        
        // Draw horizontal lines
        for (let y = 0; y <= height; y++) {
            const pixelY = y * this.cellSize + 0.5;
            this.ctx.beginPath();
            this.ctx.moveTo(0, pixelY);
            this.ctx.lineTo(width * this.cellSize, pixelY);
            this.ctx.stroke();
        }
        
        this.ctx.restore();
    }

    /**
     * Draw the next piece preview
     * @param {Tetromino} nextTetromino - The next tetromino to preview
     */
    drawNextPiece(nextTetromino) {
        this.clearNextPiece();
        
        if (!nextTetromino || !this.nextPieceCtx || !this.nextPieceCanvas) return;
        
        const shape = nextTetromino.getShape();
        const color = nextTetromino.getColor();
        const previewCellSize = Math.min(
            this.nextPieceCanvas.width / 4,
            this.nextPieceCanvas.height / 4
        );
        
        // Calculate centering offset
        const offsetX = (this.nextPieceCanvas.width - 4 * previewCellSize) / 2;
        const offsetY = (this.nextPieceCanvas.height - 4 * previewCellSize) / 2;
        
        this.nextPieceCtx.save();
        
        for (let row = 0; row < shape.length; row++) {
            for (let col = 0; col < shape[row].length; col++) {
                if (shape[row][col] === 1) {
                    const pixelX = offsetX + col * previewCellSize;
                    const pixelY = offsetY + row * previewCellSize;
                    
                    // Fill the cell
                    this.nextPieceCtx.fillStyle = color;
                    this.nextPieceCtx.fillRect(pixelX, pixelY, previewCellSize, previewCellSize);
                    
                    // Add border
                    this.nextPieceCtx.strokeStyle = this.darkenColor(color, 0.3);
                    this.nextPieceCtx.lineWidth = 1;
                    this.nextPieceCtx.strokeRect(pixelX + 0.5, pixelY + 0.5, previewCellSize - 1, previewCellSize - 1);
                    
                    // Add highlight
                    this.nextPieceCtx.fillStyle = this.lightenColor(color, 0.2);
                    this.nextPieceCtx.fillRect(pixelX + 1, pixelY + 1, previewCellSize - 2, 1);
                    this.nextPieceCtx.fillRect(pixelX + 1, pixelY + 1, 1, previewCellSize - 2);
                }
            }
        }
        
        this.nextPieceCtx.restore();
    }

    /**
     * Update UI elements with current game state
     * @param {Object} gameState - Current game state
     */
    updateUI(gameState) {
        // Update score display
        const scoreElement = document.getElementById('scoreDisplay');
        if (scoreElement) {
            scoreElement.textContent = gameState.score.toLocaleString();
        }
        
        // Update level display
        const levelElement = document.getElementById('levelDisplay');
        if (levelElement) {
            levelElement.textContent = gameState.level.toString();
        }
        
        // Update lines display
        const linesElement = document.getElementById('linesDisplay');
        if (linesElement) {
            linesElement.textContent = gameState.lines.toString();
        }
    }

    /**
     * Show game over screen
     * @param {number} finalScore - Final score to display
     */
    showGameOver(finalScore) {
        const gameOverScreen = document.getElementById('gameOverScreen');
        const finalScoreElement = document.getElementById('finalScore');
        
        if (gameOverScreen && finalScoreElement) {
            finalScoreElement.textContent = finalScore.toLocaleString();
            gameOverScreen.classList.add('show');
        }
    }

    /**
     * Hide game over screen
     */
    hideGameOver() {
        const gameOverScreen = document.getElementById('gameOverScreen');
        if (gameOverScreen) {
            gameOverScreen.classList.remove('show');
        }
    }

    /**
     * Show pause indicator
     */
    showPauseIndicator() {
        if (!this.ctx || !this.canvas) {
            return;
        }
        
        this.ctx.save();
        
        // Semi-transparent overlay
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Pause text
        this.ctx.fillStyle = '#FFFFFF';
        this.ctx.font = 'bold 24px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
        this.ctx.fillText(
            '暂停',
            this.canvas.width / 2,
            this.canvas.height / 2
        );
        
        this.ctx.restore();
    }

    /**
     * Darken a color by a specified amount
     * @param {string} color - Hex color string
     * @param {number} amount - Amount to darken (0-1)
     * @returns {string} Darkened color
     */
    darkenColor(color, amount) {
        const hex = color.replace('#', '');
        const r = Math.max(0, parseInt(hex.substr(0, 2), 16) * (1 - amount));
        const g = Math.max(0, parseInt(hex.substr(2, 2), 16) * (1 - amount));
        const b = Math.max(0, parseInt(hex.substr(4, 2), 16) * (1 - amount));
        
        return `#${Math.round(r).toString(16).padStart(2, '0')}${Math.round(g).toString(16).padStart(2, '0')}${Math.round(b).toString(16).padStart(2, '0')}`;
    }

    /**
     * Lighten a color by a specified amount
     * @param {string} color - Hex color string
     * @param {number} amount - Amount to lighten (0-1)
     * @returns {string} Lightened color
     */
    lightenColor(color, amount) {
        const hex = color.replace('#', '');
        const r = Math.min(255, parseInt(hex.substr(0, 2), 16) + (255 * amount));
        const g = Math.min(255, parseInt(hex.substr(2, 2), 16) + (255 * amount));
        const b = Math.min(255, parseInt(hex.substr(4, 2), 16) + (255 * amount));
        
        return `#${Math.round(r).toString(16).padStart(2, '0')}${Math.round(g).toString(16).padStart(2, '0')}${Math.round(b).toString(16).padStart(2, '0')}`;
    }

    /**
     * Check if renderer is properly initialized
     * @returns {boolean} True if renderer can render
     */
    canRender() {
        return this.ctx && this.canvas;
    }

    /**
     * Render the complete game frame
     * @param {Object} renderData - All data needed for rendering
     */
    render(renderData) {
        if (!this.canRender()) {
            return;
        }
        
        const { gameBoard, currentTetromino, ghostTetromino, nextTetromino, gameState } = renderData;
        
        // Clear canvas
        this.clear();
        
        // Draw game board with placed pieces
        this.drawBoard(gameBoard);
        
        // Draw ghost piece (if enabled and exists)
        if (ghostTetromino) {
            this.drawGhostPiece(ghostTetromino);
        }
        
        // Draw current falling piece
        if (currentTetromino) {
            this.drawTetromino(currentTetromino);
        }
        
        // Draw next piece preview
        this.drawNextPiece(nextTetromino);
        
        // Update UI elements
        this.updateUI(gameState);
        
        // Show pause indicator if game is paused
        if (gameState.isPaused) {
            this.showPauseIndicator();
        }
        
        // Show game over screen if game is over
        if (gameState.isGameOver) {
            this.showGameOver(gameState.score);
        }
    }

    /**
     * Get the cell size used for rendering
     * @returns {number} Cell size in pixels
     */
    getCellSize() {
        return this.cellSize;
    }

    /**
     * Resize the renderer to fit new canvas dimensions
     * @param {number} width - New canvas width
     * @param {number} height - New canvas height
     */
    resize(width, height) {
        this.canvas.width = width;
        this.canvas.height = height;
        
        // Recalculate cell size
        this.cellSize = Math.min(
            width / this.config.boardWidth,
            height / this.config.boardHeight
        );
        
        // Reinitialize canvas
        this.initializeCanvas();
    }

    /**
     * Add line clear animation effect
     * @param {number[]} lineIndices - Array of line indices being cleared
     */
    addLineClearAnimation(lineIndices) {
        const animation = {
            type: 'lineClear',
            lines: lineIndices,
            startTime: performance.now(),
            duration: 300, // 300ms animation
            phase: 'flash' // flash -> shrink -> complete
        };
        this.animations.push(animation);
    }

    /**
     * Add piece placement visual feedback
     * @param {Tetromino} tetromino - The placed tetromino
     */
    addPiecePlacementEffect(tetromino) {
        const blocks = tetromino.getBlocks();
        const effect = {
            type: 'placement',
            blocks: blocks,
            color: tetromino.getColor(),
            startTime: performance.now(),
            duration: 200 // 200ms flash effect
        };
        this.effects.push(effect);
    }

    /**
     * Add touch operation visual feedback
     * @param {string} operation - Type of operation ('move', 'rotate', 'drop')
     * @param {number} x - Touch x coordinate
     * @param {number} y - Touch y coordinate
     */
    addTouchFeedback(operation, x, y) {
        // Temporarily disabled to prevent rendering errors
        // TODO: Re-enable after fixing coordinate system
        return;
        
        const effect = {
            type: 'touch',
            operation: operation,
            x: x,
            y: y,
            startTime: performance.now(), // Use performance.now() to match game loop
            duration: 150, // 150ms ripple effect
            radius: 0
        };
        this.effects.push(effect);
    }

    /**
     * Update and render all active animations
     * @param {number} currentTime - Current timestamp
     */
    updateAnimations(currentTime) {
        // Validate currentTime
        if (!isFinite(currentTime) || currentTime < 0) {
            console.warn('Invalid currentTime in updateAnimations:', currentTime);
            return;
        }
        
        // Update animations
        this.animations = this.animations.filter(animation => {
            if (!animation || !animation.startTime || !animation.duration) {
                return false; // Remove invalid animations
            }
            
            const elapsed = currentTime - animation.startTime;
            const progress = Math.max(0, Math.min(elapsed / animation.duration, 1));
            
            if (animation.type === 'lineClear') {
                this.renderLineClearAnimation(animation, progress);
            }
            
            // Remove completed animations
            return progress < 1;
        });

        // Update effects
        this.effects = this.effects.filter(effect => {
            if (!effect || !effect.startTime || !effect.duration) {
                return false; // Remove invalid effects
            }
            
            const elapsed = currentTime - effect.startTime;
            const progress = Math.max(0, Math.min(elapsed / effect.duration, 1));
            
            if (effect.type === 'placement') {
                this.renderPlacementEffect(effect, progress);
            } else if (effect.type === 'touch') {
                this.renderTouchEffect(effect, progress);
            }
            
            // Remove completed effects
            return progress < 1;
        });
    }

    /**
     * Render line clear animation
     * @param {Object} animation - Animation data
     * @param {number} progress - Animation progress (0-1)
     */
    renderLineClearAnimation(animation, progress) {
        this.ctx.save();
        
        for (const lineY of animation.lines) {
            const pixelY = lineY * this.cellSize;
            
            if (progress < 0.5) {
                // Flash phase - alternate between bright white and normal
                const flashIntensity = Math.sin(progress * Math.PI * 8) * 0.5 + 0.5;
                this.ctx.fillStyle = `rgba(255, 255, 255, ${flashIntensity * 0.8})`;
                this.ctx.fillRect(0, pixelY, this.canvas.width, this.cellSize);
            } else {
                // Shrink phase - compress the line vertically
                const shrinkProgress = (progress - 0.5) * 2;
                const shrinkHeight = this.cellSize * (1 - shrinkProgress);
                const shrinkY = pixelY + (this.cellSize - shrinkHeight) / 2;
                
                this.ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
                this.ctx.fillRect(0, shrinkY, this.canvas.width, shrinkHeight);
            }
        }
        
        this.ctx.restore();
    }

    /**
     * Render piece placement effect
     * @param {Object} effect - Effect data
     * @param {number} progress - Effect progress (0-1)
     */
    renderPlacementEffect(effect, progress) {
        this.ctx.save();
        
        // Flash effect - fade from bright to normal
        const alpha = 1 - progress;
        this.ctx.globalAlpha = alpha * 0.6;
        
        for (const block of effect.blocks) {
            if (block.y >= 0) {
                const pixelX = block.x * this.cellSize;
                const pixelY = block.y * this.cellSize;
                
                // Draw bright overlay
                this.ctx.fillStyle = '#FFFFFF';
                this.ctx.fillRect(pixelX, pixelY, this.cellSize, this.cellSize);
            }
        }
        
        this.ctx.restore();
    }

    /**
     * Render touch feedback effect
     * @param {Object} effect - Effect data
     * @param {number} progress - Effect progress (0-1)
     */
    renderTouchEffect(effect, progress) {
        // Validate inputs
        if (!effect || typeof progress !== 'number' || !isFinite(progress)) {
            console.warn('Invalid touch effect parameters:', { effect, progress });
            return;
        }
        
        // Clamp progress to valid range
        progress = Math.max(0, Math.min(1, progress));
        
        this.ctx.save();
        
        // Ripple effect
        const maxRadius = 30;
        const currentRadius = progress * maxRadius;
        const alpha = 1 - progress;
        
        // Validate radius before drawing
        if (!isFinite(currentRadius) || currentRadius < 0) {
            console.warn('Invalid radius calculated:', currentRadius, 'from progress:', progress);
            this.ctx.restore();
            return;
        }
        
        // Draw ripple circle
        this.ctx.strokeStyle = `rgba(255, 255, 255, ${alpha})`;
        this.ctx.lineWidth = 2;
        this.ctx.beginPath();
        this.ctx.arc(effect.x, effect.y, currentRadius, 0, Math.PI * 2);
        this.ctx.stroke();
        
        // Draw operation indicator
        this.ctx.fillStyle = `rgba(255, 255, 255, ${alpha * 0.8})`;
        this.ctx.font = '12px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
        
        let indicator = '';
        switch (effect.operation) {
            case 'move': indicator = '←→'; break;
            case 'rotate': indicator = '↻'; break;
            case 'drop': indicator = '↓'; break;
            default: indicator = '•'; break;
        }
        
        this.ctx.fillText(indicator, effect.x, effect.y);
        
        this.ctx.restore();
    }

    /**
     * Draw animated line clear effect overlay
     * @param {number[]} clearingLines - Array of line indices being cleared
     * @param {number} animationProgress - Progress of animation (0-1)
     */
    drawLineClearEffect(clearingLines, animationProgress) {
        if (clearingLines.length === 0 || animationProgress >= 1) return;
        
        this.ctx.save();
        
        for (const lineY of clearingLines) {
            const pixelY = lineY * this.cellSize;
            
            if (animationProgress < 0.6) {
                // Flash effect
                const flashAlpha = Math.sin(animationProgress * Math.PI * 10) * 0.3 + 0.3;
                this.ctx.fillStyle = `rgba(255, 255, 255, ${flashAlpha})`;
                this.ctx.fillRect(0, pixelY, this.canvas.width, this.cellSize);
            } else {
                // Fade out effect
                const fadeProgress = (animationProgress - 0.6) / 0.4;
                const alpha = 1 - fadeProgress;
                this.ctx.fillStyle = `rgba(255, 255, 255, ${alpha * 0.5})`;
                this.ctx.fillRect(0, pixelY, this.canvas.width, this.cellSize);
            }
        }
        
        this.ctx.restore();
    }

    /**
     * Draw piece drop trail effect
     * @param {Tetromino} tetromino - The dropping tetromino
     * @param {number} dropDistance - Distance the piece has dropped
     */
    drawDropTrail(tetromino, dropDistance) {
        if (!tetromino || dropDistance <= 0) return;
        
        this.ctx.save();
        
        const blocks = tetromino.getBlocks();
        const color = tetromino.getColor();
        
        // Draw fading trail
        const trailSteps = Math.min(dropDistance, 5);
        for (let i = 0; i < trailSteps; i++) {
            const alpha = (trailSteps - i) / trailSteps * 0.3;
            this.ctx.globalAlpha = alpha;
            
            for (const block of blocks) {
                const trailY = block.y - i - 1;
                if (trailY >= 0) {
                    const pixelX = block.x * this.cellSize;
                    const pixelY = trailY * this.cellSize;
                    
                    this.ctx.fillStyle = color;
                    this.ctx.fillRect(pixelX, pixelY, this.cellSize, this.cellSize);
                }
            }
        }
        
        this.ctx.restore();
    }

    /**
     * Check if any animations are currently active
     * @returns {boolean} True if animations are running
     */
    hasActiveAnimations() {
        return this.animations.length > 0 || this.effects.length > 0;
    }

    /**
     * Clear all active animations and effects
     */
    clearAnimations() {
        this.animations = [];
        this.effects = [];
    }

    /**
     * Enhanced render method with animation support and performance optimizations
     * @param {Object} renderData - All data needed for rendering
     * @param {number} currentTime - Current timestamp for animations
     */
    renderWithAnimations(renderData, currentTime = performance.now()) {
        if (!this.canRender()) {
            return;
        }
        
        // Force rendering every frame for debugging
        // if (currentTime - this.lastRenderTime < this.renderThrottle && !this.needsRedraw) {
        //     return;
        // }
        
        const { gameBoard, currentTetromino, ghostTetromino, nextTetromino, gameState, clearingLines, animationProgress } = renderData;
        
        // Force redraw every frame for debugging
        // const boardHash = this.getBoardHash(gameBoard);
        // const hasAnimations = this.animations.length > 0 || this.effects.length > 0 || (clearingLines && clearingLines.length > 0);
        
        // if (!this.needsRedraw && !hasAnimations && boardHash === this.cachedBoardHash) {
        //     // Only update UI elements if no visual changes
        //     this.updateUI(gameState);
        //     return;
        // }
        
        // Clear canvas
        this.clear();
        
        // Draw game board with placed pieces
        this.drawBoard(gameBoard);
        
        // Draw line clear animation if active
        if (clearingLines && clearingLines.length > 0) {
            this.drawLineClearEffect(clearingLines, animationProgress || 0);
        }
        
        // Draw ghost piece (if enabled and exists)
        if (ghostTetromino) {
            this.drawGhostPiece(ghostTetromino);
        }
        
        // Draw current falling piece
        if (currentTetromino) {
            this.drawTetromino(currentTetromino);
        }
        
        // Update and render animations/effects
        this.updateAnimations(currentTime);
        
        // Draw next piece preview
        this.drawNextPiece(nextTetromino);
        
        // Update UI elements
        this.updateUI(gameState);
        
        // Show pause indicator if game is paused
        if (gameState.isPaused) {
            this.showPauseIndicator();
        }
        
        // Show game over screen if game is over
        if (gameState.isGameOver) {
            this.showGameOver(gameState.score);
        }
        
        // Update performance tracking
        this.lastRenderTime = currentTime;
        this.needsRedraw = false;
        this.cachedBoardHash = boardHash;
    }

    /**
     * Generate a hash of the game board for change detection
     * @param {GameBoard} gameBoard - The game board
     * @returns {string} Hash of the board state
     */
    getBoardHash(gameBoard) {
        if (!gameBoard) return '';
        
        const board = gameBoard.getBoard();
        let hash = '';
        for (let y = 0; y < board.length; y++) {
            for (let x = 0; x < board[y].length; x++) {
                hash += board[y][x] ? '1' : '0';
            }
        }
        return hash;
    }

    /**
     * Mark renderer as needing redraw
     */
    markDirty() {
        this.needsRedraw = true;
    }

    /**
     * Optimize canvas for better performance
     */
    optimizeCanvas() {
        if (!this.ctx || !this.canvas) {
            return;
        }
        
        // Enable hardware acceleration hints
        this.ctx.imageSmoothingEnabled = false;
        
        // Set up efficient drawing state
        this.ctx.lineWidth = 1;
        this.ctx.lineCap = 'square';
        this.ctx.lineJoin = 'miter';
    }

    /**
     * Update pixel ratio for high DPI displays
     */
    updatePixelRatio() {
        if (!this.canvas || !this.ctx) {
            return;
        }
        
        const pixelRatio = window.devicePixelRatio || 1;
        const displayWidth = this.canvas.clientWidth * pixelRatio;
        const displayHeight = this.canvas.clientHeight * pixelRatio;
        
        if (this.canvas.width !== displayWidth || this.canvas.height !== displayHeight) {
            this.canvas.width = displayWidth;
            this.canvas.height = displayHeight;
            this.ctx.scale(pixelRatio, pixelRatio);
            this.markDirty();
        }
    }

    /**
     * Update canvas size and recalculate cell size
     * @param {number} width - New canvas width
     * @param {number} height - New canvas height
     */
    updateCanvasSize(width, height) {
        if (!this.canvas || !this.config) {
            return;
        }
        
        this.canvas.width = width;
        this.canvas.height = height;
        
        // Recalculate cell size
        this.cellSize = Math.min(
            width / this.config.boardWidth,
            height / this.config.boardHeight
        );
        
        this.optimizeCanvas();
        this.markDirty();
    }

    /**
     * Get performance metrics
     * @returns {Object} Performance metrics
     */
    getPerformanceMetrics() {
        return {
            lastRenderTime: this.lastRenderTime,
            renderThrottle: this.renderThrottle,
            needsRedraw: this.needsRedraw,
            activeAnimations: this.animations.length,
            activeEffects: this.effects.length,
            cellSize: this.cellSize,
            canvasSize: this.canvas ? {
                width: this.canvas.width,
                height: this.canvas.height
            } : null
        };
    }

    /**
     * Set render throttle for performance tuning
     * @param {number} throttle - Milliseconds between renders
     */
    setRenderThrottle(throttle) {
        this.renderThrottle = Math.max(8, throttle); // Minimum 8ms (120 FPS)
    }

    /**
     * Enable or disable performance optimizations
     * @param {boolean} enabled - Whether to enable optimizations
     */
    setPerformanceMode(enabled) {
        if (enabled) {
            this.renderThrottle = 16; // 60 FPS
            this.optimizeCanvas();
        } else {
            this.renderThrottle = 8; // 120 FPS
        }
    }
}