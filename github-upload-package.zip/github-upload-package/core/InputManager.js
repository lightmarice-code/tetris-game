/**
 * InputManager class - Handles keyboard and touch input for Tetris game
 * Provides input debouncing, action mapping, and event handling
 */

export class InputManager {
    /**
     * Create a new InputManager
     * @param {GameEngine} gameEngine - The game engine instance to control
     */
    constructor(gameEngine) {
        this.gameEngine = gameEngine;
        
        // Input action mappings
        this.INPUT_ACTIONS = {
            MOVE_LEFT: 'moveLeft',
            MOVE_RIGHT: 'moveRight',
            SOFT_DROP: 'softDrop',
            HARD_DROP: 'hardDrop',
            ROTATE_CW: 'rotateCW',
            ROTATE_CCW: 'rotateCCW',
            PAUSE: 'pause',
            RESTART: 'restart'
        };
        
        // Key mappings to actions
        this.keyMappings = {
            'ArrowLeft': this.INPUT_ACTIONS.MOVE_LEFT,
            'ArrowRight': this.INPUT_ACTIONS.MOVE_RIGHT,
            'ArrowDown': this.INPUT_ACTIONS.SOFT_DROP,
            'ArrowUp': this.INPUT_ACTIONS.ROTATE_CW,
            ' ': this.INPUT_ACTIONS.HARD_DROP, // Space key
            'Space': this.INPUT_ACTIONS.HARD_DROP,
            'KeyZ': this.INPUT_ACTIONS.ROTATE_CCW,
            'KeyX': this.INPUT_ACTIONS.ROTATE_CW,
            'KeyP': this.INPUT_ACTIONS.PAUSE,
            'Escape': this.INPUT_ACTIONS.PAUSE,
            'KeyR': this.INPUT_ACTIONS.RESTART
        };
        
        // Input state tracking
        this.keysPressed = new Set();
        this.lastKeyTime = new Map();
        this.repeatTimers = new Map(); // Store repeat timers for continuous actions
        this.touchButtonTimers = new Map(); // Store repeat timers for touch buttons
        
        // Debouncing and repeat settings
        this.debounceDelay = 50; // milliseconds
        this.repeatDelay = 200; // milliseconds for continuous actions (initial delay)
        this.repeatInterval = 80; // milliseconds between repeats (continuous speed)
        
        // Actions that can repeat when held
        this.repeatableActions = new Set([
            this.INPUT_ACTIONS.MOVE_LEFT,
            this.INPUT_ACTIONS.MOVE_RIGHT,
            this.INPUT_ACTIONS.SOFT_DROP
        ]);
        
        // Touch input state
        this.touchStartPos = null;
        this.touchCurrentPos = null;
        this.touchStartTime = 0;
        this.isTouching = false;
        
        // Touch gesture settings
        this.swipeThreshold = 30; // minimum distance for swipe
        this.tapThreshold = 10; // maximum distance for tap
        this.tapTimeThreshold = 200; // maximum time for tap
        this.swipeTimeThreshold = 500; // maximum time for swipe
        
        // Touch zones (will be set when canvas is available)
        this.touchZones = {
            leftZone: null,
            rightZone: null,
            rotateZone: null,
            dropZone: null
        };
        
        // Bind event handlers
        this.handleKeyDown = this.handleKeyDown.bind(this);
        this.handleKeyUp = this.handleKeyUp.bind(this);
        this.handleVisibilityChange = this.handleVisibilityChange.bind(this);
        this.handleTouchStart = this.handleTouchStart.bind(this);
        this.handleTouchMove = this.handleTouchMove.bind(this);
        this.handleTouchEnd = this.handleTouchEnd.bind(this);
        
        // Initialize event listeners
        this.bindKeyboardEvents();
        this.bindTouchEvents();
        this.bindTouchControlButtons();
    }

    /**
     * Bind keyboard event listeners
     */
    bindKeyboardEvents() {
        console.log('🎮 Binding keyboard events...');
        document.addEventListener('keydown', this.handleKeyDown);
        document.addEventListener('keyup', this.handleKeyUp);
        document.addEventListener('visibilitychange', this.handleVisibilityChange);
        
        // Prevent default behavior for game keys
        document.addEventListener('keydown', (event) => {
            if (this.keyMappings[event.code] || this.keyMappings[event.key]) {
                event.preventDefault();
            }
        });
        
        console.log('✅ Keyboard events bound successfully');
        console.log('📋 Key mappings:', this.keyMappings);
    }

    /**
     * Remove keyboard event listeners
     */
    unbindKeyboardEvents() {
        document.removeEventListener('keydown', this.handleKeyDown);
        document.removeEventListener('keyup', this.handleKeyUp);
        document.removeEventListener('visibilitychange', this.handleVisibilityChange);
    }

    /**
     * Bind touch event listeners
     */
    bindTouchEvents() {
        // Get canvas element from game engine
        const canvas = this.gameEngine.canvas;
        if (canvas) {
            canvas.addEventListener('touchstart', this.handleTouchStart, { passive: false });
            canvas.addEventListener('touchmove', this.handleTouchMove, { passive: false });
            canvas.addEventListener('touchend', this.handleTouchEnd, { passive: false });
            canvas.addEventListener('touchcancel', this.handleTouchEnd, { passive: false });
            
            // Initialize touch zones based on canvas size
            this.initializeTouchZones(canvas);
        }
    }

    /**
     * Remove touch event listeners
     */
    unbindTouchEvents() {
        const canvas = this.gameEngine.canvas;
        if (canvas) {
            canvas.removeEventListener('touchstart', this.handleTouchStart);
            canvas.removeEventListener('touchmove', this.handleTouchMove);
            canvas.removeEventListener('touchend', this.handleTouchEnd);
            canvas.removeEventListener('touchcancel', this.handleTouchEnd);
        }
    }

    /**
     * Initialize touch zones based on canvas dimensions
     * @param {HTMLCanvasElement} canvas - The game canvas
     */
    initializeTouchZones(canvas) {
        const rect = canvas.getBoundingClientRect();
        const width = rect.width;
        const height = rect.height;
        
        // Define touch zones
        this.touchZones = {
            // Left third of screen for left movement
            leftZone: {
                x: 0,
                y: 0,
                width: width / 3,
                height: height
            },
            // Right third of screen for right movement
            rightZone: {
                x: (width * 2) / 3,
                y: 0,
                width: width / 3,
                height: height
            },
            // Middle area for rotation (tap) and drop (swipe down)
            centerZone: {
                x: width / 3,
                y: 0,
                width: width / 3,
                height: height
            },
            // Top area for rotation button
            rotateZone: {
                x: width / 3,
                y: 0,
                width: width / 3,
                height: height / 4
            },
            // Bottom area for hard drop
            dropZone: {
                x: width / 3,
                y: (height * 3) / 4,
                width: width / 3,
                height: height / 4
            }
        };
    }

    /**
     * Handle keydown events
     * @param {KeyboardEvent} event - The keyboard event
     */
    handleKeyDown(event) {
        console.log('🎮 Key pressed:', event.code, event.key);
        const action = this.keyMappings[event.code] || this.keyMappings[event.key];
        
        if (!action) {
            console.log('❌ No action mapped for key:', event.code, event.key);
            return;
        }
        
        console.log('✅ Mapped action:', action);
        
        // Prevent default behavior for game keys
        event.preventDefault();
        
        const currentTime = performance.now();
        const key = event.code || event.key;
        
        // Check if key is already pressed (for repeat handling)
        const isKeyPressed = this.keysPressed.has(key);
        
        // Handle initial press or repeat
        if (!isKeyPressed) {
            // Initial press - execute immediately
            this.keysPressed.add(key);
            this.lastKeyTime.set(key, currentTime);
            this.executeAction(action);
            
            // Start repeat timer for repeatable actions
            if (this.repeatableActions.has(action)) {
                this.startRepeatTimer(key, action);
            }
        }
        // Note: Subsequent keydown events while key is held are handled by the repeat timer
    }

    /**
     * Handle keyup events
     * @param {KeyboardEvent} event - The keyboard event
     */
    handleKeyUp(event) {
        const key = event.code || event.key;
        this.keysPressed.delete(key);
        this.lastKeyTime.delete(key);
        this.lastKeyTime.delete(key + '_repeat');
        
        // Clear repeat timer if it exists
        this.clearRepeatTimer(key);
    }

    /**
     * Start repeat timer for continuous actions
     * @param {string} key - The key code
     * @param {string} action - The action to repeat
     */
    startRepeatTimer(key, action) {
        // Clear any existing timer for this key
        this.clearRepeatTimer(key);
        
        console.log(`🔄 Starting repeat timer for ${key} (${action})`);
        
        // Set initial delay timer
        const initialTimer = setTimeout(() => {
            console.log(`⏰ Initial delay complete, starting continuous repeat for ${key}`);
            
            // Start repeating at regular intervals
            const repeatTimer = setInterval(() => {
                // Only continue if key is still pressed
                if (this.keysPressed.has(key)) {
                    console.log(`🔁 Repeating action ${action} for ${key}`);
                    this.executeAction(action);
                } else {
                    // Key was released, clear the timer
                    console.log(`🛑 Key ${key} released, stopping repeat`);
                    this.clearRepeatTimer(key);
                }
            }, this.repeatInterval);
            
            // Store the repeat timer
            this.repeatTimers.set(key, repeatTimer);
        }, this.repeatDelay);
        
        // Store the initial timer temporarily
        this.repeatTimers.set(key + '_initial', initialTimer);
    }

    /**
     * Clear repeat timer for a key
     * @param {string} key - The key code
     */
    clearRepeatTimer(key) {
        // Clear initial delay timer
        const initialTimer = this.repeatTimers.get(key + '_initial');
        if (initialTimer) {
            console.log(`🚫 Clearing initial timer for ${key}`);
            clearTimeout(initialTimer);
            this.repeatTimers.delete(key + '_initial');
        }
        
        // Clear repeat interval timer
        const repeatTimer = this.repeatTimers.get(key);
        if (repeatTimer) {
            console.log(`🚫 Clearing repeat timer for ${key}`);
            clearInterval(repeatTimer);
            this.repeatTimers.delete(key);
        }
    }

    /**
     * Handle visibility change (pause when tab loses focus)
     * @param {Event} event - The visibility change event
     */
    handleVisibilityChange(event) {
        if (document.hidden) {
            // Clear all pressed keys and timers when losing focus
            this.clearPressedKeys();
            
            if (this.gameEngine.isGameRunning() && !this.gameEngine.isGamePaused()) {
                this.executeAction(this.INPUT_ACTIONS.PAUSE);
            }
        }
    }

    /**
     * Handle touch start events
     * @param {TouchEvent} event - The touch event
     */
    handleTouchStart(event) {
        event.preventDefault();
        
        if (event.touches.length > 1) {
            // Multi-touch not supported
            return;
        }
        
        const touch = event.touches[0];
        const canvas = this.gameEngine.canvas;
        const rect = canvas.getBoundingClientRect();
        
        this.touchStartPos = {
            x: touch.clientX - rect.left,
            y: touch.clientY - rect.top
        };
        
        this.touchCurrentPos = { ...this.touchStartPos };
        this.touchStartTime = performance.now();
        this.isTouching = true;
    }

    /**
     * Handle touch move events
     * @param {TouchEvent} event - The touch event
     */
    handleTouchMove(event) {
        event.preventDefault();
        
        if (!this.isTouching || event.touches.length > 1) {
            return;
        }
        
        const touch = event.touches[0];
        const canvas = this.gameEngine.canvas;
        const rect = canvas.getBoundingClientRect();
        
        this.touchCurrentPos = {
            x: touch.clientX - rect.left,
            y: touch.clientY - rect.top
        };
    }

    /**
     * Handle touch end events
     * @param {TouchEvent} event - The touch event
     */
    handleTouchEnd(event) {
        event.preventDefault();
        
        if (!this.isTouching) {
            return;
        }
        
        const touchEndTime = performance.now();
        const touchDuration = touchEndTime - this.touchStartTime;
        
        // Calculate touch distance
        const deltaX = this.touchCurrentPos.x - this.touchStartPos.x;
        const deltaY = this.touchCurrentPos.y - this.touchStartPos.y;
        const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
        
        // Determine gesture type and execute action
        this.processTouch(deltaX, deltaY, distance, touchDuration);
        
        // Reset touch state
        this.isTouching = false;
        this.touchStartPos = null;
        this.touchCurrentPos = null;
        this.touchStartTime = 0;
    }

    /**
     * Process touch gesture and execute appropriate action
     * @param {number} deltaX - Horizontal distance
     * @param {number} deltaY - Vertical distance
     * @param {number} distance - Total distance
     * @param {number} duration - Touch duration
     */
    processTouch(deltaX, deltaY, distance, duration) {
        const startPos = this.touchStartPos;
        
        // Check if it's a tap (short duration, small distance)
        if (duration <= this.tapTimeThreshold && distance <= this.tapThreshold) {
            this.handleTap(startPos);
            return;
        }
        
        // Check if it's a swipe (within time threshold, above distance threshold)
        if (duration <= this.swipeTimeThreshold && distance >= this.swipeThreshold) {
            this.handleSwipe(deltaX, deltaY, startPos);
            return;
        }
    }

    /**
     * Handle tap gesture
     * @param {Object} position - Touch position {x, y}
     */
    handleTap(position) {
        // Check which zone was tapped
        if (this.isInZone(position, this.touchZones.rotateZone)) {
            // Tap in rotate zone - rotate piece
            this.executeAction(this.INPUT_ACTIONS.ROTATE_CW);
        } else if (this.isInZone(position, this.touchZones.dropZone)) {
            // Tap in drop zone - hard drop
            this.executeAction(this.INPUT_ACTIONS.HARD_DROP);
        } else if (this.isInZone(position, this.touchZones.centerZone)) {
            // Tap in center zone - rotate (default action)
            this.executeAction(this.INPUT_ACTIONS.ROTATE_CW);
        }
    }

    /**
     * Handle swipe gesture
     * @param {number} deltaX - Horizontal distance
     * @param {number} deltaY - Vertical distance
     * @param {Object} startPos - Starting position {x, y}
     */
    handleSwipe(deltaX, deltaY, startPos) {
        const absX = Math.abs(deltaX);
        const absY = Math.abs(deltaY);
        
        // Determine primary swipe direction
        if (absX > absY) {
            // Horizontal swipe
            if (deltaX > 0) {
                // Swipe right
                if (this.isInZone(startPos, this.touchZones.leftZone) || 
                    this.isInZone(startPos, this.touchZones.centerZone)) {
                    this.executeAction(this.INPUT_ACTIONS.MOVE_RIGHT);
                }
            } else {
                // Swipe left
                if (this.isInZone(startPos, this.touchZones.rightZone) || 
                    this.isInZone(startPos, this.touchZones.centerZone)) {
                    this.executeAction(this.INPUT_ACTIONS.MOVE_LEFT);
                }
            }
        } else {
            // Vertical swipe
            if (deltaY > 0) {
                // Swipe down - soft drop
                this.executeAction(this.INPUT_ACTIONS.SOFT_DROP);
            }
            // Swipe up could be used for hard drop or rotation
            else if (deltaY < 0) {
                this.executeAction(this.INPUT_ACTIONS.HARD_DROP);
            }
        }
    }

    /**
     * Check if position is within a touch zone
     * @param {Object} position - Position to check {x, y}
     * @param {Object} zone - Zone to check against {x, y, width, height}
     * @returns {boolean} True if position is in zone
     */
    isInZone(position, zone) {
        if (!position || !zone) {
            return false;
        }
        
        return position.x >= zone.x &&
               position.x <= zone.x + zone.width &&
               position.y >= zone.y &&
               position.y <= zone.y + zone.height;
    }

    /**
     * Execute a game action with debouncing
     * @param {string} action - The action to execute
     */
    executeAction(action) {
        const currentTime = performance.now();
        const lastActionTime = this.lastKeyTime.get(action + '_action') || 0;
        
        // Apply debouncing for non-repeatable actions
        if (!this.repeatableActions.has(action) && 
            currentTime - lastActionTime < this.debounceDelay) {
            return;
        }
        
        this.lastKeyTime.set(action + '_action', currentTime);
        this.handleInput(action);
    }

    /**
     * Handle input action and call appropriate game engine method
     * @param {string} action - The input action to handle
     */
    handleInput(action) {
        if (!this.gameEngine) {
            console.log('❌ No game engine available');
            return;
        }
        
        console.log('🎯 Executing action:', action);
        
        switch (action) {
            case this.INPUT_ACTIONS.MOVE_LEFT:
                this.gameEngine.moveLeft();
                break;
                
            case this.INPUT_ACTIONS.MOVE_RIGHT:
                this.gameEngine.moveRight();
                break;
                
            case this.INPUT_ACTIONS.SOFT_DROP:
                this.gameEngine.softDrop();
                // Don't reset drop timer - let natural timing continue
                break;
                
            case this.INPUT_ACTIONS.HARD_DROP:
                this.gameEngine.hardDrop();
                break;
                
            case this.INPUT_ACTIONS.ROTATE_CW:
                this.gameEngine.rotate();
                break;
                
            case this.INPUT_ACTIONS.ROTATE_CCW:
                this.gameEngine.rotateCounterClockwise();
                break;
                
            case this.INPUT_ACTIONS.PAUSE:
                this.handlePauseToggle();
                break;
                
            case this.INPUT_ACTIONS.RESTART:
                this.handleRestart();
                break;
                
            default:
                console.warn(`Unknown input action: ${action}`);
        }
    }

    /**
     * Handle pause/resume toggle
     */
    handlePauseToggle() {
        if (this.gameEngine.isGameOver()) {
            return;
        }
        
        if (this.gameEngine.isGamePaused()) {
            this.gameEngine.resume();
        } else if (this.gameEngine.isGameRunning()) {
            this.gameEngine.pause();
        }
    }

    /**
     * Handle game restart
     */
    handleRestart() {
        this.gameEngine.reset();
        this.gameEngine.start();
    }

    /**
     * Set custom key mapping
     * @param {string} key - The key code or key name
     * @param {string} action - The action to map to
     */
    setKeyMapping(key, action) {
        if (Object.values(this.INPUT_ACTIONS).includes(action)) {
            this.keyMappings[key] = action;
        } else {
            console.warn(`Invalid action: ${action}`);
        }
    }

    /**
     * Remove key mapping
     * @param {string} key - The key code or key name to remove
     */
    removeKeyMapping(key) {
        delete this.keyMappings[key];
    }

    /**
     * Get current key mappings
     * @returns {Object} Current key mappings
     */
    getKeyMappings() {
        return { ...this.keyMappings };
    }

    /**
     * Set debounce delay
     * @param {number} delay - Delay in milliseconds
     */
    setDebounceDelay(delay) {
        this.debounceDelay = Math.max(0, delay);
    }

    /**
     * Set repeat settings
     * @param {number} delay - Initial delay before repeat starts
     * @param {number} interval - Interval between repeats
     */
    setRepeatSettings(delay, interval) {
        this.repeatDelay = Math.max(0, delay);
        this.repeatInterval = Math.max(0, interval);
    }

    /**
     * Check if a key is currently pressed
     * @param {string} key - The key to check
     * @returns {boolean} True if key is pressed
     */
    isKeyPressed(key) {
        return this.keysPressed.has(key);
    }

    /**
     * Clear all pressed keys (useful for focus loss)
     */
    clearPressedKeys() {
        this.keysPressed.clear();
        this.lastKeyTime.clear();
        
        // Clear all repeat timers
        for (const [key, timer] of this.repeatTimers) {
            if (key.endsWith('_initial')) {
                clearTimeout(timer);
            } else {
                clearInterval(timer);
            }
        }
        this.repeatTimers.clear();
        
        // Clear all touch button timers
        for (const [button, timer] of this.touchButtonTimers) {
            if (timer.initial) {
                clearTimeout(timer.initial);
            }
            if (timer.repeat) {
                clearInterval(timer.repeat);
            }
        }
        this.touchButtonTimers.clear();
    }

    /**
     * Update touch zones when canvas size changes
     */
    updateTouchZones() {
        const canvas = this.gameEngine.canvas;
        if (canvas) {
            this.initializeTouchZones(canvas);
        }
    }

    /**
     * Set touch gesture thresholds
     * @param {Object} settings - Gesture settings
     * @param {number} settings.swipeThreshold - Minimum distance for swipe
     * @param {number} settings.tapThreshold - Maximum distance for tap
     * @param {number} settings.tapTimeThreshold - Maximum time for tap
     * @param {number} settings.swipeTimeThreshold - Maximum time for swipe
     */
    setTouchSettings(settings) {
        if (settings.swipeThreshold !== undefined) {
            this.swipeThreshold = Math.max(0, settings.swipeThreshold);
        }
        if (settings.tapThreshold !== undefined) {
            this.tapThreshold = Math.max(0, settings.tapThreshold);
        }
        if (settings.tapTimeThreshold !== undefined) {
            this.tapTimeThreshold = Math.max(0, settings.tapTimeThreshold);
        }
        if (settings.swipeTimeThreshold !== undefined) {
            this.swipeTimeThreshold = Math.max(0, settings.swipeTimeThreshold);
        }
    }

    /**
     * Get current touch settings
     * @returns {Object} Current touch settings
     */
    getTouchSettings() {
        return {
            swipeThreshold: this.swipeThreshold,
            tapThreshold: this.tapThreshold,
            tapTimeThreshold: this.tapTimeThreshold,
            swipeTimeThreshold: this.swipeTimeThreshold
        };
    }

    /**
     * Check if touch input is currently active
     * @returns {boolean} True if currently touching
     */
    isTouchActive() {
        return this.isTouching;
    }

    /**
     * Get current touch zones
     * @returns {Object} Current touch zones
     */
    getTouchZones() {
        return { ...this.touchZones };
    }

    /**
     * Bind touch control button events
     */
    bindTouchControlButtons() {
        // Bind touch control buttons
        const touchButtons = document.querySelectorAll('.touch-btn');
        const pauseBtn = document.getElementById('pauseBtn');
        
        touchButtons.forEach(button => {
            button.addEventListener('touchstart', this.handleTouchButtonStart.bind(this), { passive: false });
            button.addEventListener('touchend', this.handleTouchButtonEnd.bind(this), { passive: false });
            button.addEventListener('touchcancel', this.handleTouchButtonEnd.bind(this), { passive: false });
            button.addEventListener('click', this.handleTouchButtonClick.bind(this), { passive: false });
        });
        
        if (pauseBtn) {
            pauseBtn.addEventListener('touchstart', this.handleTouchButtonStart.bind(this), { passive: false });
            pauseBtn.addEventListener('touchend', this.handleTouchButtonEnd.bind(this), { passive: false });
            pauseBtn.addEventListener('touchcancel', this.handleTouchButtonEnd.bind(this), { passive: false });
            pauseBtn.addEventListener('click', this.handleTouchButtonClick.bind(this), { passive: false });
        }
    }

    /**
     * Unbind touch control button events
     */
    unbindTouchControlButtons() {
        const touchButtons = document.querySelectorAll('.touch-btn');
        const pauseBtn = document.getElementById('pauseBtn');
        
        touchButtons.forEach(button => {
            button.removeEventListener('touchstart', this.handleTouchButtonStart.bind(this));
            button.removeEventListener('touchend', this.handleTouchButtonEnd.bind(this));
            button.removeEventListener('touchcancel', this.handleTouchButtonEnd.bind(this));
            button.removeEventListener('click', this.handleTouchButtonClick.bind(this));
        });
        
        if (pauseBtn) {
            pauseBtn.removeEventListener('touchstart', this.handleTouchButtonStart.bind(this));
            pauseBtn.removeEventListener('touchend', this.handleTouchButtonEnd.bind(this));
            pauseBtn.removeEventListener('touchcancel', this.handleTouchButtonEnd.bind(this));
            pauseBtn.removeEventListener('click', this.handleTouchButtonClick.bind(this));
        }
    }

    /**
     * Handle touch button start (for visual feedback and continuous action)
     * @param {TouchEvent} event - The touch event
     */
    handleTouchButtonStart(event) {
        event.preventDefault();
        event.stopPropagation();
        
        const button = event.currentTarget;
        button.classList.add('active');
        
        // Execute action immediately
        const action = button.dataset.action;
        if (action) {
            this.handleTouchButtonAction(action);
            
            // Start continuous action for repeatable actions
            const inputAction = this.getInputActionFromTouchAction(action);
            if (inputAction && this.repeatableActions.has(inputAction)) {
                this.startTouchButtonRepeat(button, action);
            }
        }
    }

    /**
     * Handle touch button end
     * @param {TouchEvent} event - The touch event
     */
    handleTouchButtonEnd(event) {
        event.preventDefault();
        event.stopPropagation();
        
        const button = event.currentTarget;
        button.classList.remove('active');
        
        // Clear any continuous action timer
        this.clearTouchButtonRepeat(button);
    }

    /**
     * Handle touch button click (fallback for non-touch devices)
     * @param {MouseEvent} event - The click event
     */
    handleTouchButtonClick(event) {
        event.preventDefault();
        event.stopPropagation();
        
        const button = event.currentTarget;
        const action = button.dataset.action;
        if (action) {
            this.handleTouchButtonAction(action);
        }
    }

    /**
     * Handle touch button action
     * @param {string} action - The button action
     */
    handleTouchButtonAction(action) {
        switch (action) {
            case 'left':
                this.executeAction(this.INPUT_ACTIONS.MOVE_LEFT);
                break;
            case 'right':
                this.executeAction(this.INPUT_ACTIONS.MOVE_RIGHT);
                break;
            case 'down':
                this.executeAction(this.INPUT_ACTIONS.SOFT_DROP);
                break;
            case 'rotate':
                this.executeAction(this.INPUT_ACTIONS.ROTATE_CW);
                break;
            case 'pause':
                this.executeAction(this.INPUT_ACTIONS.PAUSE);
                break;
            case 'hardDrop':
                this.executeAction(this.INPUT_ACTIONS.HARD_DROP);
                break;
            case 'restart':
                this.executeAction(this.INPUT_ACTIONS.RESTART);
                break;
            default:
                console.warn(`Unknown touch button action: ${action}`);
        }
    }

    /**
     * Show or hide touch controls based on device type
     */
    updateTouchControlsVisibility() {
        const touchControls = document.getElementById('touchControls');
        const pauseBtn = document.getElementById('pauseBtn');
        
        // Check if device supports touch
        const isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
        
        // Check screen size (mobile breakpoint)
        const isMobileSize = window.innerWidth <= 768;
        
        const shouldShowControls = isTouchDevice && isMobileSize;
        
        if (touchControls) {
            touchControls.style.display = shouldShowControls ? 'block' : 'none';
        }
        
        if (pauseBtn) {
            pauseBtn.style.display = shouldShowControls ? 'block' : 'none';
        }
    }

    /**
     * Get input action from touch button action
     * @param {string} touchAction - The touch button action
     * @returns {string|null} The corresponding input action
     */
    getInputActionFromTouchAction(touchAction) {
        switch (touchAction) {
            case 'left':
                return this.INPUT_ACTIONS.MOVE_LEFT;
            case 'right':
                return this.INPUT_ACTIONS.MOVE_RIGHT;
            case 'down':
                return this.INPUT_ACTIONS.SOFT_DROP;
            default:
                return null;
        }
    }

    /**
     * Start repeat timer for touch button continuous actions
     * @param {HTMLElement} button - The touch button element
     * @param {string} action - The action to repeat
     */
    startTouchButtonRepeat(button, action) {
        // Clear any existing timer for this button
        this.clearTouchButtonRepeat(button);
        
        console.log(`🔄 Starting touch button repeat for ${action}`);
        
        // Set initial delay timer
        const initialTimer = setTimeout(() => {
            console.log(`⏰ Touch button initial delay complete, starting continuous repeat for ${action}`);
            
            // Start repeating at regular intervals
            const repeatTimer = setInterval(() => {
                // Check if button still has active class (still being pressed)
                if (button.classList.contains('active')) {
                    console.log(`🔁 Repeating touch action ${action}`);
                    this.handleTouchButtonAction(action);
                } else {
                    // Button was released, clear the timer
                    console.log(`🛑 Touch button ${action} released, stopping repeat`);
                    this.clearTouchButtonRepeat(button);
                }
            }, this.repeatInterval);
            
            // Store the repeat timer
            const timers = this.touchButtonTimers.get(button) || {};
            timers.repeat = repeatTimer;
            this.touchButtonTimers.set(button, timers);
        }, this.repeatDelay);
        
        // Store the initial timer
        this.touchButtonTimers.set(button, { initial: initialTimer });
    }

    /**
     * Clear repeat timer for a touch button
     * @param {HTMLElement} button - The touch button element
     */
    clearTouchButtonRepeat(button) {
        const timers = this.touchButtonTimers.get(button);
        if (timers) {
            if (timers.initial) {
                console.log(`🚫 Clearing touch button initial timer`);
                clearTimeout(timers.initial);
            }
            if (timers.repeat) {
                console.log(`🚫 Clearing touch button repeat timer`);
                clearInterval(timers.repeat);
            }
            this.touchButtonTimers.delete(button);
        }
    }

    /**
     * Destroy the input manager and clean up event listeners
     */
    destroy() {
        this.unbindKeyboardEvents();
        this.unbindTouchEvents();
        this.unbindTouchControlButtons();
        this.clearPressedKeys(); // This will also clear repeat timers
        this.gameEngine = null;
    }
}