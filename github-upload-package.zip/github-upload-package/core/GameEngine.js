/**
 * GameEngine class - Core game loop and state management for Tetris
 * Handles update/render cycle, game state transitions, and timing
 */

import { GameState } from './GameState.js';
import { GameBoard } from './GameBoard.js';
import { Tetromino } from './Tetromino.js';
import { Renderer } from './Renderer.js';
import { GameConfig } from '../config/GameConfig.js';

export class GameEngine {
    /**
     * Create a new GameEngine
     * @param {HTMLCanvasElement} canvas - The canvas element for rendering
     * @param {GameConfig} config - Game configuration object
     */
    constructor(canvas, config = new GameConfig()) {
        this.canvas = canvas;
        this.config = config;
        
        // Initialize game components
        this.gameState = new GameState(config);
        this.gameBoard = new GameBoard(config.boardWidth, config.boardHeight);
        
        // Initialize renderer
        const nextPieceCanvas = document.getElementById('nextPieceCanvas');
        this.renderer = new Renderer(canvas, nextPieceCanvas, config);
        
        // Game pieces
        this.currentTetromino = null;
        this.nextTetromino = null;
        this.ghostTetromino = null;
        
        // Timing
        this.lastUpdateTime = 0;
        this.dropTimer = 0;
        this.isRunning = false;
        this.animationFrameId = null;
        
        // Animation and effects
        this.clearingLines = [];
        this.animationProgress = 0;
        this.animationStartTime = 0;
        this.lineClearAnimationDuration = 300;
        
        // Performance monitoring
        this.performanceMetrics = {
            frameCount: 0,
            lastFPSCheck: 0,
            currentFPS: 0,
            averageFrameTime: 0,
            memoryUsage: 0
        };
        
        // Error handling
        this.errorCount = 0;
        this.maxErrors = 50;
        this.lastError = null;
        
        // Bind methods to preserve context
        this.gameLoop = this.gameLoop.bind(this);
        this.handleError = this.handleError.bind(this);
        
        // Set up error handling
        this.setupErrorHandling();
        
        // Initialize first pieces
        try {
            this.generateNextTetromino();
            this.spawnNewTetromino();
            this.updateGhostPiece();
        } catch (error) {
            this.handleError(error, 'constructor');
        }
    }

    /**
     * Start the game
     */
    start() {
        console.log('🎮 === STARTING GAME ENGINE ===');
        
        if (this.isRunning) {
            console.log('⚠️ Game already running, ignoring start request');
            return;
        }
        
        console.log('Setting up game state...');
        this.isRunning = true;
        this.gameState.setPaused(false);
        this.lastUpdateTime = 0; // Will be initialized in gameLoop
        this.dropTimer = 0;
        this.frameCount = 0;
        
        console.log('Game state after setup:', {
            isRunning: this.isRunning,
            isPaused: this.gameState.isPaused,
            isGameOver: this.gameState.isGameOver,
            dropInterval: this.gameState.getDropInterval()
        });
        
        // Ensure we have pieces
        if (!this.currentTetromino) {
            console.log('No current tetromino, generating pieces...');
            this.generateNextTetromino();
            this.spawnNewTetromino();
        }
        
        console.log('Pieces after generation:', {
            current: this.currentTetromino ? `${this.currentTetromino.type} at (${this.currentTetromino.x},${this.currentTetromino.y})` : 'null',
            next: this.nextTetromino ? this.nextTetromino.type : 'null'
        });
        
        // Start the game loop
        console.log('Starting game loop...');
        this.animationFrameId = requestAnimationFrame(this.gameLoop);
        console.log('Game loop started with animation frame ID:', this.animationFrameId);
        console.log('=== GAME ENGINE STARTED ===');
    }

    /**
     * Pause the game
     */
    pause() {
        if (this.gameState.isPaused) {
            return;
        }
        
        this.gameState.setPaused(true);
        
        if (this.animationFrameId) {
            cancelAnimationFrame(this.animationFrameId);
            this.animationFrameId = null;
        }
    }

    /**
     * Resume the game from pause
     */
    resume() {
        if (!this.isRunning || !this.gameState.isPaused) {
            return;
        }
        
        this.gameState.setPaused(false);
        this.lastUpdateTime = performance.now();
        
        // Restart the game loop
        this.animationFrameId = requestAnimationFrame(this.gameLoop);
    }

    /**
     * Reset the game to initial state
     */
    reset() {
        // Stop current game loop
        if (this.animationFrameId) {
            cancelAnimationFrame(this.animationFrameId);
            this.animationFrameId = null;
        }
        
        this.isRunning = false;
        
        // Reset all game components
        this.gameState.reset();
        this.gameBoard.reset();
        
        // Reset timing
        this.lastUpdateTime = 0;
        this.dropTimer = 0;
        
        // Hide game over screen
        if (this.renderer && this.renderer.hideGameOver) {
            this.renderer.hideGameOver();
        }
        
        // Generate new pieces
        this.generateNextTetromino();
        this.spawnNewTetromino();
    }

    /**
     * Main game loop - handles update and render cycles
     * @param {number} currentTime - Current timestamp from requestAnimationFrame
     */
    gameLoop(currentTime) {
        try {
            if (!this.isRunning) {
                console.log('Game loop stopped - not running');
                return;
            }
            
            // Initialize lastUpdateTime if not set
            if (this.lastUpdateTime === 0) {
                this.lastUpdateTime = currentTime;
                console.log('Game loop initialized at time:', currentTime);
                // Skip first frame to avoid huge deltaTime
                this.animationFrameId = requestAnimationFrame(this.gameLoop);
                return;
            }
            
            // Calculate delta time
            const deltaTime = currentTime - this.lastUpdateTime;
            this.lastUpdateTime = currentTime;
            
            // Cap deltaTime to prevent huge jumps (e.g., when tab was inactive)
            const cappedDeltaTime = Math.min(deltaTime, 100); // Max 100ms per frame
            
            this.frameCount = (this.frameCount || 0) + 1;
            
            // Minimal debug logging
            if (this.frameCount === 1) {
                console.log('🎮 Game loop is running successfully');
            }
            
            // Debug every 60 frames (about 1 second) - disabled for clean gameplay
            // if (this.frameCount % 60 === 0) {
            //     console.log('🔄 Game loop active, frame:', this.frameCount);
            // }
            
            // Update game logic (only if not paused)
            if (!this.gameState.isPaused) {
                this.update(cappedDeltaTime);
            } else {
                console.log('Game is paused, skipping update');
            }
            
            // Always render (to show pause screen, etc.)
            this.render(currentTime);
            
            // Update performance metrics
            this.updatePerformanceMetrics(currentTime);
            
            // Continue the loop
            this.animationFrameId = requestAnimationFrame(this.gameLoop);
        } catch (error) {
            console.error('Game loop error:', error);
            this.handleError(error, 'gameLoop');
        }
    }

    /**
     * Update game logic
     * @param {number} deltaTime - Time elapsed since last update in milliseconds
     */
    update(deltaTime) {
        if (this.gameState.isGameOver) {
            console.log('Update skipped: game over');
            return;
        }
        
        if (this.gameState.isPaused) {
            console.log('Update skipped: game paused');
            return;
        }
        
        // Update line clear animation
        this.updateLineClearAnimation(deltaTime);
        
        // Skip game logic updates during line clear animation
        if (this.clearingLines.length > 0) {
            console.log('Update skipped: line clear animation active');
            return;
        }
        
        // Update drop timer
        const oldDropTimer = this.dropTimer;
        this.dropTimer += deltaTime;
        
        // Check if it's time for automatic drop
        const dropInterval = this.gameState.getDropInterval();
        
        // Minimal drop timer logging - disabled for clean gameplay
        // if (this.frameCount % 120 === 0) { // Every 2 seconds
        //     console.log(`Drop progress: ${(this.dropTimer/dropInterval*100).toFixed(1)}%`);
        // }
        
        if (this.dropTimer >= dropInterval) {
            // console.log('⬇️ AUTO DROP TRIGGERED!');
            this.handleAutomaticDrop();
            this.dropTimer = 0;
        }
        
        // Update ghost piece position
        this.updateGhostPiece();
    }

    /**
     * Handle automatic tetromino drop
     */
    handleAutomaticDrop() {
        if (!this.currentTetromino) {
            return;
        }
        
        // Try to move the current tetromino down
        const movedTetromino = this.currentTetromino.moveDown();
        
        if (this.gameBoard.isValidPosition(movedTetromino)) {
            // Move successful
            this.currentTetromino = movedTetromino;
        } else {
            // Cannot move down - lock the piece and spawn new one
            this.lockCurrentTetromino();
        }
    }

    /**
     * Lock the current tetromino in place and handle line clearing
     */
    lockCurrentTetromino() {
        if (!this.currentTetromino) {
            return;
        }
        
        // Place the tetromino on the board
        try {
            this.gameBoard.placeTetromino(this.currentTetromino);
        } catch (error) {
            // If placement fails, it might be game over
            this.checkGameOver();
            return;
        }
        
        // Clear completed lines
        const linesCleared = this.gameBoard.clearLines();
        
        // Update score and level
        if (linesCleared > 0) {
            this.gameState.updateScore(linesCleared);
        }
        
        // Spawn new tetromino
        this.spawnNewTetromino();
        
        // Check for game over condition
        this.checkGameOver();
    }

    /**
     * Spawn a new tetromino at the top of the board
     */
    spawnNewTetromino() {
        // Move next tetromino to current
        this.currentTetromino = this.nextTetromino;
        
        // Generate new next tetromino
        this.generateNextTetromino();
        
        // Position current tetromino at spawn location
        if (this.currentTetromino) {
            // Standard spawn position (center top of board)
            const spawnX = Math.floor(this.config.boardWidth / 2) - 2;
            const spawnY = 0;
            this.currentTetromino = new Tetromino(
                this.currentTetromino.type,
                spawnX,
                spawnY,
                this.currentTetromino.rotation
            );
        }
    }

    /**
     * Generate the next tetromino
     */
    generateNextTetromino() {
        this.nextTetromino = Tetromino.createRandom();
    }

    /**
     * Check if game over condition is met
     */
    checkGameOver() {
        if (!this.currentTetromino) {
            return;
        }
        
        // Check if the newly spawned tetromino collides immediately
        if (!this.gameBoard.isValidPosition(this.currentTetromino)) {
            this.gameState.setGameOver(true);
            this.isRunning = false;
            
            if (this.animationFrameId) {
                cancelAnimationFrame(this.animationFrameId);
                this.animationFrameId = null;
            }
            
            // Show game over screen with final score
            if (this.renderer && this.renderer.showGameOver) {
                this.renderer.showGameOver(this.gameState.score);
            }
        }
    }

    // Move methods are defined later with enhanced functionality

    /**
     * Soft drop - accelerate current tetromino downward
     * @returns {boolean} True if move was successful
     */
    softDrop() {
        if (!this.currentTetromino || this.gameState.isPaused || this.gameState.isGameOver) {
            return false;
        }
        
        const movedTetromino = this.currentTetromino.moveDown();
        if (this.gameBoard.isValidPosition(movedTetromino)) {
            this.currentTetromino = movedTetromino;
            return true;
        }
        return false;
    }

    /**
     * Hard drop - instantly drop tetromino to bottom
     * @returns {number} Number of rows dropped
     */
    hardDrop() {
        if (!this.currentTetromino || this.gameState.isPaused || this.gameState.isGameOver) {
            return 0;
        }
        
        const originalY = this.currentTetromino.y;
        const droppedTetromino = this.gameBoard.getHardDropPosition(this.currentTetromino);
        
        if (droppedTetromino) {
            this.currentTetromino = droppedTetromino;
            this.lockCurrentTetromino();
            return droppedTetromino.y - originalY;
        }
        
        return 0;
    }

    // Rotate method is defined later with enhanced functionality

    /**
     * Rotate current tetromino counter-clockwise
     * @returns {boolean} True if rotation was successful
     */
    rotateCounterClockwise() {
        if (!this.currentTetromino || this.gameState.isPaused || this.gameState.isGameOver) {
            return false;
        }
        
        const rotatedTetromino = this.gameBoard.tryRotate(this.currentTetromino, false);
        if (rotatedTetromino) {
            this.currentTetromino = rotatedTetromino;
            return true;
        }
        return false;
    }

    /**
     * Get current game state
     * @returns {Object} Current game state information
     */
    getGameState() {
        return {
            ...this.gameState.getState(),
            currentTetromino: this.currentTetromino,
            nextTetromino: this.nextTetromino,
            board: this.gameBoard.getBoard(),
            isRunning: this.isRunning
        };
    }

    /**
     * Get the current tetromino
     * @returns {Tetromino|null} Current active tetromino
     */
    getCurrentTetromino() {
        return this.currentTetromino;
    }

    /**
     * Get the next tetromino
     * @returns {Tetromino|null} Next tetromino to spawn
     */
    getNextTetromino() {
        return this.nextTetromino;
    }

    /**
     * Get the game board
     * @returns {GameBoard} Current game board
     */
    getGameBoard() {
        return this.gameBoard;
    }

    /**
     * Check if game is running
     * @returns {boolean} True if game is currently running
     */
    isGameRunning() {
        return this.isRunning;
    }

    /**
     * Check if game is paused
     * @returns {boolean} True if game is paused
     */
    isGamePaused() {
        return this.gameState.isPaused;
    }

    /**
     * Check if game is over
     * @returns {boolean} True if game is over
     */
    isGameOver() {
        return this.gameState.isGameOver;
    }

    /**
     * Get current drop timer value
     * @returns {number} Current drop timer in milliseconds
     */
    getDropTimer() {
        return this.dropTimer;
    }

    /**
     * Reset drop timer (useful for input handling)
     */
    resetDropTimer() {
        this.dropTimer = 0;
    }

    /**
     * Render the current game state
     * @param {number} currentTime - Current timestamp for animations
     */
    render(currentTime) {
        try {
            const renderData = {
                gameBoard: this.gameBoard,
                currentTetromino: this.currentTetromino,
                ghostTetromino: this.ghostTetromino,
                nextTetromino: this.nextTetromino,
                gameState: this.gameState.getState(),
                clearingLines: this.clearingLines,
                animationProgress: this.animationProgress
            };
            
            this.renderer.renderWithAnimations(renderData, currentTime);
        } catch (error) {
            this.handleError(error, 'render');
        }
    }

    /**
     * Update ghost piece position (shows where current piece will land)
     */
    updateGhostPiece() {
        if (!this.currentTetromino) {
            this.ghostTetromino = null;
            return;
        }
        
        try {
            this.ghostTetromino = this.gameBoard.getHardDropPosition(this.currentTetromino);
        } catch (error) {
            this.handleError(error, 'updateGhostPiece');
            this.ghostTetromino = null;
        }
    }

    /**
     * Update line clear animation
     * @param {number} deltaTime - Time elapsed since last update
     */
    updateLineClearAnimation(deltaTime) {
        if (this.clearingLines.length === 0) {
            return;
        }
        
        const elapsed = Date.now() - this.animationStartTime;
        this.animationProgress = Math.min(elapsed / this.lineClearAnimationDuration, 1);
        
        // Animation complete
        if (this.animationProgress >= 1) {
            this.finishLineClear();
        }
    }

    /**
     * Start line clear animation
     * @param {number[]} lineIndices - Array of line indices to clear
     */
    startLineClearAnimation(lineIndices) {
        if (lineIndices.length === 0) {
            return;
        }
        
        this.clearingLines = [...lineIndices];
        this.animationStartTime = Date.now();
        this.animationProgress = 0;
        
        // Add animation to renderer
        if (this.renderer && this.renderer.addLineClearAnimation) {
            this.renderer.addLineClearAnimation(lineIndices);
        }
    }

    /**
     * Finish line clear animation and update game state
     */
    finishLineClear() {
        const linesCleared = this.clearingLines.length;
        
        // Actually remove the lines from the board
        this.gameBoard.removeLines(this.clearingLines);
        
        // Update score and level
        if (linesCleared > 0) {
            this.gameState.updateScore(linesCleared);
        }
        
        // Reset animation state
        this.clearingLines = [];
        this.animationProgress = 0;
        this.animationStartTime = 0;
        
        // Spawn new tetromino after line clear is complete
        this.spawnNewTetromino();
        this.checkGameOver();
    }

    /**
     * Setup error handling for the game engine
     */
    setupErrorHandling() {
        // Handle uncaught errors
        window.addEventListener('error', (event) => {
            this.handleError(event.error, 'uncaught');
        });
        
        // Handle unhandled promise rejections
        window.addEventListener('unhandledrejection', (event) => {
            this.handleError(event.reason, 'unhandledPromise');
        });
    }

    /**
     * Handle errors that occur during game execution
     * @param {Error} error - The error that occurred
     * @param {string} context - Context where the error occurred
     */
    handleError(error, context) {
        this.errorCount++;
        this.lastError = { error, context, timestamp: Date.now() };
        
        console.error(`Tetris Game Error in ${context}:`, error);
        
        // If too many errors, stop the game to prevent infinite loops
        if (this.errorCount >= this.maxErrors) {
            console.error('Too many errors occurred. Resetting error count and continuing.');
            this.errorCount = 0; // Reset error count instead of stopping
            return;
        }
        
        // Try to recover from specific error types
        try {
            this.attemptErrorRecovery(error, context);
        } catch (recoveryError) {
            console.error('Error recovery failed:', recoveryError);
            this.emergencyStop();
        }
    }

    /**
     * Attempt to recover from errors
     * @param {Error} error - The error that occurred
     * @param {string} context - Context where the error occurred
     */
    attemptErrorRecovery(error, context) {
        switch (context) {
            case 'constructor':
                // Critical error during initialization
                throw error;
                
            case 'gameLoop':
                // Try to restart the game loop
                if (this.animationFrameId) {
                    cancelAnimationFrame(this.animationFrameId);
                }
                this.lastUpdateTime = performance.now();
                this.animationFrameId = requestAnimationFrame(this.gameLoop);
                break;
                
            case 'render':
                // Clear renderer state and try to continue
                if (this.renderer && this.renderer.clearAnimations) {
                    this.renderer.clearAnimations();
                }
                break;
                
            case 'updateGhostPiece':
                // Disable ghost piece temporarily
                this.ghostTetromino = null;
                break;
                
            case 'spawnNewTetromino':
                // Try to generate a new piece
                this.generateNextTetromino();
                this.currentTetromino = this.nextTetromino;
                this.generateNextTetromino();
                break;
                
            default:
                // For unknown contexts, try to continue
                console.warn(`Unknown error context: ${context}`);
        }
    }

    /**
     * Emergency stop - halt all game operations
     */
    emergencyStop() {
        this.isRunning = false;
        
        if (this.animationFrameId) {
            cancelAnimationFrame(this.animationFrameId);
            this.animationFrameId = null;
        }
        
        // Show error message to user
        this.showErrorMessage();
    }

    /**
     * Show error message to user
     */
    showErrorMessage() {
        try {
            const gameOverScreen = document.getElementById('gameOverScreen');
            if (gameOverScreen) {
                const errorMessage = document.createElement('div');
                errorMessage.className = 'error-message';
                errorMessage.innerHTML = `
                    <h3>游戏遇到错误</h3>
                    <p>游戏遇到了意外错误，请刷新页面重试。</p>
                    <button onclick="location.reload()">刷新页面</button>
                `;
                gameOverScreen.appendChild(errorMessage);
                gameOverScreen.classList.add('show');
            }
        } catch (error) {
            // If we can't even show the error message, just log it
            console.error('Failed to show error message:', error);
        }
    }

    /**
     * Get error statistics
     * @returns {Object} Error statistics
     */
    getErrorStats() {
        return {
            errorCount: this.errorCount,
            lastError: this.lastError,
            maxErrors: this.maxErrors
        };
    }

    /**
     * Reset error count (useful for testing)
     */
    resetErrorCount() {
        this.errorCount = 0;
        this.lastError = null;
    }

    /**
     * Enhanced lock current tetromino with animation support
     */
    lockCurrentTetromino() {
        if (!this.currentTetromino) {
            return;
        }
        
        try {
            // Place the tetromino on the board
            this.gameBoard.placeTetromino(this.currentTetromino);
            
            // Add placement effect
            if (this.renderer && this.renderer.addPiecePlacementEffect) {
                this.renderer.addPiecePlacementEffect(this.currentTetromino);
            }
            
            // Check for completed lines
            const completedLines = this.gameBoard.getCompletedLines();
            
            if (completedLines.length > 0) {
                // Start line clear animation
                this.startLineClearAnimation(completedLines);
            } else {
                // No lines to clear, spawn new tetromino immediately
                this.spawnNewTetromino();
                this.checkGameOver();
            }
            
        } catch (error) {
            this.handleError(error, 'lockCurrentTetromino');
        }
    }

    /**
     * Enhanced move methods with visual feedback
     */
    moveLeft() {
        const result = this.baseMoveLeft();
        if (result && this.renderer && this.renderer.addTouchFeedback) {
            this.renderer.addTouchFeedback('move', 50, 50);
        }
        return result;
    }

    moveRight() {
        const result = this.baseMoveRight();
        if (result && this.renderer && this.renderer.addTouchFeedback) {
            this.renderer.addTouchFeedback('move', 250, 50);
        }
        return result;
    }

    rotate() {
        const result = this.baseRotate();
        if (result && this.renderer && this.renderer.addTouchFeedback) {
            this.renderer.addTouchFeedback('rotate', 150, 100);
        }
        return result;
    }

    hardDrop() {
        const result = this.baseHardDrop();
        if (result > 0 && this.renderer && this.renderer.addTouchFeedback) {
            this.renderer.addTouchFeedback('drop', 150, 200);
        }
        return result;
    }

    /**
     * Base movement methods (fallback implementations)
     */
    baseMoveLeft() {
        if (!this.currentTetromino || this.gameState.isPaused || this.gameState.isGameOver) {
            return false;
        }
        
        const movedTetromino = this.currentTetromino.moveLeft();
        if (this.gameBoard.isValidPosition(movedTetromino)) {
            this.currentTetromino = movedTetromino;
            this.updateGhostPiece();
            return true;
        }
        return false;
    }

    baseMoveRight() {
        if (!this.currentTetromino || this.gameState.isPaused || this.gameState.isGameOver) {
            return false;
        }
        
        const movedTetromino = this.currentTetromino.moveRight();
        if (this.gameBoard.isValidPosition(movedTetromino)) {
            this.currentTetromino = movedTetromino;
            this.updateGhostPiece();
            return true;
        }
        return false;
    }

    baseRotate() {
        if (!this.currentTetromino || this.gameState.isPaused || this.gameState.isGameOver) {
            return false;
        }
        
        const rotatedTetromino = this.gameBoard.tryRotate(this.currentTetromino, true);
        if (rotatedTetromino) {
            this.currentTetromino = rotatedTetromino;
            this.updateGhostPiece();
            return true;
        }
        return false;
    }

    baseHardDrop() {
        if (!this.currentTetromino || this.gameState.isPaused || this.gameState.isGameOver) {
            return 0;
        }
        
        const originalY = this.currentTetromino.y;
        const droppedTetromino = this.gameBoard.getHardDropPosition(this.currentTetromino);
        
        if (droppedTetromino) {
            this.currentTetromino = droppedTetromino;
            this.lockCurrentTetromino();
            return droppedTetromino.y - originalY;
        }
        
        return 0;
    }

    /**
     * Get renderer instance
     * @returns {Renderer} The renderer instance
     */
    getRenderer() {
        return this.renderer;
    }

    /**
     * Check if line clear animation is active
     * @returns {boolean} True if animation is active
     */
    isLineClearAnimationActive() {
        return this.clearingLines.length > 0;
    }

    /**
     * Get current animation progress
     * @returns {number} Animation progress (0-1)
     */
    getAnimationProgress() {
        return this.animationProgress;
    }

    /**
     * Update performance metrics
     * @param {number} currentTime - Current timestamp
     */
    updatePerformanceMetrics(currentTime) {
        this.performanceMetrics.frameCount++;
        
        // Calculate FPS every second
        if (currentTime - this.performanceMetrics.lastFPSCheck >= 1000) {
            this.performanceMetrics.currentFPS = this.performanceMetrics.frameCount;
            this.performanceMetrics.frameCount = 0;
            this.performanceMetrics.lastFPSCheck = currentTime;
            
            // Calculate average frame time
            this.performanceMetrics.averageFrameTime = 1000 / this.performanceMetrics.currentFPS;
            
            // Monitor memory usage if available
            if (performance.memory) {
                this.performanceMetrics.memoryUsage = performance.memory.usedJSHeapSize / 1024 / 1024; // MB
            }
        }
    }

    /**
     * Get performance metrics
     * @returns {Object} Current performance metrics
     */
    getPerformanceMetrics() {
        return {
            ...this.performanceMetrics,
            isRunning: this.isRunning,
            isPaused: this.gameState.isPaused,
            errorCount: this.errorCount,
            renderer: this.renderer ? this.renderer.getPerformanceMetrics() : null
        };
    }

    /**
     * Optimize game performance
     */
    optimizePerformance() {
        // Enable renderer performance mode
        if (this.renderer) {
            this.renderer.setPerformanceMode(true);
        }
        
        // Reduce animation complexity if FPS is low
        if (this.performanceMetrics.currentFPS < 30) {
            this.lineClearAnimationDuration = 150; // Shorter animations
            if (this.renderer) {
                this.renderer.setRenderThrottle(33); // 30 FPS
            }
        }
        
        // Clean up old animations and effects
        this.cleanupAnimations();
    }

    /**
     * Clean up old animations and effects to prevent memory leaks
     */
    cleanupAnimations() {
        if (this.renderer) {
            // Remove completed animations
            const currentTime = Date.now();
            this.renderer.animations = this.renderer.animations.filter(
                animation => currentTime - animation.startTime < animation.duration * 2
            );
            
            this.renderer.effects = this.renderer.effects.filter(
                effect => currentTime - effect.startTime < effect.duration * 2
            );
        }
    }

    /**
     * Check for memory leaks and clean up
     */
    checkMemoryUsage() {
        if (!performance.memory) {
            return;
        }
        
        const memoryUsage = performance.memory.usedJSHeapSize / 1024 / 1024; // MB
        
        // If memory usage is high, trigger cleanup
        if (memoryUsage > 100) { // 100MB threshold
            this.cleanupAnimations();
            
            // Force garbage collection if available
            if (window.gc) {
                window.gc();
            }
        }
    }

    /**
     * Enable debug mode for performance monitoring
     * @param {boolean} enabled - Whether to enable debug mode
     */
    setDebugMode(enabled) {
        this.debugMode = enabled;
        
        if (enabled) {
            // Log performance metrics every 5 seconds
            this.debugInterval = setInterval(() => {
                console.log('Performance Metrics:', this.getPerformanceMetrics());
            }, 5000);
        } else if (this.debugInterval) {
            clearInterval(this.debugInterval);
            this.debugInterval = null;
        }
    }

    /**
     * Get detailed system information for debugging
     * @returns {Object} System information
     */
    getSystemInfo() {
        return {
            userAgent: navigator.userAgent,
            platform: navigator.platform,
            language: navigator.language,
            cookieEnabled: navigator.cookieEnabled,
            onLine: navigator.onLine,
            screen: {
                width: screen.width,
                height: screen.height,
                colorDepth: screen.colorDepth,
                pixelDepth: screen.pixelDepth
            },
            window: {
                innerWidth: window.innerWidth,
                innerHeight: window.innerHeight,
                devicePixelRatio: window.devicePixelRatio || 1
            },
            canvas: this.canvas ? {
                width: this.canvas.width,
                height: this.canvas.height,
                clientWidth: this.canvas.clientWidth,
                clientHeight: this.canvas.clientHeight
            } : null,
            webGL: this.checkWebGLSupport()
        };
    }

    /**
     * Check WebGL support for potential hardware acceleration
     * @returns {boolean} Whether WebGL is supported
     */
    checkWebGLSupport() {
        try {
            const canvas = document.createElement('canvas');
            return !!(canvas.getContext('webgl') || canvas.getContext('experimental-webgl'));
        } catch (e) {
            return false;
        }
    }

    /**
     * Detect mobile device for performance adjustments
     * @returns {boolean} Whether running on mobile device
     */
    isMobileDevice() {
        return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ||
               ('ontouchstart' in window) ||
               (navigator.maxTouchPoints > 0);
    }

    /**
     * Adjust performance settings based on device capabilities
     */
    adjustForDevice() {
        const isMobile = this.isMobileDevice();
        const hasWebGL = this.checkWebGLSupport();
        
        if (isMobile) {
            // Reduce performance demands on mobile
            this.lineClearAnimationDuration = 200;
            if (this.renderer) {
                this.renderer.setRenderThrottle(33); // 30 FPS on mobile
                this.renderer.setPerformanceMode(true);
            }
        }
        
        if (!hasWebGL) {
            // Reduce visual effects if no hardware acceleration
            if (this.renderer) {
                this.renderer.setPerformanceMode(true);
            }
        }
    }
}