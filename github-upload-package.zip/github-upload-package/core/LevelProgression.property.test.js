import fc from 'fast-check';
import { ScoringSystem } from '../../src/core/ScoringSystem.js';
import { GameState } from '../../src/core/GameState.js';
import { GameConfig } from '../../src/config/GameConfig.js';

describe('Level Progression Property Tests', () => {
    let scoringSystem;
    let gameState;
    let config;

    beforeEach(() => {
        config = new GameConfig();
        scoringSystem = new ScoringSystem(config);
        gameState = new GameState(config);
    });

    /**
     * **Feature: tetris-game, Property 9: 等级提升机制**
     * **Validates: Requirements 2.4, 3.5**
     * 
     * For any number of lines cleared that reaches the level threshold,
     * the system should increase the game level and correspondingly increase drop speed
     */
    test('Property 9: Level progression mechanism', () => {
        fc.assert(fc.property(
            fc.integer({ min: 0, max: 200 }), // totalLines
            (totalLines) => {
                const level = scoringSystem.calculateLevel(totalLines);
                
                // Level should be at least 1
                expect(level).toBeGreaterThanOrEqual(1);
                
                // Level should be calculated correctly: floor(lines/10) + 1
                const expectedLevel = Math.floor(totalLines / 10) + 1;
                expect(level).toBe(expectedLevel);
                
                // Level should increase monotonically with lines
                if (totalLines >= 10) {
                    const prevLevel = scoringSystem.calculateLevel(totalLines - 10);
                    expect(level).toBeGreaterThanOrEqual(prevLevel);
                }
                
                // Drop interval should decrease as level increases
                const dropInterval = scoringSystem.calculateDropInterval(level);
                expect(dropInterval).toBeGreaterThanOrEqual(50); // Minimum interval
                
                if (level > 1) {
                    const prevDropInterval = scoringSystem.calculateDropInterval(level - 1);
                    expect(dropInterval).toBeLessThan(prevDropInterval);
                }
                
                // Verify drop interval calculation
                const expectedInterval = Math.max(
                    50,
                    Math.floor(config.dropInterval * Math.pow(config.levelSpeedMultiplier, level - 1))
                );
                expect(dropInterval).toBe(expectedInterval);
            }
        ), { numRuns: 100 });
    });

    /**
     * Property: Level progression should be consistent in GameState
     */
    test('Property: GameState level progression consistency', () => {
        fc.assert(fc.property(
            fc.array(fc.integer({ min: 1, max: 4 }), { minLength: 1, maxLength: 50 }), // sequence of line clears
            (lineClearSequence) => {
                gameState.reset();
                let totalLines = 0;
                let previousLevel = 1;
                
                for (const linesCleared of lineClearSequence) {
                    const result = gameState.updateScore(linesCleared);
                    totalLines += linesCleared;
                    
                    // Level should match expected calculation
                    const expectedLevel = Math.floor(totalLines / 10) + 1;
                    expect(gameState.level).toBe(expectedLevel);
                    
                    // Level should never decrease
                    expect(gameState.level).toBeGreaterThanOrEqual(previousLevel);
                    
                    // Level up flag should be accurate
                    const shouldLevelUp = expectedLevel > previousLevel;
                    expect(result.levelUp).toBe(shouldLevelUp);
                    
                    previousLevel = gameState.level;
                }
                
                // Final state should be consistent
                expect(gameState.lines).toBe(totalLines);
                expect(gameState.level).toBe(Math.floor(totalLines / 10) + 1);
            }
        ), { numRuns: 100 });
    });

    /**
     * Property: Level thresholds should be exact
     */
    test('Property: Level threshold exactness', () => {
        fc.assert(fc.property(
            fc.integer({ min: 1, max: 20 }), // targetLevel
            (targetLevel) => {
                // Lines needed for this level
                const linesForLevel = (targetLevel - 1) * 10;
                
                // One line before threshold should be previous level
                if (linesForLevel > 0) {
                    const levelBefore = scoringSystem.calculateLevel(linesForLevel - 1);
                    expect(levelBefore).toBe(targetLevel - 1);
                }
                
                // Exactly at threshold should be target level
                const levelAt = scoringSystem.calculateLevel(linesForLevel);
                expect(levelAt).toBe(targetLevel);
                
                // One line after threshold should still be target level
                const levelAfter = scoringSystem.calculateLevel(linesForLevel + 1);
                expect(levelAfter).toBe(targetLevel);
            }
        ), { numRuns: 100 });
    });

    /**
     * Property: Drop speed progression should be exponential
     */
    test('Property: Drop speed exponential progression', () => {
        fc.assert(fc.property(
            fc.integer({ min: 1, max: 15 }), // level
            (level) => {
                const dropInterval = scoringSystem.calculateDropInterval(level);
                
                // Should never go below minimum
                expect(dropInterval).toBeGreaterThanOrEqual(50);
                
                // Should follow exponential decay formula
                const expectedInterval = Math.max(
                    50,
                    Math.floor(config.dropInterval * Math.pow(config.levelSpeedMultiplier, level - 1))
                );
                expect(dropInterval).toBe(expectedInterval);
                
                // Higher levels should have faster drop (lower interval)
                if (level > 1) {
                    const prevInterval = scoringSystem.calculateDropInterval(level - 1);
                    expect(dropInterval).toBeLessThanOrEqual(prevInterval);
                }
            }
        ), { numRuns: 100 });
    });

    /**
     * Property: Level progress calculation should be accurate
     */
    test('Property: Level progress calculation accuracy', () => {
        fc.assert(fc.property(
            fc.integer({ min: 0, max: 150 }), // totalLines
            (totalLines) => {
                const currentLevel = scoringSystem.calculateLevel(totalLines);
                const progress = scoringSystem.getLevelProgress(totalLines, currentLevel);
                
                // Progress should be within valid range
                expect(progress.progressLines).toBeGreaterThanOrEqual(0);
                expect(progress.progressLines).toBeLessThan(10);
                expect(progress.neededLines).toBeGreaterThanOrEqual(0);
                expect(progress.neededLines).toBeLessThanOrEqual(10);
                expect(progress.totalNeeded).toBe(10);
                expect(progress.percentage).toBeGreaterThanOrEqual(0);
                expect(progress.percentage).toBeLessThanOrEqual(100);
                
                // Progress + needed should equal total needed
                expect(progress.progressLines + progress.neededLines).toBe(10);
                
                // Percentage should match progress
                const expectedPercentage = (progress.progressLines / 10) * 100;
                expect(progress.percentage).toBe(expectedPercentage);
            }
        ), { numRuns: 100 });
    });
});