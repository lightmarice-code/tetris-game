/**
 * Property-based tests for Touch Input Equivalency
 * Using fast-check for property testing
 */

import fc from 'fast-check';
import { InputManager } from '../../src/core/InputManager.js';
import { GameEngine } from '../../src/core/GameEngine.js';
import { GameConfig } from '../../src/config/GameConfig.js';

// Mock canvas for testing
const createMockCanvas = () => ({
    getBoundingClientRect: () => ({
        left: 0,
        top: 0,
        width: 300,
        height: 600
    }),
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    getContext: jest.fn(() => ({
        clearRect: jest.fn(),
        fillRect: jest.fn(),
        strokeRect: jest.fn(),
        fillText: jest.fn(),
        save: jest.fn(),
        restore: jest.fn(),
        beginPath: jest.fn(),
        moveTo: jest.fn(),
        lineTo: jest.fn(),
        stroke: jest.fn(),
        arc: jest.fn()
    })),
    width: 300,
    height: 600
});

// Mock touch event
const createMockTouchEvent = (clientX, clientY, type = 'touchend') => ({
    type,
    preventDefault: jest.fn(),
    touches: type === 'touchend' ? [] : [{
        clientX,
        clientY
    }],
    changedTouches: [{
        clientX,
        clientY
    }]
});

describe('Touch Input Equivalency Property Tests', () => {
    let gameEngine;
    let inputManager;
    let mockCanvas;

    beforeEach(() => {
        mockCanvas = createMockCanvas();
        const config = new GameConfig();
        gameEngine = new GameEngine(mockCanvas, config);
        
        // Mock the game engine methods to track calls
        gameEngine.moveLeft = jest.fn().mockReturnValue(true);
        gameEngine.moveRight = jest.fn().mockReturnValue(true);
        gameEngine.softDrop = jest.fn().mockReturnValue(true);
        gameEngine.hardDrop = jest.fn().mockReturnValue(5);
        gameEngine.rotate = jest.fn().mockReturnValue(true);
        gameEngine.rotateCounterClockwise = jest.fn().mockReturnValue(true);
        gameEngine.pause = jest.fn();
        gameEngine.resume = jest.fn();
        gameEngine.reset = jest.fn();
        gameEngine.start = jest.fn();
        gameEngine.resetDropTimer = jest.fn();
        gameEngine.isGameRunning = jest.fn().mockReturnValue(true);
        gameEngine.isGamePaused = jest.fn().mockReturnValue(false);
        gameEngine.isGameOver = jest.fn().mockReturnValue(false);
        
        inputManager = new InputManager(gameEngine);
    });

    afterEach(() => {
        if (inputManager) {
            inputManager.destroy();
        }
    });

    /**
     * **Feature: tetris-game, Property 17: 触摸输入等效性**
     * **Validates: Requirements 7.1, 7.2, 7.3, 7.4**
     * 
     * For any touch input operation, its effect should be completely equivalent to the corresponding keyboard input operation
     */
    describe('Property 17: Touch Input Equivalency', () => {

        test('left swipe should be equivalent to left arrow key', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 200, max: 300 }), // start x in right zone (swipe left from right)
                    fc.integer({ min: 0, max: 600 }), // start y
                    fc.integer({ min: 50, max: 200 }), // swipe distance
                    (startX, startY, swipeDistance) => {
                        // Reset mocks
                        gameEngine.moveLeft.mockClear();
                        
                        // Simulate left swipe (start in right zone, swipe left)
                        const endX = startX - swipeDistance;
                        
                        // Set up touch state properly
                        inputManager.touchStartPos = { x: startX, y: startY };
                        inputManager.touchCurrentPos = { x: endX, y: startY };
                        inputManager.touchStartTime = performance.now();
                        inputManager.isTouching = true;
                        
                        // Process the swipe
                        const deltaX = endX - startX;
                        const deltaY = 0;
                        const distance = Math.abs(deltaX);
                        const duration = 100; // Within swipe time threshold
                        
                        inputManager.processTouch(deltaX, deltaY, distance, duration);
                        
                        // Reset mocks to count only keyboard input
                        const touchCalls = gameEngine.moveLeft.mock.calls.length;
                        gameEngine.moveLeft.mockClear();
                        
                        // Simulate keyboard left arrow
                        inputManager.handleInput(inputManager.INPUT_ACTIONS.MOVE_LEFT);
                        const keyboardCalls = gameEngine.moveLeft.mock.calls.length;
                        
                        // Both should call moveLeft exactly once
                        expect(touchCalls).toBe(1);
                        expect(keyboardCalls).toBe(1);
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('right swipe should be equivalent to right arrow key', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 0, max: 100 }), // start x in left zone (swipe right from left)
                    fc.integer({ min: 0, max: 600 }), // start y
                    fc.integer({ min: 50, max: 200 }), // swipe distance
                    (startX, startY, swipeDistance) => {
                        // Reset mocks
                        gameEngine.moveRight.mockClear();
                        
                        // Simulate right swipe (start in left zone, swipe right)
                        const endX = startX + swipeDistance;
                        
                        // Set up touch state properly
                        inputManager.touchStartPos = { x: startX, y: startY };
                        inputManager.touchCurrentPos = { x: endX, y: startY };
                        inputManager.touchStartTime = performance.now();
                        inputManager.isTouching = true;
                        
                        // Process the swipe
                        const deltaX = endX - startX;
                        const deltaY = 0;
                        const distance = Math.abs(deltaX);
                        const duration = 100; // Within swipe time threshold
                        
                        inputManager.processTouch(deltaX, deltaY, distance, duration);
                        
                        // Reset mocks to count only keyboard input
                        const touchCalls = gameEngine.moveRight.mock.calls.length;
                        gameEngine.moveRight.mockClear();
                        
                        // Simulate keyboard right arrow
                        inputManager.handleInput(inputManager.INPUT_ACTIONS.MOVE_RIGHT);
                        const keyboardCalls = gameEngine.moveRight.mock.calls.length;
                        
                        // Both should call moveRight exactly once
                        expect(touchCalls).toBe(1);
                        expect(keyboardCalls).toBe(1);
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('downward swipe should be equivalent to down arrow key', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 100, max: 200 }), // start x in center zone
                    fc.integer({ min: 0, max: 300 }), // start y
                    fc.integer({ min: 50, max: 200 }), // swipe distance
                    (startX, startY, swipeDistance) => {
                        // Reset mocks
                        gameEngine.softDrop.mockClear();
                        gameEngine.resetDropTimer.mockClear();
                        
                        // Simulate downward swipe
                        const endY = startY + swipeDistance;
                        
                        // Set up touch state properly
                        inputManager.touchStartPos = { x: startX, y: startY };
                        inputManager.touchCurrentPos = { x: startX, y: endY };
                        inputManager.touchStartTime = performance.now();
                        inputManager.isTouching = true;
                        
                        // Process the swipe
                        const deltaX = 0;
                        const deltaY = endY - startY;
                        const distance = Math.abs(deltaY);
                        const duration = 100; // Within swipe time threshold
                        
                        inputManager.processTouch(deltaX, deltaY, distance, duration);
                        
                        // Count touch calls
                        const touchSoftDropCalls = gameEngine.softDrop.mock.calls.length;
                        const touchResetCalls = gameEngine.resetDropTimer.mock.calls.length;
                        
                        // Reset mocks to count only keyboard input
                        gameEngine.softDrop.mockClear();
                        gameEngine.resetDropTimer.mockClear();
                        
                        // Simulate keyboard down arrow
                        inputManager.handleInput(inputManager.INPUT_ACTIONS.SOFT_DROP);
                        
                        const keyboardSoftDropCalls = gameEngine.softDrop.mock.calls.length;
                        const keyboardResetCalls = gameEngine.resetDropTimer.mock.calls.length;
                        
                        // Both should call softDrop exactly once
                        expect(touchSoftDropCalls).toBe(1);
                        expect(keyboardSoftDropCalls).toBe(1);
                        // Both should reset drop timer
                        expect(touchResetCalls).toBe(1);
                        expect(keyboardResetCalls).toBe(1);
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('tap in rotate zone should be equivalent to up arrow key', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 101, max: 199 }), // x in center zone (avoid boundary)
                    fc.integer({ min: 1, max: 149 }), // y in rotate zone (avoid boundary)
                    (tapX, tapY) => {
                        // Reset all state between iterations
                        gameEngine.rotate.mockClear();
                        inputManager.lastKeyTime.clear();
                        inputManager.touchStartPos = null;
                        inputManager.touchCurrentPos = null;
                        inputManager.isTouching = false;
                        
                        // Ensure touch zones are properly initialized
                        inputManager.updateTouchZones();
                        
                        // Simulate complete touch event sequence for tap
                        const tapPosition = { x: tapX, y: tapY };
                        
                        // Simulate touchstart
                        inputManager.touchStartPos = tapPosition;
                        inputManager.touchCurrentPos = tapPosition;
                        inputManager.touchStartTime = performance.now();
                        inputManager.isTouching = true;
                        
                        // Simulate touchend with minimal movement (tap)
                        const touchDuration = 50;
                        const deltaX = 0;
                        const deltaY = 0;
                        const distance = 0;
                        
                        // Call processTouch as it would be called from handleTouchEnd
                        inputManager.processTouch(deltaX, deltaY, distance, touchDuration);
                        
                        // Clean up touch state
                        inputManager.isTouching = false;
                        inputManager.touchStartPos = null;
                        inputManager.touchCurrentPos = null;
                        
                        // Count touch calls
                        const touchCalls = gameEngine.rotate.mock.calls.length;
                        
                        // Reset mocks to count only keyboard input
                        gameEngine.rotate.mockClear();
                        
                        // Simulate keyboard up arrow
                        inputManager.handleInput(inputManager.INPUT_ACTIONS.ROTATE_CW);
                        const keyboardCalls = gameEngine.rotate.mock.calls.length;
                        
                        // Both should call rotate exactly once (tap is in rotate zone)
                        expect(touchCalls).toBe(1);
                        expect(keyboardCalls).toBe(1);
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('upward swipe should be equivalent to space key (hard drop)', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 101, max: 199 }), // start x in center zone (avoid boundary)
                    fc.integer({ min: 200, max: 500 }), // start y
                    fc.integer({ min: 50, max: 150 }), // swipe distance (ensure it's above threshold)
                    (startX, startY, swipeDistance) => {
                        // Reset all state between iterations
                        gameEngine.hardDrop.mockClear();
                        inputManager.lastKeyTime.clear();
                        inputManager.touchStartPos = null;
                        inputManager.touchCurrentPos = null;
                        inputManager.isTouching = false;
                        
                        // Ensure touch zones are properly initialized
                        inputManager.updateTouchZones();
                        
                        // Simulate complete touch event sequence for upward swipe
                        const endY = startY - swipeDistance;
                        const startPosition = { x: startX, y: startY };
                        const endPosition = { x: startX, y: endY };
                        
                        // Simulate touchstart
                        inputManager.touchStartPos = startPosition;
                        inputManager.touchCurrentPos = endPosition;
                        inputManager.touchStartTime = performance.now();
                        inputManager.isTouching = true;
                        
                        // Simulate touchend with upward movement (swipe)
                        const touchDuration = 100; // Within swipe time threshold
                        const deltaX = 0;
                        const deltaY = endY - startY; // Negative for upward
                        const distance = Math.abs(deltaY);
                        
                        // Call processTouch as it would be called from handleTouchEnd
                        inputManager.processTouch(deltaX, deltaY, distance, touchDuration);
                        
                        // Clean up touch state
                        inputManager.isTouching = false;
                        inputManager.touchStartPos = null;
                        inputManager.touchCurrentPos = null;
                        
                        // Count touch calls
                        const touchCalls = gameEngine.hardDrop.mock.calls.length;
                        
                        // Reset mocks to count only keyboard input
                        gameEngine.hardDrop.mockClear();
                        
                        // Simulate keyboard space key
                        inputManager.handleInput(inputManager.INPUT_ACTIONS.HARD_DROP);
                        const keyboardCalls = gameEngine.hardDrop.mock.calls.length;
                        
                        // Both should call hardDrop exactly once (upward swipe should trigger hard drop)
                        expect(touchCalls).toBe(1);
                        expect(keyboardCalls).toBe(1);
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('touch gesture timing should match keyboard input timing', () => {
            fc.assert(
                fc.property(
                    fc.constantFrom('MOVE_LEFT', 'MOVE_RIGHT', 'SOFT_DROP', 'ROTATE_CW', 'HARD_DROP'),
                    (actionName) => {
                        const action = inputManager.INPUT_ACTIONS[actionName];
                        
                        // Clear any previous timing data
                        inputManager.lastKeyTime.clear();
                        
                        // Record timing for keyboard input
                        const keyboardStartTime = performance.now();
                        inputManager.executeAction(action);
                        const keyboardEndTime = performance.now();
                        const keyboardDuration = keyboardEndTime - keyboardStartTime;
                        
                        // Clear timing data again
                        inputManager.lastKeyTime.clear();
                        
                        // Record timing for touch input (simulate equivalent touch)
                        const touchStartTime = performance.now();
                        inputManager.handleInput(action);
                        const touchEndTime = performance.now();
                        const touchDuration = touchEndTime - touchStartTime;
                        
                        // Both should execute in similar timeframes (within reasonable tolerance)
                        const timeDifference = Math.abs(touchDuration - keyboardDuration);
                        expect(timeDifference).toBeLessThan(10); // 10ms tolerance
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('touch input debouncing should match keyboard debouncing', () => {
            fc.assert(
                fc.property(
                    fc.constantFrom('ROTATE_CW', 'HARD_DROP'), // Non-repeatable actions
                    fc.integer({ min: 1, max: 5 }), // Number of rapid inputs (reduced to avoid timing issues)
                    (actionName, rapidInputs) => {
                        const action = inputManager.INPUT_ACTIONS[actionName];
                        const mockMethod = actionName === 'ROTATE_CW' ? gameEngine.rotate : gameEngine.hardDrop;
                        
                        // Clear mocks and timing
                        mockMethod.mockClear();
                        inputManager.lastKeyTime.clear();
                        
                        // Simulate rapid keyboard inputs with executeAction (includes debouncing)
                        for (let i = 0; i < rapidInputs; i++) {
                            inputManager.executeAction(action);
                        }
                        const keyboardCalls = mockMethod.mock.calls.length;
                        
                        // Clear mocks and timing
                        mockMethod.mockClear();
                        inputManager.lastKeyTime.clear();
                        
                        // Simulate rapid touch inputs with executeAction (same debouncing logic)
                        for (let i = 0; i < rapidInputs; i++) {
                            inputManager.executeAction(action);
                        }
                        const touchCalls = mockMethod.mock.calls.length;
                        
                        // Both should be debounced equally since they use the same executeAction method
                        expect(touchCalls).toBe(keyboardCalls);
                    }
                ),
                { numRuns: 100 }
            );
        });
    });
});