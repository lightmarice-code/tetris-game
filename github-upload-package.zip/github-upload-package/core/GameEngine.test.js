import { GameEngine } from '../../src/core/GameEngine.js';
import { GameConfig } from '../../src/config/GameConfig.js';

describe('GameEngine', () => {
  let canvas, config, gameEngine;

  beforeEach(() => {
    // Create mock canvas
    canvas = document.createElement('canvas');
    canvas.width = 300;
    canvas.height = 600;
    
    config = new GameConfig();
    gameEngine = new GameEngine(canvas, config);
  });

  test('should initialize with correct properties', () => {
    expect(gameEngine.canvas).toBe(canvas);
    expect(gameEngine.config).toBe(config);
    expect(gameEngine.isGameRunning()).toBe(false);
    expect(gameEngine.isGamePaused()).toBe(false);
    expect(gameEngine.lastUpdateTime).toBe(0);
  });

  test('should start the game', () => {
    gameEngine.start();
    expect(gameEngine.isGameRunning()).toBe(true);
  });

  test('should pause and resume the game', () => {
    gameEngine.start();
    gameEngine.pause();
    expect(gameEngine.isGamePaused()).toBe(true);
    
    gameEngine.resume();
    expect(gameEngine.isGamePaused()).toBe(false);
  });

  test('should reset the game state', () => {
    gameEngine.start();
    gameEngine.pause();
    gameEngine.lastUpdateTime = 1000;
    
    gameEngine.reset();
    
    expect(gameEngine.isGameRunning()).toBe(false);
    expect(gameEngine.isGamePaused()).toBe(false);
    expect(gameEngine.lastUpdateTime).toBe(0);
  });
});