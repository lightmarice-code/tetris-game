/**
 * CollisionDetector class for handling all collision detection logic
 * Includes boundary collision, piece collision, and SRS wall kick system
 */

export class CollisionDetector {
    /**
     * Create a collision detector
     * @param {GameBoard} gameBoard - The game board to check collisions against
     */
    constructor(gameBoard) {
        this.gameBoard = gameBoard;
    }

    /**
     * Check if a tetromino position is valid (no collisions)
     * @param {Tetromino} tetromino - The tetromino to check
     * @returns {boolean} True if position is valid
     */
    isValidPosition(tetromino) {
        return this.gameBoard.isValidPosition(tetromino);
    }

    /**
     * Check for boundary collision (walls and floor)
     * @param {Tetromino} tetromino - The tetromino to check
     * @returns {boolean} True if tetromino collides with boundaries
     */
    hasBoundaryCollision(tetromino) {
        const blocks = tetromino.getBlocks();
        
        for (const block of blocks) {
            // Check left and right walls
            if (block.x < 0 || block.x >= this.gameBoard.width) {
                return true;
            }
            
            // Check floor
            if (block.y >= this.gameBoard.height) {
                return true;
            }
            
            // Check ceiling (for spawn collision)
            if (block.y < 0) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * Check for collision with placed pieces
     * @param {Tetromino} tetromino - The tetromino to check
     * @returns {boolean} True if tetromino collides with placed pieces
     */
    hasPieceCollision(tetromino) {
        const blocks = tetromino.getBlocks();
        
        for (const block of blocks) {
            // Skip blocks that are above the board (during spawn)
            if (block.y < 0) {
                continue;
            }
            
            // Check if position is within bounds
            if (!this.gameBoard.isInBounds(block.x, block.y)) {
                continue;
            }
            
            // Check if cell is occupied
            if (this.gameBoard.getCell(block.x, block.y) !== 0) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * Check if a move is valid (no collision after move)
     * @param {Tetromino} tetromino - The original tetromino
     * @param {number} dx - Horizontal movement
     * @param {number} dy - Vertical movement
     * @returns {boolean} True if move is valid
     */
    canMove(tetromino, dx, dy) {
        const movedTetromino = tetromino.move(dx, dy);
        return this.isValidPosition(movedTetromino);
    }

    /**
     * Check if a rotation is valid using SRS wall kick system
     * @param {Tetromino} tetromino - The tetromino to rotate
     * @param {boolean} clockwise - Direction of rotation (true for clockwise)
     * @returns {Tetromino|null} New rotated tetromino if successful, null if impossible
     */
    tryRotateWithKicks(tetromino, clockwise = true) {
        const newRotation = clockwise ? 
            (tetromino.rotation + 1) % 4 : 
            (tetromino.rotation + 3) % 4;
        
        // Try the basic rotation first (no kick)
        let candidate = new (tetromino.constructor)(
            tetromino.type, 
            tetromino.x, 
            tetromino.y, 
            newRotation
        );
        
        if (this.isValidPosition(candidate)) {
            return candidate;
        }

        // If basic rotation fails, try SRS kick tests
        const kickTests = this.getSRSKickTests(tetromino, clockwise);
        
        for (const [dx, dy] of kickTests) {
            candidate = new (tetromino.constructor)(
                tetromino.type, 
                tetromino.x + dx, 
                tetromino.y + dy, 
                newRotation
            );
            
            if (this.isValidPosition(candidate)) {
                return candidate;
            }
        }

        // If all kick tests fail, return null
        return null;
    }

    /**
     * Get SRS wall kick test offsets for a rotation
     * @param {Tetromino} tetromino - The tetromino being rotated
     * @param {boolean} clockwise - Direction of rotation
     * @returns {number[][]} Array of [dx, dy] kick test offsets
     */
    getSRSKickTests(tetromino, clockwise) {
        // I-piece has special kick data
        if (tetromino.type === 'I') {
            return this.getIKickTests(tetromino.rotation, clockwise);
        }
        
        // O-piece doesn't need kicks (it's symmetric)
        if (tetromino.type === 'O') {
            return [];
        }
        
        // Standard kick tests for T, S, Z, J, L pieces
        return this.getStandardKickTests(tetromino.rotation, clockwise);
    }

    /**
     * Get kick tests for I-piece (special case)
     * @param {number} fromRotation - Current rotation state
     * @param {boolean} clockwise - Direction of rotation
     * @returns {number[][]} Array of kick test offsets
     */
    getIKickTests(fromRotation, clockwise) {
        const kickData = {
            // 0->1 (clockwise) or 1->0 (counter-clockwise)
            '0->1': [[-2, 0], [1, 0], [-2, -1], [1, 2]],
            '1->0': [[2, 0], [-1, 0], [2, 1], [-1, -2]],
            
            // 1->2 (clockwise) or 2->1 (counter-clockwise)
            '1->2': [[-1, 0], [2, 0], [-1, 2], [2, -1]],
            '2->1': [[1, 0], [-2, 0], [1, -2], [-2, 1]],
            
            // 2->3 (clockwise) or 3->2 (counter-clockwise)
            '2->3': [[2, 0], [-1, 0], [2, 1], [-1, -2]],
            '3->2': [[-2, 0], [1, 0], [-2, -1], [1, 2]],
            
            // 3->0 (clockwise) or 0->3 (counter-clockwise)
            '3->0': [[1, 0], [-2, 0], [1, -2], [-2, 1]],
            '0->3': [[-1, 0], [2, 0], [-1, 2], [2, -1]]
        };
        
        const toRotation = clockwise ? (fromRotation + 1) % 4 : (fromRotation + 3) % 4;
        const key = `${fromRotation}->${toRotation}`;
        
        return kickData[key] || [];
    }

    /**
     * Get standard kick tests for T, S, Z, J, L pieces
     * @param {number} fromRotation - Current rotation state
     * @param {boolean} clockwise - Direction of rotation
     * @returns {number[][]} Array of kick test offsets
     */
    getStandardKickTests(fromRotation, clockwise) {
        const kickData = {
            // 0->1 (clockwise) or 1->0 (counter-clockwise)
            '0->1': [[-1, 0], [-1, 1], [0, -2], [-1, -2]],
            '1->0': [[1, 0], [1, -1], [0, 2], [1, 2]],
            
            // 1->2 (clockwise) or 2->1 (counter-clockwise)
            '1->2': [[1, 0], [1, -1], [0, 2], [1, 2]],
            '2->1': [[-1, 0], [-1, 1], [0, -2], [-1, -2]],
            
            // 2->3 (clockwise) or 3->2 (counter-clockwise)
            '2->3': [[1, 0], [1, 1], [0, -2], [1, -2]],
            '3->2': [[-1, 0], [-1, -1], [0, 2], [-1, 2]],
            
            // 3->0 (clockwise) or 0->3 (counter-clockwise)
            '3->0': [[-1, 0], [-1, -1], [0, 2], [-1, 2]],
            '0->3': [[1, 0], [1, 1], [0, -2], [1, -2]]
        };
        
        const toRotation = clockwise ? (fromRotation + 1) % 4 : (fromRotation + 3) % 4;
        const key = `${fromRotation}->${toRotation}`;
        
        return kickData[key] || [];
    }

    /**
     * Find the lowest valid position for a tetromino (hard drop)
     * @param {Tetromino} tetromino - The tetromino to drop
     * @returns {Tetromino} Tetromino at the lowest valid position
     */
    getHardDropPosition(tetromino) {
        let dropDistance = 0;
        let candidate = tetromino;
        
        // Keep moving down until collision
        while (this.canMove(candidate, 0, 1)) {
            dropDistance++;
            candidate = candidate.move(0, 1);
        }
        
        return candidate;
    }

    /**
     * Check if the game is over (new piece can't be placed)
     * @param {Tetromino} tetromino - The tetromino trying to spawn
     * @returns {boolean} True if game over condition is met
     */
    isGameOver(tetromino) {
        return !this.isValidPosition(tetromino);
    }
}