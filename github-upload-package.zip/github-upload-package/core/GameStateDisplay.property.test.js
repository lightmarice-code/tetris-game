/**
 * Property-based tests for Game State Display Synchronization
 * **Feature: tetris-game, Property 13: 游戏状态显示同步**
 * **Validates: Requirements 5.1, 5.2, 5.3**
 */

import fc from 'fast-check';
import { Renderer } from '../../src/core/Renderer.js';
import { GameConfig } from '../../src/config/GameConfig.js';

// Mock DOM elements for testing
const createMockDOM = () => {
    // Create mock canvas elements
    const mockCanvas = {
        width: 300,
        height: 600,
        getContext: () => ({
            fillStyle: '',
            fillRect: jest.fn(),
            strokeStyle: '',
            strokeRect: jest.fn(),
            lineWidth: 1,
            globalAlpha: 1,
            imageSmoothingEnabled: false,
            save: jest.fn(),
            restore: jest.fn(),
            beginPath: jest.fn(),
            moveTo: jest.fn(),
            lineTo: jest.fn(),
            stroke: jest.fn(),
            font: '',
            textAlign: '',
            textBaseline: '',
            fillText: jest.fn()
        })
    };

    const mockNextPieceCanvas = {
        width: 80,
        height: 80,
        getContext: () => ({
            fillStyle: '',
            fillRect: jest.fn(),
            strokeStyle: '',
            strokeRect: jest.fn(),
            lineWidth: 1,
            globalAlpha: 1,
            imageSmoothingEnabled: false,
            save: jest.fn(),
            restore: jest.fn()
        })
    };

    // Mock DOM elements with proper setters
    const mockElements = {
        scoreDisplay: { 
            _textContent: '0',
            get textContent() { return this._textContent; },
            set textContent(value) { this._textContent = value; }
        },
        levelDisplay: { 
            _textContent: '1',
            get textContent() { return this._textContent; },
            set textContent(value) { this._textContent = value; }
        },
        linesDisplay: { 
            _textContent: '0',
            get textContent() { return this._textContent; },
            set textContent(value) { this._textContent = value; }
        },
        gameOverScreen: { classList: { add: jest.fn(), remove: jest.fn() } },
        finalScore: { 
            _textContent: '0',
            get textContent() { return this._textContent; },
            set textContent(value) { this._textContent = value; }
        }
    };

    // Mock document.getElementById
    global.document = {
        getElementById: jest.fn((id) => mockElements[id] || null)
    };

    return { mockCanvas, mockNextPieceCanvas, mockElements };
};

describe('Game State Display Synchronization Properties', () => {
    let mockDOM;
    let renderer;
    let config;

    beforeEach(() => {
        mockDOM = createMockDOM();
        config = new GameConfig();
        renderer = new Renderer(mockDOM.mockCanvas, mockDOM.mockNextPieceCanvas, config);
        
        // Ensure the mock is properly set up for each test
        global.document.getElementById = jest.fn((id) => mockDOM.mockElements[id] || null);
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    /**
     * **Feature: tetris-game, Property 13: 游戏状态显示同步**
     * For any game state change, the UI should synchronously display current score, level, and lines
     */
    test('UI synchronizes with game state changes', () => {
        fc.assert(fc.property(
            // Generate random game state values
            fc.integer({ min: 0, max: 999999 }), // score
            fc.integer({ min: 1, max: 20 }),     // level
            fc.integer({ min: 0, max: 1000 }),   // lines
            fc.boolean(),                        // isPaused
            fc.boolean(),                        // isGameOver
            (score, level, lines, isPaused, isGameOver) => {
                const gameState = {
                    score,
                    level,
                    lines,
                    isPaused,
                    isGameOver
                };

                // Update UI with the game state
                renderer.updateUI(gameState);

                // Property: Score display should match game state score
                expect(mockDOM.mockElements.scoreDisplay.textContent)
                    .toBe(score.toLocaleString());

                // Property: Level display should match game state level
                expect(mockDOM.mockElements.levelDisplay.textContent)
                    .toBe(level.toString());

                // Property: Lines display should match game state lines
                expect(mockDOM.mockElements.linesDisplay.textContent)
                    .toBe(lines.toString());
            }
        ), { numRuns: 100 });
    });

    /**
     * Test that game over screen displays correct final score
     */
    test('game over screen displays correct final score', () => {
        fc.assert(fc.property(
            fc.integer({ min: 0, max: 999999 }),
            (finalScore) => {
                // Show game over screen
                renderer.showGameOver(finalScore);

                // Property: Final score should be displayed correctly
                expect(mockDOM.mockElements.finalScore.textContent)
                    .toBe(finalScore.toLocaleString());

                // Property: Game over screen should be shown
                expect(mockDOM.mockElements.gameOverScreen.classList.add)
                    .toHaveBeenCalledWith('show');
            }
        ), { numRuns: 100 });
    });

    /**
     * Test that game over screen can be hidden
     */
    test('game over screen can be hidden', () => {
        fc.assert(fc.property(
            fc.constant(null), // No parameters needed for this test
            () => {
                // Hide game over screen
                renderer.hideGameOver();

                // Property: Game over screen should be hidden
                expect(mockDOM.mockElements.gameOverScreen.classList.remove)
                    .toHaveBeenCalledWith('show');
            }
        ), { numRuns: 100 });
    });

    /**
     * Test that UI updates are consistent across multiple calls
     */
    test('UI updates are consistent across multiple calls', () => {
        fc.assert(fc.property(
            fc.array(fc.record({
                score: fc.integer({ min: 0, max: 999999 }),
                level: fc.integer({ min: 1, max: 20 }),
                lines: fc.integer({ min: 0, max: 1000 }),
                isPaused: fc.boolean(),
                isGameOver: fc.boolean()
            }), { minLength: 1, maxLength: 10 }),
            (gameStates) => {
                // Apply all game state updates
                for (const gameState of gameStates) {
                    renderer.updateUI(gameState);
                }

                // Property: Final UI state should match the last game state
                const lastState = gameStates[gameStates.length - 1];
                
                expect(mockDOM.mockElements.scoreDisplay.textContent)
                    .toBe(lastState.score.toLocaleString());
                
                expect(mockDOM.mockElements.levelDisplay.textContent)
                    .toBe(lastState.level.toString());
                
                expect(mockDOM.mockElements.linesDisplay.textContent)
                    .toBe(lastState.lines.toString());
            }
        ), { numRuns: 100 });
    });

    /**
     * Test that score formatting is consistent
     */
    test('score formatting is consistent with locale', () => {
        fc.assert(fc.property(
            fc.integer({ min: 0, max: 999999 }),
            (score) => {
                const gameState = { score, level: 1, lines: 0, isPaused: false, isGameOver: false };
                
                renderer.updateUI(gameState);
                
                // Property: Score should be formatted with locale-specific number formatting
                const expectedFormat = score.toLocaleString();
                expect(mockDOM.mockElements.scoreDisplay.textContent).toBe(expectedFormat);
                
                // Property: Formatted score should be parseable back to original number
                const parsedScore = parseInt(mockDOM.mockElements.scoreDisplay.textContent.replace(/,/g, ''));
                expect(parsedScore).toBe(score);
            }
        ), { numRuns: 100 });
    });

    /**
     * Test that UI elements handle edge cases properly
     */
    test('UI handles edge case values properly', () => {
        fc.assert(fc.property(
            fc.constantFrom(
                { score: 0, level: 1, lines: 0 },           // Minimum values
                { score: 999999, level: 20, lines: 1000 },  // Maximum values
                { score: 1, level: 1, lines: 1 },           // Small positive values
            ),
            (edgeCase) => {
                const gameState = { 
                    ...edgeCase, 
                    isPaused: false, 
                    isGameOver: false 
                };
                
                renderer.updateUI(gameState);
                
                // Property: All edge case values should be displayed correctly
                expect(mockDOM.mockElements.scoreDisplay.textContent)
                    .toBe(edgeCase.score.toLocaleString());
                
                expect(mockDOM.mockElements.levelDisplay.textContent)
                    .toBe(edgeCase.level.toString());
                
                expect(mockDOM.mockElements.linesDisplay.textContent)
                    .toBe(edgeCase.lines.toString());
            }
        ), { numRuns: 100 });
    });

    /**
     * Test that missing DOM elements don't cause errors
     */
    test('missing DOM elements are handled gracefully', () => {
        fc.assert(fc.property(
            fc.integer({ min: 0, max: 999999 }),
            fc.integer({ min: 1, max: 20 }),
            fc.integer({ min: 0, max: 1000 }),
            (score, level, lines) => {
                // Mock missing DOM elements
                global.document.getElementById = jest.fn(() => null);
                
                const gameState = { score, level, lines, isPaused: false, isGameOver: false };
                
                // Property: updateUI should not throw when DOM elements are missing
                expect(() => {
                    renderer.updateUI(gameState);
                }).not.toThrow();
            }
        ), { numRuns: 100 });
    });
});