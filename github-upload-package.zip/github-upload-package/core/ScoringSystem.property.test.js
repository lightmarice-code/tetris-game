import fc from 'fast-check';
import { ScoringSystem } from '../../src/core/ScoringSystem.js';
import { GameConfig } from '../../src/config/GameConfig.js';

describe('ScoringSystem Property Tests', () => {
    let scoringSystem;
    let config;

    beforeEach(() => {
        config = new GameConfig();
        scoringSystem = new ScoringSystem(config);
    });

    /**
     * **Feature: tetris-game, Property 8: 分数计算正确性**
     * **Validates: Requirements 3.3, 3.4**
     * 
     * For any valid line clear operation, the system should calculate score
     * based on the number of lines cleared, with multi-line clears giving higher rewards
     */
    test('Property 8: Score calculation correctness', () => {
        fc.assert(fc.property(
            fc.integer({ min: 1, max: 4 }), // linesCleared
            fc.integer({ min: 1, max: 30 }), // level
            (linesCleared, level) => {
                const score = scoringSystem.calculateScore(linesCleared, level);
                
                // Score should be positive for valid inputs
                expect(score).toBeGreaterThan(0);
                
                // Score should increase with level (level multiplier effect)
                const scoreLevel1 = scoringSystem.calculateScore(linesCleared, 1);
                const scoreLevel2 = scoringSystem.calculateScore(linesCleared, 2);
                expect(scoreLevel2).toBeGreaterThan(scoreLevel1);
                
                // Multi-line clears should give higher base scores
                if (linesCleared < 4) {
                    const higherLineScore = scoringSystem.calculateScore(linesCleared + 1, level);
                    expect(higherLineScore).toBeGreaterThan(score);
                }
                
                // Score should be exactly base score * level
                const baseScore = scoringSystem.getBaseScore(linesCleared);
                expect(score).toBe(baseScore * level);
                
                // Verify specific scoring values match configuration
                const expectedBaseScore = getExpectedBaseScore(linesCleared, config);
                expect(baseScore).toBe(expectedBaseScore);
            }
        ), { numRuns: 100 });
    });

    /**
     * Property: Score calculation should handle edge cases correctly
     */
    test('Property: Score calculation edge cases', () => {
        fc.assert(fc.property(
            fc.integer({ min: -10, max: 0 }), // invalid linesCleared
            fc.integer({ min: 1, max: 10 }), // level
            (invalidLines, level) => {
                const score = scoringSystem.calculateScore(invalidLines, level);
                expect(score).toBe(0);
            }
        ), { numRuns: 50 });

        fc.assert(fc.property(
            fc.integer({ min: 5, max: 10 }), // invalid linesCleared (too high)
            fc.integer({ min: 1, max: 10 }), // level
            (invalidLines, level) => {
                const score = scoringSystem.calculateScore(invalidLines, level);
                expect(score).toBe(0);
            }
        ), { numRuns: 50 });

        fc.assert(fc.property(
            fc.integer({ min: 1, max: 4 }), // linesCleared
            fc.integer({ min: -5, max: 0 }), // invalid level
            (linesCleared, invalidLevel) => {
                const score = scoringSystem.calculateScore(linesCleared, invalidLevel);
                expect(score).toBe(0);
            }
        ), { numRuns: 50 });
    });

    /**
     * Property: Multi-line bonus progression should be monotonic
     */
    test('Property: Multi-line bonus progression', () => {
        fc.assert(fc.property(
            fc.integer({ min: 1, max: 10 }), // level
            (level) => {
                const single = scoringSystem.calculateScore(1, level);
                const double = scoringSystem.calculateScore(2, level);
                const triple = scoringSystem.calculateScore(3, level);
                const tetris = scoringSystem.calculateScore(4, level);
                
                // Each successive multi-line clear should give more points
                expect(double).toBeGreaterThan(single);
                expect(triple).toBeGreaterThan(double);
                expect(tetris).toBeGreaterThan(triple);
                
                // Tetris should give significantly more than single
                expect(tetris).toBeGreaterThan(single * 4);
            }
        ), { numRuns: 100 });
    });
});

/**
 * Helper function to get expected base score from config
 */
function getExpectedBaseScore(linesCleared, config) {
    switch (linesCleared) {
        case 1:
            return config.scoring.single;
        case 2:
            return config.scoring.double;
        case 3:
            return config.scoring.triple;
        case 4:
            return config.scoring.tetris;
        default:
            return 0;
    }
}