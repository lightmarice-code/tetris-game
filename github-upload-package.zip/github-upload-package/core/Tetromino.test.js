/**
 * Basic unit tests for Tetromino class
 */

import { Tetromino, TETROMINO_DEFINITIONS } from '../../src/core/Tetromino.js';

describe('Tetromino', () => {
    describe('Constructor', () => {
        test('should create a valid tetromino with default parameters', () => {
            const tetromino = new Tetromino('I');
            
            expect(tetromino.type).toBe('I');
            expect(tetromino.x).toBe(0);
            expect(tetromino.y).toBe(0);
            expect(tetromino.rotation).toBe(0);
        });

        test('should create a tetromino with custom position and rotation', () => {
            const tetromino = new Tetromino('T', 5, 3, 2);
            
            expect(tetromino.type).toBe('T');
            expect(tetromino.x).toBe(5);
            expect(tetromino.y).toBe(3);
            expect(tetromino.rotation).toBe(2);
        });

        test('should throw error for invalid tetromino type', () => {
            expect(() => new Tetromino('X')).toThrow('Invalid tetromino type: X');
        });

        test('should normalize rotation values', () => {
            const tetromino = new Tetromino('I', 0, 0, 5);
            expect(tetromino.rotation).toBe(1); // 5 % 4 = 1
        });
    });

    describe('Basic Properties', () => {
        test('should return correct shape for each rotation', () => {
            const tetromino = new Tetromino('I');
            const shape = tetromino.getShape();
            
            expect(shape).toEqual(TETROMINO_DEFINITIONS.I.shapes[0]);
            expect(Array.isArray(shape)).toBe(true);
            expect(shape.length).toBe(4);
            expect(shape[0].length).toBe(4);
        });

        test('should return correct color', () => {
            const tetromino = new Tetromino('I');
            expect(tetromino.getColor()).toBe('#00FFFF');
        });

        test('should return correct name', () => {
            const tetromino = new Tetromino('T');
            expect(tetromino.getName()).toBe('T');
        });
    });

    describe('Block Positions', () => {
        test('should return correct block positions for I piece', () => {
            const tetromino = new Tetromino('I', 0, 0);
            const blocks = tetromino.getBlocks();
            
            expect(blocks).toEqual([
                { x: 0, y: 1 },
                { x: 1, y: 1 },
                { x: 2, y: 1 },
                { x: 3, y: 1 }
            ]);
        });

        test('should return correct block positions with offset', () => {
            const tetromino = new Tetromino('I', 2, 3);
            const blocks = tetromino.getBlocks();
            
            expect(blocks).toEqual([
                { x: 2, y: 4 },
                { x: 3, y: 4 },
                { x: 4, y: 4 },
                { x: 5, y: 4 }
            ]);
        });
    });

    describe('Movement', () => {
        test('should create new instance when moving', () => {
            const original = new Tetromino('T', 0, 0);
            const moved = original.move(1, 2);
            
            expect(moved).not.toBe(original);
            expect(moved.x).toBe(1);
            expect(moved.y).toBe(2);
            expect(moved.type).toBe('T');
            expect(moved.rotation).toBe(0);
            
            // Original should be unchanged
            expect(original.x).toBe(0);
            expect(original.y).toBe(0);
        });

        test('should move left correctly', () => {
            const tetromino = new Tetromino('I', 5, 3);
            const moved = tetromino.moveLeft();
            
            expect(moved.x).toBe(4);
            expect(moved.y).toBe(3);
        });

        test('should move right correctly', () => {
            const tetromino = new Tetromino('I', 5, 3);
            const moved = tetromino.moveRight();
            
            expect(moved.x).toBe(6);
            expect(moved.y).toBe(3);
        });

        test('should move down correctly', () => {
            const tetromino = new Tetromino('I', 5, 3);
            const moved = tetromino.moveDown();
            
            expect(moved.x).toBe(5);
            expect(moved.y).toBe(4);
        });
    });

    describe('Rotation', () => {
        test('should rotate clockwise correctly', () => {
            const tetromino = new Tetromino('T', 0, 0, 0);
            const rotated = tetromino.rotate();
            
            expect(rotated.rotation).toBe(1);
            expect(rotated.x).toBe(0);
            expect(rotated.y).toBe(0);
            expect(rotated.type).toBe('T');
        });

        test('should rotate counter-clockwise correctly', () => {
            const tetromino = new Tetromino('T', 0, 0, 1);
            const rotated = tetromino.rotateCounterClockwise();
            
            expect(rotated.rotation).toBe(0);
        });

        test('should wrap rotation values correctly', () => {
            const tetromino = new Tetromino('T', 0, 0, 3);
            const rotated = tetromino.rotate();
            
            expect(rotated.rotation).toBe(0);
        });
    });

    describe('Clone and Equals', () => {
        test('should create identical clone', () => {
            const original = new Tetromino('S', 3, 5, 2);
            const clone = original.clone();
            
            expect(clone).not.toBe(original);
            expect(clone.equals(original)).toBe(true);
        });

        test('should detect differences correctly', () => {
            const tetromino1 = new Tetromino('S', 3, 5, 2);
            const tetromino2 = new Tetromino('S', 3, 5, 1);
            
            expect(tetromino1.equals(tetromino2)).toBe(false);
        });
    });

    describe('Static Methods', () => {
        test('should create random tetromino', () => {
            const random = Tetromino.createRandom(5, 10);
            
            expect(random).toBeInstanceOf(Tetromino);
            expect(random.x).toBe(5);
            expect(random.y).toBe(10);
            expect(Tetromino.getValidTypes()).toContain(random.type);
        });

        test('should return all valid types', () => {
            const types = Tetromino.getValidTypes();
            expect(types).toEqual(['I', 'O', 'T', 'S', 'Z', 'J', 'L']);
        });
    });
});