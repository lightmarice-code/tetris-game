/**
 * Property-based tests for Game Reset Functionality
 * Using fast-check for property testing
 */

import fc from 'fast-check';
import { GameEngine } from '../../src/core/GameEngine.js';
import { GameConfig } from '../../src/config/GameConfig.js';
import { Tetromino } from '../../src/core/Tetromino.js';

// Mock canvas for testing
const createMockCanvas = () => ({
    getContext: jest.fn(() => ({
        clearRect: jest.fn(),
        fillRect: jest.fn(),
        strokeRect: jest.fn(),
        fillText: jest.fn(),
        measureText: jest.fn(() => ({ width: 0 })),
        beginPath: jest.fn(),
        moveTo: jest.fn(),
        lineTo: jest.fn(),
        stroke: jest.fn(),
        fill: jest.fn(),
        save: jest.fn(),
        restore: jest.fn(),
        translate: jest.fn(),
        rotate: jest.fn(),
        scale: jest.fn()
    }))
});

describe('Game Reset Property Tests', () => {
    /**
     * **Feature: tetris-game, Property 16: 游戏重置功能**
     * **Validates: Requirements 6.3**
     * 
     * For any game state, reset operation should restore all game state to initial values
     */
    describe('Property 16: Game Reset Functionality', () => {
        test('should reset all game state to initial values', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 1, max: 20 }),     // level
                    fc.integer({ min: 0, max: 50000 }),  // score
                    fc.integer({ min: 0, max: 200 }),    // lines
                    fc.boolean(),                        // game over state
                    fc.boolean(),                        // paused state
                    fc.integer({ min: 0, max: 1000 }),   // drop timer
                    (level, score, lines, isGameOver, isPaused, dropTimer) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        // Set up modified game state
                        engine.gameState.level = level;
                        engine.gameState.score = score;
                        engine.gameState.lines = lines;
                        engine.gameState.setGameOver(isGameOver);
                        engine.gameState.setPaused(isPaused);
                        engine.dropTimer = dropTimer;
                        engine.isRunning = true;
                        
                        // Fill some cells on the board
                        const board = engine.getGameBoard();
                        for (let i = 0; i < 5; i++) {
                            board.setCell(i, config.boardHeight - 1, '#FF0000');
                        }
                        
                        // Reset the game
                        engine.reset();
                        
                        // Verify all state is reset to initial values
                        const finalState = engine.getGameState();
                        
                        expect(finalState.score).toBe(0);
                        expect(finalState.level).toBe(1);
                        expect(finalState.lines).toBe(0);
                        expect(finalState.isGameOver).toBe(false);
                        expect(finalState.isPaused).toBe(false);
                        expect(engine.getDropTimer()).toBe(0);
                        expect(engine.isGameRunning()).toBe(false);
                        
                        // Board should be empty
                        const finalBoard = board.getBoard();
                        for (let y = 0; y < config.boardHeight; y++) {
                            for (let x = 0; x < config.boardWidth; x++) {
                                expect(finalBoard[y][x]).toBe(0);
                            }
                        }
                        
                        // Should have valid tetrominoes
                        expect(engine.getCurrentTetromino()).toBeTruthy();
                        expect(engine.getNextTetromino()).toBeTruthy();
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should reset timing state correctly', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 100, max: 2000 }), // drop timer value
                    fc.integer({ min: 1000, max: 5000 }), // last update time
                    (dropTimer, lastUpdateTime) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        // Set up timing state
                        engine.dropTimer = dropTimer;
                        engine.lastUpdateTime = lastUpdateTime;
                        engine.isRunning = true;
                        
                        // Reset the game
                        engine.reset();
                        
                        // Timing should be reset
                        expect(engine.getDropTimer()).toBe(0);
                        expect(engine.lastUpdateTime).toBe(0);
                        expect(engine.isGameRunning()).toBe(false);
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should generate new tetrominoes after reset', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 1, max: 10 }), // number of resets
                    (numResets) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        for (let i = 0; i < numResets; i++) {
                            // Modify game state
                            engine.gameState.score = 1000 * (i + 1);
                            engine.gameState.level = i + 2;
                            engine.gameState.lines = i * 10;
                            
                            const beforeCurrent = engine.getCurrentTetromino();
                            const beforeNext = engine.getNextTetromino();
                            
                            // Reset
                            engine.reset();
                            
                            const afterCurrent = engine.getCurrentTetromino();
                            const afterNext = engine.getNextTetromino();
                            
                            // Should have valid tetrominoes
                            expect(afterCurrent).toBeTruthy();
                            expect(afterNext).toBeTruthy();
                            
                            // Should be new instances (not the same objects)
                            if (beforeCurrent && afterCurrent) {
                                expect(afterCurrent).not.toBe(beforeCurrent);
                            }
                            if (beforeNext && afterNext) {
                                expect(afterNext).not.toBe(beforeNext);
                            }
                            
                            // Should be at spawn position
                            if (afterCurrent) {
                                expect(afterCurrent.x).toBe(Math.floor(config.boardWidth / 2) - 2);
                                expect(afterCurrent.y).toBe(0);
                            }
                            
                            // Game state should be reset
                            expect(engine.gameState.score).toBe(0);
                            expect(engine.gameState.level).toBe(1);
                            expect(engine.gameState.lines).toBe(0);
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should clear the game board completely', () => {
            fc.assert(
                fc.property(
                    fc.array(
                        fc.record({
                            x: fc.integer({ min: 0, max: 9 }),
                            y: fc.integer({ min: 0, max: 19 }),
                            color: fc.constantFrom('#FF0000', '#00FF00', '#0000FF', '#FFFF00')
                        }),
                        { minLength: 1, maxLength: 50 }
                    ),
                    (cellsToFill) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        const board = engine.getGameBoard();
                        
                        // Fill some cells
                        for (const cell of cellsToFill) {
                            board.setCell(cell.x, cell.y, cell.color);
                        }
                        
                        // Verify cells are filled
                        let filledCells = 0;
                        const beforeBoard = board.getBoard();
                        for (let y = 0; y < config.boardHeight; y++) {
                            for (let x = 0; x < config.boardWidth; x++) {
                                if (beforeBoard[y][x] !== 0) {
                                    filledCells++;
                                }
                            }
                        }
                        expect(filledCells).toBeGreaterThan(0);
                        
                        // Reset the game
                        engine.reset();
                        
                        // Board should be completely empty
                        const afterBoard = board.getBoard();
                        for (let y = 0; y < config.boardHeight; y++) {
                            for (let x = 0; x < config.boardWidth; x++) {
                                expect(afterBoard[y][x]).toBe(0);
                            }
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should stop game loop and reset running state', () => {
            fc.assert(
                fc.property(
                    fc.boolean(), // initial running state
                    fc.boolean(), // initial paused state
                    (initialRunning, initialPaused) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        // Set up initial state
                        if (initialRunning) {
                            engine.start();
                        }
                        if (initialPaused) {
                            engine.pause();
                        }
                        
                        const beforeRunning = engine.isGameRunning();
                        const beforePaused = engine.isGamePaused();
                        
                        // Reset the game
                        engine.reset();
                        
                        // Should not be running or paused after reset
                        expect(engine.isGameRunning()).toBe(false);
                        expect(engine.isGamePaused()).toBe(false);
                        
                        // Animation frame should be cancelled
                        expect(engine.animationFrameId).toBeNull();
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should reset to consistent initial state regardless of previous state', () => {
            fc.assert(
                fc.property(
                    fc.record({
                        level: fc.integer({ min: 1, max: 50 }),
                        score: fc.integer({ min: 0, max: 100000 }),
                        lines: fc.integer({ min: 0, max: 500 }),
                        isGameOver: fc.boolean(),
                        isPaused: fc.boolean(),
                        dropTimer: fc.integer({ min: 0, max: 2000 })
                    }),
                    (initialState) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine1 = new GameEngine(canvas, config);
                        const engine2 = new GameEngine(canvas, config);
                        
                        // Set up different states for both engines
                        engine1.gameState.level = initialState.level;
                        engine1.gameState.score = initialState.score;
                        engine1.gameState.lines = initialState.lines;
                        engine1.gameState.setGameOver(initialState.isGameOver);
                        engine1.gameState.setPaused(initialState.isPaused);
                        engine1.dropTimer = initialState.dropTimer;
                        
                        engine2.gameState.level = initialState.level + 5;
                        engine2.gameState.score = initialState.score + 5000;
                        engine2.gameState.lines = initialState.lines + 50;
                        engine2.gameState.setGameOver(!initialState.isGameOver);
                        engine2.gameState.setPaused(!initialState.isPaused);
                        engine2.dropTimer = initialState.dropTimer + 500;
                        
                        // Reset both engines
                        engine1.reset();
                        engine2.reset();
                        
                        // Both should have identical state after reset
                        const state1 = engine1.getGameState();
                        const state2 = engine2.getGameState();
                        
                        expect(state1.score).toBe(state2.score);
                        expect(state1.level).toBe(state2.level);
                        expect(state1.lines).toBe(state2.lines);
                        expect(state1.isGameOver).toBe(state2.isGameOver);
                        expect(state1.isPaused).toBe(state2.isPaused);
                        expect(engine1.getDropTimer()).toBe(engine2.getDropTimer());
                        expect(engine1.isGameRunning()).toBe(engine2.isGameRunning());
                        
                        // Both boards should be identical (empty)
                        const board1 = engine1.getGameBoard().getBoard();
                        const board2 = engine2.getGameBoard().getBoard();
                        
                        for (let y = 0; y < config.boardHeight; y++) {
                            for (let x = 0; x < config.boardWidth; x++) {
                                expect(board1[y][x]).toBe(board2[y][x]);
                                expect(board1[y][x]).toBe(0);
                            }
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should allow game to be started again after reset', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 1, max: 5 }), // number of reset/start cycles
                    (numCycles) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        for (let i = 0; i < numCycles; i++) {
                            // Modify game state
                            engine.gameState.score = 1000;
                            engine.gameState.level = 5;
                            engine.gameState.lines = 20;
                            
                            // Start the game
                            engine.start();
                            expect(engine.isGameRunning()).toBe(true);
                            
                            // Reset the game
                            engine.reset();
                            expect(engine.isGameRunning()).toBe(false);
                            expect(engine.gameState.score).toBe(0);
                            expect(engine.gameState.level).toBe(1);
                            expect(engine.gameState.lines).toBe(0);
                            
                            // Should be able to start again
                            engine.start();
                            expect(engine.isGameRunning()).toBe(true);
                            expect(engine.isGamePaused()).toBe(false);
                            
                            // Game should be functional
                            const currentTetromino = engine.getCurrentTetromino();
                            const nextTetromino = engine.getNextTetromino();
                            
                            expect(currentTetromino).toBeTruthy();
                            expect(nextTetromino).toBeTruthy();
                            
                            // Should be able to perform game actions
                            if (currentTetromino) {
                                const moveResult = engine.moveLeft() || engine.moveRight() || engine.rotate();
                                // At least one action should be possible (unless in a very constrained state)
                            }
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should handle reset during different game states', () => {
            fc.assert(
                fc.property(
                    fc.constantFrom('running', 'paused', 'game_over', 'not_started'),
                    (gameState) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        // Set up the specified game state
                        switch (gameState) {
                            case 'running':
                                engine.start();
                                break;
                            case 'paused':
                                engine.start();
                                engine.pause();
                                break;
                            case 'game_over':
                                engine.gameState.setGameOver(true);
                                break;
                            case 'not_started':
                                // Default state, do nothing
                                break;
                        }
                        
                        // Add some game progress
                        engine.gameState.score = 5000;
                        engine.gameState.level = 3;
                        engine.gameState.lines = 15;
                        
                        // Reset should work regardless of state
                        engine.reset();
                        
                        // Verify reset worked
                        expect(engine.gameState.score).toBe(0);
                        expect(engine.gameState.level).toBe(1);
                        expect(engine.gameState.lines).toBe(0);
                        expect(engine.gameState.isGameOver).toBe(false);
                        expect(engine.gameState.isPaused).toBe(false);
                        expect(engine.isGameRunning()).toBe(false);
                        expect(engine.getDropTimer()).toBe(0);
                        
                        // Should have valid tetrominoes
                        expect(engine.getCurrentTetromino()).toBeTruthy();
                        expect(engine.getNextTetromino()).toBeTruthy();
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });
    });
});