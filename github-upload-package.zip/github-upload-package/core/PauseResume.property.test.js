/**
 * Property-based tests for Pause and Resume Functionality
 * Using fast-check for property testing
 */

import fc from 'fast-check';
import { GameEngine } from '../../src/core/GameEngine.js';
import { GameConfig } from '../../src/config/GameConfig.js';
import { Tetromino } from '../../src/core/Tetromino.js';

// Mock canvas for testing
const createMockCanvas = () => ({
    getContext: jest.fn(() => ({
        clearRect: jest.fn(),
        fillRect: jest.fn(),
        strokeRect: jest.fn(),
        fillText: jest.fn(),
        measureText: jest.fn(() => ({ width: 0 })),
        beginPath: jest.fn(),
        moveTo: jest.fn(),
        lineTo: jest.fn(),
        stroke: jest.fn(),
        fill: jest.fn(),
        save: jest.fn(),
        restore: jest.fn(),
        translate: jest.fn(),
        rotate: jest.fn(),
        scale: jest.fn()
    }))
});

describe('Pause and Resume Property Tests', () => {
    /**
     * **Feature: tetris-game, Property 15: 暂停和恢复功能**
     * **Validates: Requirements 6.1, 6.2**
     * 
     * For any game state, pause operation should stop all game logic updates, and resume operation should restart updates
     */
    describe('Property 15: Pause and Resume Functionality', () => {
        test('should stop all game logic updates when paused', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 100, max: 1000 }), // delta time
                    fc.integer({ min: 1, max: 10 }),     // level
                    fc.integer({ min: 0, max: 1000 }),   // initial score
                    (deltaTime, level, initialScore) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        // Set up initial game state
                        engine.gameState.level = level;
                        engine.gameState.score = initialScore;
                        
                        const initialTetromino = engine.getCurrentTetromino();
                        const initialDropTimer = engine.getDropTimer();
                        const initialGameState = engine.getGameState();
                        
                        // Pause the game
                        engine.pause();
                        expect(engine.isGamePaused()).toBe(true);
                        
                        // Try to update while paused
                        engine.update(deltaTime);
                        
                        const finalTetromino = engine.getCurrentTetromino();
                        const finalDropTimer = engine.getDropTimer();
                        const finalGameState = engine.getGameState();
                        
                        // Game state should remain unchanged
                        expect(finalGameState.score).toBe(initialGameState.score);
                        expect(finalGameState.level).toBe(initialGameState.level);
                        expect(finalGameState.lines).toBe(initialGameState.lines);
                        
                        // Drop timer should not have changed
                        expect(finalDropTimer).toBe(initialDropTimer);
                        
                        // Tetromino position should not have changed
                        if (initialTetromino && finalTetromino) {
                            expect(finalTetromino.x).toBe(initialTetromino.x);
                            expect(finalTetromino.y).toBe(initialTetromino.y);
                            expect(finalTetromino.rotation).toBe(initialTetromino.rotation);
                            expect(finalTetromino.type).toBe(initialTetromino.type);
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should resume game logic updates after resume', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 200, max: 800 }), // delta time (enough to trigger drop)
                    fc.integer({ min: 1, max: 5 }),     // level
                    (deltaTime, level) => {
                        const config = new GameConfig();
                        config.dropInterval = 100; // Fast drops for testing
                        
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        engine.gameState.level = level;
                        
                        // Start the game first
                        engine.start();
                        
                        const initialTetromino = engine.getCurrentTetromino();
                        
                        // Pause and then resume
                        engine.pause();
                        expect(engine.isGamePaused()).toBe(true);
                        
                        engine.resume();
                        expect(engine.isGamePaused()).toBe(false);
                        expect(engine.isGameRunning()).toBe(true);
                        
                        // Update after resume - should process normally
                        engine.dropTimer = 0; // Reset timer for consistent testing
                        engine.update(deltaTime);
                        
                        const finalTetromino = engine.getCurrentTetromino();
                        
                        // Game should be processing updates again
                        if (initialTetromino && finalTetromino && !engine.isGameOver()) {
                            // Either the piece moved or was locked and replaced
                            const positionChanged = (finalTetromino.x !== initialTetromino.x || 
                                                   finalTetromino.y !== initialTetromino.y);
                            const pieceChanged = (finalTetromino.type !== initialTetromino.type);
                            
                            // At least one of these should be true after sufficient time
                            expect(positionChanged || pieceChanged).toBe(true);
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should handle multiple pause/resume cycles correctly', () => {
            fc.assert(
                fc.property(
                    fc.array(fc.boolean(), { minLength: 2, maxLength: 10 }), // pause/resume sequence
                    fc.integer({ min: 50, max: 200 }), // delta time per cycle
                    (pauseSequence, deltaTime) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        engine.start();
                        
                        let expectedPauseState = false;
                        
                        for (const shouldPause of pauseSequence) {
                            if (shouldPause && !expectedPauseState) {
                                engine.pause();
                                expectedPauseState = true;
                            } else if (!shouldPause && expectedPauseState) {
                                engine.resume();
                                expectedPauseState = false;
                            }
                            
                            // Verify pause state is correct
                            expect(engine.isGamePaused()).toBe(expectedPauseState);
                            
                            // Try to update
                            const beforeDropTimer = engine.getDropTimer();
                            engine.update(deltaTime);
                            const afterDropTimer = engine.getDropTimer();
                            
                            if (expectedPauseState) {
                                // When paused, timer should not change
                                expect(afterDropTimer).toBe(beforeDropTimer);
                            } else {
                                // When not paused, timer should change (increase or reset to 0)
                                expect(afterDropTimer >= 0).toBe(true);
                            }
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should preserve game state during pause', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 1, max: 20 }),     // level
                    fc.integer({ min: 0, max: 10000 }),  // score
                    fc.integer({ min: 0, max: 100 }),    // lines
                    fc.integer({ min: 100, max: 1000 }), // pause duration
                    (level, score, lines, pauseDuration) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        // Set up game state
                        engine.gameState.level = level;
                        engine.gameState.score = score;
                        engine.gameState.lines = lines;
                        
                        const initialState = {
                            level: engine.gameState.level,
                            score: engine.gameState.score,
                            lines: engine.gameState.lines,
                            isGameOver: engine.gameState.isGameOver,
                            dropTimer: engine.getDropTimer()
                        };
                        
                        const initialTetromino = engine.getCurrentTetromino();
                        const initialNext = engine.getNextTetromino();
                        
                        // Pause the game
                        engine.pause();
                        
                        // Simulate multiple updates during pause
                        const numUpdates = Math.floor(pauseDuration / 50);
                        for (let i = 0; i < numUpdates; i++) {
                            engine.update(50);
                        }
                        
                        // Check that everything is preserved
                        expect(engine.gameState.level).toBe(initialState.level);
                        expect(engine.gameState.score).toBe(initialState.score);
                        expect(engine.gameState.lines).toBe(initialState.lines);
                        expect(engine.gameState.isGameOver).toBe(initialState.isGameOver);
                        expect(engine.getDropTimer()).toBe(initialState.dropTimer);
                        
                        // Tetrominoes should be unchanged
                        const currentTetromino = engine.getCurrentTetromino();
                        const nextTetromino = engine.getNextTetromino();
                        
                        if (initialTetromino && currentTetromino) {
                            expect(currentTetromino.x).toBe(initialTetromino.x);
                            expect(currentTetromino.y).toBe(initialTetromino.y);
                            expect(currentTetromino.type).toBe(initialTetromino.type);
                            expect(currentTetromino.rotation).toBe(initialTetromino.rotation);
                        }
                        
                        if (initialNext && nextTetromino) {
                            expect(nextTetromino.type).toBe(initialNext.type);
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should not allow pause when already paused', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 1, max: 5 }), // number of pause attempts
                    (numPauseAttempts) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        // First pause should work
                        engine.pause();
                        expect(engine.isGamePaused()).toBe(true);
                        
                        // Multiple pause attempts should not change state
                        for (let i = 0; i < numPauseAttempts; i++) {
                            engine.pause();
                            expect(engine.isGamePaused()).toBe(true);
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should not allow resume when not paused', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 1, max: 5 }), // number of resume attempts
                    (numResumeAttempts) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        // Start the game (not paused)
                        engine.start();
                        expect(engine.isGamePaused()).toBe(false);
                        
                        // Multiple resume attempts should not change state
                        for (let i = 0; i < numResumeAttempts; i++) {
                            engine.resume();
                            expect(engine.isGamePaused()).toBe(false);
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should handle pause/resume with user input correctly', () => {
            fc.assert(
                fc.property(
                    fc.array(fc.constantFrom('left', 'right', 'down', 'rotate'), { minLength: 1, maxLength: 5 }),
                    (inputSequence) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        const initialTetromino = engine.getCurrentTetromino();
                        
                        // Pause the game
                        engine.pause();
                        
                        // Try user inputs while paused
                        for (const input of inputSequence) {
                            switch (input) {
                                case 'left':
                                    engine.moveLeft();
                                    break;
                                case 'right':
                                    engine.moveRight();
                                    break;
                                case 'down':
                                    engine.softDrop();
                                    break;
                                case 'rotate':
                                    engine.rotate();
                                    break;
                            }
                        }
                        
                        const finalTetromino = engine.getCurrentTetromino();
                        
                        // Tetromino should not have moved during pause
                        if (initialTetromino && finalTetromino) {
                            expect(finalTetromino.x).toBe(initialTetromino.x);
                            expect(finalTetromino.y).toBe(initialTetromino.y);
                            expect(finalTetromino.rotation).toBe(initialTetromino.rotation);
                        }
                        
                        // Resume and try inputs again
                        engine.resume();
                        
                        let inputWorked = false;
                        for (const input of inputSequence) {
                            const beforeTetromino = engine.getCurrentTetromino();
                            
                            switch (input) {
                                case 'left':
                                    inputWorked = engine.moveLeft() || inputWorked;
                                    break;
                                case 'right':
                                    inputWorked = engine.moveRight() || inputWorked;
                                    break;
                                case 'down':
                                    inputWorked = engine.softDrop() || inputWorked;
                                    break;
                                case 'rotate':
                                    inputWorked = engine.rotate() || inputWorked;
                                    break;
                            }
                            
                            // At least one input should work after resume (unless game over)
                            if (!engine.isGameOver()) {
                                // We expect at least some inputs to be successful
                            }
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should maintain pause state consistency', () => {
            fc.assert(
                fc.property(
                    fc.array(fc.constantFrom('pause', 'resume', 'start', 'reset'), { minLength: 3, maxLength: 8 }),
                    (actionSequence) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        for (const action of actionSequence) {
                            const beforeRunning = engine.isGameRunning();
                            const beforePaused = engine.isGamePaused();
                            
                            switch (action) {
                                case 'start':
                                    engine.start();
                                    // After start: should be running
                                    expect(engine.isGameRunning()).toBe(true);
                                    // Only unpauses if game was not already running
                                    if (!beforeRunning) {
                                        expect(engine.isGamePaused()).toBe(false);
                                    }
                                    break;
                                case 'pause':
                                    engine.pause();
                                    // After pause: should be paused (if was not already)
                                    if (!beforePaused) {
                                        expect(engine.isGamePaused()).toBe(true);
                                    }
                                    break;
                                case 'resume':
                                    engine.resume();
                                    // After resume: should not be paused (if was running and paused)
                                    if (beforeRunning && beforePaused) {
                                        expect(engine.isGamePaused()).toBe(false);
                                    }
                                    break;
                                case 'reset':
                                    engine.reset();
                                    // After reset: should not be running and not paused
                                    expect(engine.isGameRunning()).toBe(false);
                                    expect(engine.isGamePaused()).toBe(false);
                                    break;
                            }
                            
                            // Basic consistency checks
                            const isRunning = engine.isGameRunning();
                            const isPaused = engine.isGamePaused();
                            
                            // Internal state should match public methods
                            expect(engine.gameState.isPaused).toBe(isPaused);
                            
                            // If paused, should have consistent internal state
                            if (isPaused) {
                                expect(engine.gameState.isPaused).toBe(true);
                            }
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });
    });
});