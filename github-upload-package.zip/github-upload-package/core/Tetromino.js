/**
 * Tetromino class representing the falling blocks in Tetris
 * Implements all 7 standard Tetromino types with SRS rotation system
 */

/**
 * Tetromino type definitions with shapes and SRS kick data
 */
export const TETROMINO_DEFINITIONS = {
    I: {
        name: 'I',
        color: '#00FFFF',
        shapes: [
            [
                [0, 0, 0, 0],
                [1, 1, 1, 1],
                [0, 0, 0, 0],
                [0, 0, 0, 0]
            ],
            [
                [0, 0, 1, 0],
                [0, 0, 1, 0],
                [0, 0, 1, 0],
                [0, 0, 1, 0]
            ],
            [
                [0, 0, 0, 0],
                [0, 0, 0, 0],
                [1, 1, 1, 1],
                [0, 0, 0, 0]
            ],
            [
                [0, 1, 0, 0],
                [0, 1, 0, 0],
                [0, 1, 0, 0],
                [0, 1, 0, 0]
            ]
        ],
        kickData: [
            [0, 0], [-1, 0], [2, 0], [-1, 0], [2, 0]
        ]
    },
    O: {
        name: 'O',
        color: '#FFFF00',
        shapes: [
            [
                [0, 1, 1, 0],
                [0, 1, 1, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0]
            ],
            [
                [0, 1, 1, 0],
                [0, 1, 1, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0]
            ],
            [
                [0, 1, 1, 0],
                [0, 1, 1, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0]
            ],
            [
                [0, 1, 1, 0],
                [0, 1, 1, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0]
            ]
        ],
        kickData: [
            [0, 0]
        ]
    },
    T: {
        name: 'T',
        color: '#800080',
        shapes: [
            [
                [0, 1, 0, 0],
                [1, 1, 1, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0]
            ],
            [
                [0, 1, 0, 0],
                [0, 1, 1, 0],
                [0, 1, 0, 0],
                [0, 0, 0, 0]
            ],
            [
                [0, 0, 0, 0],
                [1, 1, 1, 0],
                [0, 1, 0, 0],
                [0, 0, 0, 0]
            ],
            [
                [0, 1, 0, 0],
                [1, 1, 0, 0],
                [0, 1, 0, 0],
                [0, 0, 0, 0]
            ]
        ],
        kickData: [
            [0, 0], [-1, 0], [-1, 1], [0, -2], [-1, -2]
        ]
    },
    S: {
        name: 'S',
        color: '#00FF00',
        shapes: [
            [
                [0, 1, 1, 0],
                [1, 1, 0, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0]
            ],
            [
                [0, 1, 0, 0],
                [0, 1, 1, 0],
                [0, 0, 1, 0],
                [0, 0, 0, 0]
            ],
            [
                [0, 0, 0, 0],
                [0, 1, 1, 0],
                [1, 1, 0, 0],
                [0, 0, 0, 0]
            ],
            [
                [1, 0, 0, 0],
                [1, 1, 0, 0],
                [0, 1, 0, 0],
                [0, 0, 0, 0]
            ]
        ],
        kickData: [
            [0, 0], [-1, 0], [-1, 1], [0, -2], [-1, -2]
        ]
    },
    Z: {
        name: 'Z',
        color: '#FF0000',
        shapes: [
            [
                [1, 1, 0, 0],
                [0, 1, 1, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0]
            ],
            [
                [0, 0, 1, 0],
                [0, 1, 1, 0],
                [0, 1, 0, 0],
                [0, 0, 0, 0]
            ],
            [
                [0, 0, 0, 0],
                [1, 1, 0, 0],
                [0, 1, 1, 0],
                [0, 0, 0, 0]
            ],
            [
                [0, 1, 0, 0],
                [1, 1, 0, 0],
                [1, 0, 0, 0],
                [0, 0, 0, 0]
            ]
        ],
        kickData: [
            [0, 0], [-1, 0], [-1, 1], [0, -2], [-1, -2]
        ]
    },
    J: {
        name: 'J',
        color: '#0000FF',
        shapes: [
            [
                [1, 0, 0, 0],
                [1, 1, 1, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0]
            ],
            [
                [0, 1, 1, 0],
                [0, 1, 0, 0],
                [0, 1, 0, 0],
                [0, 0, 0, 0]
            ],
            [
                [0, 0, 0, 0],
                [1, 1, 1, 0],
                [0, 0, 1, 0],
                [0, 0, 0, 0]
            ],
            [
                [0, 1, 0, 0],
                [0, 1, 0, 0],
                [1, 1, 0, 0],
                [0, 0, 0, 0]
            ]
        ],
        kickData: [
            [0, 0], [-1, 0], [-1, 1], [0, -2], [-1, -2]
        ]
    },
    L: {
        name: 'L',
        color: '#FFA500',
        shapes: [
            [
                [0, 0, 1, 0],
                [1, 1, 1, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 0]
            ],
            [
                [0, 1, 0, 0],
                [0, 1, 0, 0],
                [0, 1, 1, 0],
                [0, 0, 0, 0]
            ],
            [
                [0, 0, 0, 0],
                [1, 1, 1, 0],
                [1, 0, 0, 0],
                [0, 0, 0, 0]
            ],
            [
                [1, 1, 0, 0],
                [0, 1, 0, 0],
                [0, 1, 0, 0],
                [0, 0, 0, 0]
            ]
        ],
        kickData: [
            [0, 0], [-1, 0], [-1, 1], [0, -2], [-1, -2]
        ]
    }
};

/**
 * Tetromino class representing a single game piece
 */
export class Tetromino {
    /**
     * Create a new Tetromino
     * @param {string} type - The type of tetromino ('I', 'O', 'T', 'S', 'Z', 'J', 'L')
     * @param {number} x - Initial x position
     * @param {number} y - Initial y position
     * @param {number} rotation - Initial rotation state (0-3)
     */
    constructor(type, x = 0, y = 0, rotation = 0) {
        if (!TETROMINO_DEFINITIONS[type]) {
            throw new Error(`Invalid tetromino type: ${type}`);
        }
        
        this.type = type;
        this.x = x;
        this.y = y;
        this.rotation = rotation % 4;
        this.definition = TETROMINO_DEFINITIONS[type];
    }

    /**
     * Get the current shape matrix based on rotation
     * @returns {number[][]} 4x4 matrix representing the current shape
     */
    getShape() {
        return this.definition.shapes[this.rotation];
    }

    /**
     * Get the color of this tetromino
     * @returns {string} Hex color string
     */
    getColor() {
        return this.definition.color;
    }

    /**
     * Get the name/type of this tetromino
     * @returns {string} Single character type name
     */
    getName() {
        return this.definition.name;
    }

    /**
     * Get all occupied block positions relative to the tetromino's position
     * @returns {Array<{x: number, y: number}>} Array of block positions
     */
    getBlocks() {
        const blocks = [];
        const shape = this.getShape();
        
        for (let row = 0; row < shape.length; row++) {
            for (let col = 0; col < shape[row].length; col++) {
                if (shape[row][col] === 1) {
                    blocks.push({
                        x: this.x + col,
                        y: this.y + row
                    });
                }
            }
        }
        
        return blocks;
    }

    /**
     * Move the tetromino by the specified offset
     * @param {number} dx - Horizontal offset
     * @param {number} dy - Vertical offset
     * @returns {Tetromino} New tetromino instance at the new position
     */
    move(dx, dy) {
        return new Tetromino(this.type, this.x + dx, this.y + dy, this.rotation);
    }

    /**
     * Rotate the tetromino clockwise
     * @returns {Tetromino} New tetromino instance with updated rotation
     */
    rotate() {
        const newRotation = (this.rotation + 1) % 4;
        return new Tetromino(this.type, this.x, this.y, newRotation);
    }

    /**
     * Rotate the tetromino counter-clockwise
     * @returns {Tetromino} New tetromino instance with updated rotation
     */
    rotateCounterClockwise() {
        const newRotation = (this.rotation + 3) % 4; // +3 is equivalent to -1 mod 4
        return new Tetromino(this.type, this.x, this.y, newRotation);
    }

    /**
     * Try to rotate with SRS kick tests
     * @param {Function} isValidPosition - Function to test if position is valid
     * @param {boolean} clockwise - Direction of rotation (true for clockwise)
     * @returns {Tetromino|null} New rotated tetromino if successful, null if impossible
     */
    tryRotate(isValidPosition, clockwise = true) {
        const newRotation = clockwise ? 
            (this.rotation + 1) % 4 : 
            (this.rotation + 3) % 4;
        
        // Try the basic rotation first
        let candidate = new Tetromino(this.type, this.x, this.y, newRotation);
        if (isValidPosition(candidate)) {
            return candidate;
        }

        // If basic rotation fails, try SRS kick tests
        const kickData = this.getKickData();
        for (const [dx, dy] of kickData) {
            candidate = new Tetromino(this.type, this.x + dx, this.y + dy, newRotation);
            if (isValidPosition(candidate)) {
                return candidate;
            }
        }

        // If all kick tests fail, return null
        return null;
    }

    /**
     * Move the tetromino left
     * @returns {Tetromino} New tetromino instance moved left
     */
    moveLeft() {
        return this.move(-1, 0);
    }

    /**
     * Move the tetromino right
     * @returns {Tetromino} New tetromino instance moved right
     */
    moveRight() {
        return this.move(1, 0);
    }

    /**
     * Move the tetromino down
     * @returns {Tetromino} New tetromino instance moved down
     */
    moveDown() {
        return this.move(0, 1);
    }

    /**
     * Create a deep copy of this tetromino
     * @returns {Tetromino} New tetromino instance with same properties
     */
    clone() {
        return new Tetromino(this.type, this.x, this.y, this.rotation);
    }

    /**
     * Check if this tetromino is equal to another tetromino
     * @param {Tetromino} other - The other tetromino to compare
     * @returns {boolean} True if both tetrominoes are identical
     */
    equals(other) {
        if (!(other instanceof Tetromino)) {
            return false;
        }
        
        return this.type === other.type &&
               this.x === other.x &&
               this.y === other.y &&
               this.rotation === other.rotation;
    }

    /**
     * Get the SRS kick data for this tetromino type
     * @returns {number[][]} Array of kick offset pairs [x, y]
     */
    getKickData() {
        return this.definition.kickData;
    }

    /**
     * Create a random tetromino of any valid type
     * @param {number} x - Initial x position
     * @param {number} y - Initial y position
     * @returns {Tetromino} New random tetromino
     */
    static createRandom(x = 0, y = 0) {
        const types = Object.keys(TETROMINO_DEFINITIONS);
        const randomType = types[Math.floor(Math.random() * types.length)];
        return new Tetromino(randomType, x, y);
    }

    /**
     * Get all valid tetromino type names
     * @returns {string[]} Array of valid type names
     */
    static getValidTypes() {
        return Object.keys(TETROMINO_DEFINITIONS);
    }
}