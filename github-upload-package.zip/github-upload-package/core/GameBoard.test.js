/**
 * Unit tests for GameBoard class
 */

import { GameBoard } from '../../src/core/GameBoard.js';
import { Tetromino } from '../../src/core/Tetromino.js';

describe('GameBoard', () => {
    let gameBoard;

    beforeEach(() => {
        gameBoard = new GameBoard();
    });

    describe('constructor', () => {
        test('creates board with default dimensions', () => {
            expect(gameBoard.width).toBe(10);
            expect(gameBoard.height).toBe(20);
            expect(gameBoard.board.length).toBe(20);
            expect(gameBoard.board[0].length).toBe(10);
        });

        test('creates board with custom dimensions', () => {
            const customBoard = new GameBoard(8, 15);
            expect(customBoard.width).toBe(8);
            expect(customBoard.height).toBe(15);
            expect(customBoard.board.length).toBe(15);
            expect(customBoard.board[0].length).toBe(8);
        });

        test('initializes collision detector', () => {
            expect(gameBoard.getCollisionDetector()).toBeDefined();
        });
    });

    describe('basic operations', () => {
        test('isInBounds works correctly', () => {
            expect(gameBoard.isInBounds(0, 0)).toBe(true);
            expect(gameBoard.isInBounds(9, 19)).toBe(true);
            expect(gameBoard.isInBounds(-1, 0)).toBe(false);
            expect(gameBoard.isInBounds(10, 0)).toBe(false);
            expect(gameBoard.isInBounds(0, -1)).toBe(false);
            expect(gameBoard.isInBounds(0, 20)).toBe(false);
        });

        test('isEmpty works correctly', () => {
            expect(gameBoard.isEmpty(0, 0)).toBe(true);
            gameBoard.setCell(0, 0, '#FF0000');
            expect(gameBoard.isEmpty(0, 0)).toBe(false);
            expect(gameBoard.isEmpty(-1, 0)).toBe(false); // Out of bounds
        });

        test('getCell and setCell work correctly', () => {
            expect(gameBoard.getCell(5, 10)).toBe(0);
            gameBoard.setCell(5, 10, '#FF0000');
            expect(gameBoard.getCell(5, 10)).toBe('#FF0000');
            expect(gameBoard.getCell(-1, 0)).toBe(null); // Out of bounds
        });
    });

    describe('tetromino placement', () => {
        test('can place valid tetromino', () => {
            const tetromino = new Tetromino('I', 3, 0);
            expect(gameBoard.isValidPosition(tetromino)).toBe(true);
            
            gameBoard.placeTetromino(tetromino);
            const blocks = tetromino.getBlocks();
            
            blocks.forEach(block => {
                expect(gameBoard.getCell(block.x, block.y)).toBe(tetromino.getColor());
            });
        });

        test('cannot place tetromino at invalid position', () => {
            const tetromino = new Tetromino('I', -1, 0); // Out of bounds
            expect(gameBoard.isValidPosition(tetromino)).toBe(false);
            expect(() => gameBoard.placeTetromino(tetromino)).toThrow();
        });

        test('cannot place tetromino on occupied cells', () => {
            const tetromino1 = new Tetromino('O', 0, 0);
            const tetromino2 = new Tetromino('O', 0, 0); // Same position
            
            gameBoard.placeTetromino(tetromino1);
            expect(gameBoard.isValidPosition(tetromino2)).toBe(false);
        });
    });

    describe('line clearing', () => {
        test('detects complete lines', () => {
            // Fill a complete line
            for (let x = 0; x < 10; x++) {
                gameBoard.setCell(x, 19, '#FF0000');
            }
            
            expect(gameBoard.isLineComplete(19)).toBe(true);
            expect(gameBoard.getCompletedLines()).toEqual([19]);
            expect(gameBoard.hasCompletedLines()).toBe(true);
        });

        test('clears complete lines', () => {
            // Fill bottom line
            for (let x = 0; x < 10; x++) {
                gameBoard.setCell(x, 19, '#FF0000');
            }
            
            // Add some blocks above
            gameBoard.setCell(0, 18, '#00FF00');
            gameBoard.setCell(1, 18, '#00FF00');
            
            const linesCleared = gameBoard.clearLines();
            
            expect(linesCleared).toBe(1);
            expect(gameBoard.getCompletedLines()).toEqual([]);
            
            // Check that blocks moved down
            expect(gameBoard.getCell(0, 19)).toBe('#00FF00');
            expect(gameBoard.getCell(1, 19)).toBe('#00FF00');
            
            // Check that top line is empty
            for (let x = 0; x < 10; x++) {
                expect(gameBoard.getCell(x, 0)).toBe(0);
            }
        });

        test('clears multiple lines simultaneously', () => {
            // Fill lines 18 and 19
            for (let x = 0; x < 10; x++) {
                gameBoard.setCell(x, 18, '#FF0000');
                gameBoard.setCell(x, 19, '#FF0000');
            }
            
            const linesCleared = gameBoard.clearLines();
            expect(linesCleared).toBe(2);
            
            // Check that top two lines are empty
            for (let y = 0; y < 2; y++) {
                for (let x = 0; x < 10; x++) {
                    expect(gameBoard.getCell(x, y)).toBe(0);
                }
            }
        });

        test('line fill count is accurate', () => {
            gameBoard.setCell(0, 10, '#FF0000');
            gameBoard.setCell(1, 10, '#FF0000');
            gameBoard.setCell(2, 10, '#FF0000');
            
            expect(gameBoard.getLineFillCount(10)).toBe(3);
            expect(gameBoard.getLineFillCount(11)).toBe(0);
        });
    });

    describe('collision detection integration', () => {
        test('canMove works correctly', () => {
            const tetromino = new Tetromino('I', 5, 10);
            
            expect(gameBoard.canMove(tetromino, -1, 0)).toBe(true); // Move left
            expect(gameBoard.canMove(tetromino, 1, 0)).toBe(true);  // Move right
            expect(gameBoard.canMove(tetromino, 0, 1)).toBe(true);  // Move down
            expect(gameBoard.canMove(tetromino, -10, 0)).toBe(false); // Move out of bounds
        });

        test('tryRotate works with SRS kicks', () => {
            const tetromino = new Tetromino('T', 5, 10);
            const rotated = gameBoard.tryRotate(tetromino, true);
            
            expect(rotated).not.toBe(null);
            expect(rotated.rotation).toBe((tetromino.rotation + 1) % 4);
        });

        test('getHardDropPosition works correctly', () => {
            const tetromino = new Tetromino('I', 5, 0);
            const dropped = gameBoard.getHardDropPosition(tetromino);
            
            expect(dropped.x).toBe(tetromino.x);
            expect(dropped.y).toBeGreaterThan(tetromino.y);
            expect(gameBoard.isValidPosition(dropped)).toBe(true);
            
            // One more step down should be invalid
            const oneMoreDown = dropped.move(0, 1);
            expect(gameBoard.isValidPosition(oneMoreDown)).toBe(false);
        });
    });

    describe('board state management', () => {
        test('reset clears the board', () => {
            gameBoard.setCell(5, 10, '#FF0000');
            gameBoard.reset();
            
            expect(gameBoard.getCell(5, 10)).toBe(0);
            
            // Check entire board is empty
            for (let y = 0; y < gameBoard.height; y++) {
                for (let x = 0; x < gameBoard.width; x++) {
                    expect(gameBoard.getCell(x, y)).toBe(0);
                }
            }
        });

        test('clone creates independent copy', () => {
            gameBoard.setCell(5, 10, '#FF0000');
            const cloned = gameBoard.clone();
            
            expect(cloned.getCell(5, 10)).toBe('#FF0000');
            
            // Modify original
            gameBoard.setCell(5, 10, '#00FF00');
            
            // Clone should be unchanged
            expect(cloned.getCell(5, 10)).toBe('#FF0000');
            expect(gameBoard.getCell(5, 10)).toBe('#00FF00');
        });

        test('getBoard returns copy of board state', () => {
            gameBoard.setCell(5, 10, '#FF0000');
            const boardCopy = gameBoard.getBoard();
            
            expect(boardCopy[10][5]).toBe('#FF0000');
            
            // Modify the copy
            boardCopy[10][5] = '#00FF00';
            
            // Original should be unchanged
            expect(gameBoard.getCell(5, 10)).toBe('#FF0000');
        });
    });
});