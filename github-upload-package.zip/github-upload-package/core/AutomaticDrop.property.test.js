/**
 * Property-based tests for Automatic Drop Mechanism
 * Using fast-check for property testing
 */

import fc from 'fast-check';
import { GameEngine } from '../../src/core/GameEngine.js';
import { GameConfig } from '../../src/config/GameConfig.js';
import { Tetromino } from '../../src/core/Tetromino.js';

// Mock canvas for testing
const createMockCanvas = () => ({
    getContext: jest.fn(() => ({
        clearRect: jest.fn(),
        fillRect: jest.fn(),
        strokeRect: jest.fn(),
        fillText: jest.fn(),
        measureText: jest.fn(() => ({ width: 0 })),
        beginPath: jest.fn(),
        moveTo: jest.fn(),
        lineTo: jest.fn(),
        stroke: jest.fn(),
        fill: jest.fn(),
        save: jest.fn(),
        restore: jest.fn(),
        translate: jest.fn(),
        rotate: jest.fn(),
        scale: jest.fn()
    }))
});

describe('Automatic Drop Property Tests', () => {
    /**
     * **Feature: tetris-game, Property 4: 自动下落机制**
     * **Validates: Requirements 2.1**
     * 
     * For any game state, after the specified time interval, the active tetromino should automatically move down one space
     */
    describe('Property 4: Automatic Drop Mechanism', () => {
        test('should move tetromino down after drop interval', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 100, max: 2000 }), // drop interval
                    fc.integer({ min: 1, max: 10 }),     // level
                    (dropInterval, level) => {
                        const config = new GameConfig();
                        config.dropInterval = dropInterval;
                        
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        // Set up initial state
                        engine.gameState.level = level;
                        const initialTetromino = engine.getCurrentTetromino();
                        
                        if (!initialTetromino) {
                            return true; // Skip if no tetromino
                        }
                        
                        const initialY = initialTetromino.y;
                        
                        // Simulate time passing equal to drop interval
                        const deltaTime = engine.gameState.getDropInterval();
                        engine.dropTimer = deltaTime;
                        
                        // Update the game
                        engine.update(0);
                        
                        const currentTetromino = engine.getCurrentTetromino();
                        
                        if (currentTetromino && currentTetromino.type === initialTetromino.type) {
                            // If same tetromino type, it should have moved down or been locked
                            // (We can't guarantee same instance due to locking mechanism)
                            if (currentTetromino.y === initialY) {
                                // If Y didn't change, the piece must have been locked
                                // and a new piece spawned at the top
                                expect(currentTetromino.y).toBeLessThanOrEqual(initialY);
                            } else {
                                // If Y changed, it should be exactly one position down
                                expect(currentTetromino.y).toBe(initialY + 1);
                            }
                        }
                        
                        // Drop timer should be reset after update
                        expect(engine.getDropTimer()).toBe(0);
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should respect level-based drop intervals', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 1, max: 20 }), // level
                    (level) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        // Set the level
                        engine.gameState.level = level;
                        
                        // Get the drop interval for this level
                        const dropInterval = engine.gameState.getDropInterval();
                        
                        // Drop interval should be positive and decrease with higher levels
                        expect(dropInterval).toBeGreaterThan(0);
                        
                        // For higher levels, drop interval should be smaller (faster)
                        if (level > 1) {
                            engine.gameState.level = 1;
                            const level1Interval = engine.gameState.getDropInterval();
                            expect(dropInterval).toBeLessThanOrEqual(level1Interval);
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should accumulate drop timer correctly', () => {
            fc.assert(
                fc.property(
                    fc.array(fc.integer({ min: 10, max: 100 }), { minLength: 1, maxLength: 10 }), // delta times
                    (deltaTimes) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        const initialDropTimer = engine.getDropTimer();
                        let expectedTimer = initialDropTimer;
                        
                        // Apply multiple small updates
                        for (const deltaTime of deltaTimes) {
                            const timerBefore = engine.getDropTimer();
                            engine.update(deltaTime);
                            
                            expectedTimer += deltaTime;
                            
                            // If drop didn't occur, timer should accumulate
                            if (expectedTimer < engine.gameState.getDropInterval()) {
                                expect(engine.getDropTimer()).toBe(expectedTimer);
                            } else {
                                // If drop occurred, timer should reset
                                expect(engine.getDropTimer()).toBe(0);
                                expectedTimer = 0;
                            }
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should not drop when game is paused', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 100, max: 1000 }), // delta time
                    (deltaTime) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        // Pause the game
                        engine.pause();
                        
                        const initialTetromino = engine.getCurrentTetromino();
                        const initialDropTimer = engine.getDropTimer();
                        
                        if (!initialTetromino) {
                            return true; // Skip if no tetromino
                        }
                        
                        const initialY = initialTetromino.y;
                        
                        // Try to update while paused
                        engine.update(deltaTime);
                        
                        const currentTetromino = engine.getCurrentTetromino();
                        
                        // Tetromino should not have moved
                        if (currentTetromino) {
                            expect(currentTetromino.y).toBe(initialY);
                        }
                        
                        // Drop timer should not have changed
                        expect(engine.getDropTimer()).toBe(initialDropTimer);
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should not drop when game is over', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 100, max: 1000 }), // delta time
                    (deltaTime) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        // Set game over state
                        engine.gameState.setGameOver(true);
                        
                        const initialTetromino = engine.getCurrentTetromino();
                        const initialDropTimer = engine.getDropTimer();
                        
                        if (!initialTetromino) {
                            return true; // Skip if no tetromino
                        }
                        
                        const initialY = initialTetromino.y;
                        
                        // Try to update while game is over
                        engine.update(deltaTime);
                        
                        const currentTetromino = engine.getCurrentTetromino();
                        
                        // Tetromino should not have moved
                        if (currentTetromino) {
                            expect(currentTetromino.y).toBe(initialY);
                        }
                        
                        // Drop timer should not have changed
                        expect(engine.getDropTimer()).toBe(initialDropTimer);
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should handle multiple drops in sequence', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 2, max: 5 }), // number of drops
                    (numDrops) => {
                        const config = new GameConfig();
                        config.dropInterval = 100; // Fast drops for testing
                        
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        let dropsExecuted = 0;
                        
                        for (let i = 0; i < numDrops; i++) {
                            const initialTetromino = engine.getCurrentTetromino();
                            
                            if (!initialTetromino) {
                                break; // Game might be over
                            }
                            
                            const initialY = initialTetromino.y;
                            
                            // Trigger a drop
                            engine.dropTimer = config.dropInterval;
                            engine.update(0);
                            
                            const currentTetromino = engine.getCurrentTetromino();
                            
                            if (currentTetromino) {
                                // Either moved down or new piece spawned
                                if (currentTetromino === initialTetromino) {
                                    expect(currentTetromino.y).toBeGreaterThan(initialY);
                                }
                                dropsExecuted++;
                            }
                            
                            // Timer should be reset
                            expect(engine.getDropTimer()).toBe(0);
                            
                            if (engine.isGameOver()) {
                                break; // Stop if game over
                            }
                        }
                        
                        // Should have executed at least one drop
                        expect(dropsExecuted).toBeGreaterThan(0);
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should maintain consistent timing behavior', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 200, max: 800 }), // drop interval
                    fc.integer({ min: 1, max: 5 }),     // level
                    (baseInterval, level) => {
                        const config = new GameConfig();
                        config.dropInterval = baseInterval;
                        
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        engine.gameState.level = level;
                        
                        const dropInterval = engine.gameState.getDropInterval();
                        
                        // Test timing consistency over multiple updates
                        const smallDelta = Math.floor(dropInterval / 3);
                        
                        // First update - should not trigger drop
                        engine.update(smallDelta);
                        expect(engine.getDropTimer()).toBe(smallDelta);
                        
                        // Second update - should not trigger drop
                        engine.update(smallDelta);
                        expect(engine.getDropTimer()).toBe(smallDelta * 2);
                        
                        // Third update - should trigger drop (add extra to ensure it exceeds interval)
                        const finalDelta = dropInterval - (smallDelta * 2) + 1;
                        engine.update(finalDelta);
                        expect(engine.getDropTimer()).toBe(0);
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should handle edge case of zero delta time', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 1, max: 10 }), // level
                    (level) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        engine.gameState.level = level;
                        
                        const initialDropTimer = engine.getDropTimer();
                        const initialTetromino = engine.getCurrentTetromino();
                        
                        // Update with zero delta time
                        engine.update(0);
                        
                        // Timer should not change
                        expect(engine.getDropTimer()).toBe(initialDropTimer);
                        
                        // Tetromino should not move due to time
                        const currentTetromino = engine.getCurrentTetromino();
                        if (initialTetromino && currentTetromino && 
                            initialTetromino.type === currentTetromino.type) {
                            expect(currentTetromino.y).toBe(initialTetromino.y);
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });
    });
});