import fc from 'fast-check';
import { GameState } from '../../src/core/GameState.js';
import { GameBoard } from '../../src/core/GameBoard.js';
import { Tetromino } from '../../src/core/Tetromino.js';
import { GameConfig } from '../../src/config/GameConfig.js';

describe('Game Over Conditions Property Tests', () => {
    let gameState;
    let gameBoard;
    let config;

    beforeEach(() => {
        config = new GameConfig();
        gameState = new GameState(config);
        gameBoard = new GameBoard(config.boardWidth, config.boardHeight);
    });

    /**
     * **Feature: tetris-game, Property 6: 游戏结束条件**
     * **Validates: Requirements 2.5**
     * 
     * For any game state where the top of the board is occupied and prevents
     * new tetromino generation, the system should trigger game over
     */
    test('Property 6: Game over condition detection', () => {
        fc.assert(fc.property(
            fc.boolean(), // gameOverState
            (shouldBeGameOver) => {
                gameState.reset();
                gameState.setGameOver(shouldBeGameOver);
                
                // Game over state should be settable and retrievable
                expect(gameState.checkGameOver()).toBe(shouldBeGameOver);
                expect(gameState.isGameOver).toBe(shouldBeGameOver);
                
                // Game state should reflect the game over condition
                const state = gameState.getState();
                expect(state.isGameOver).toBe(shouldBeGameOver);
            }
        ), { numRuns: 100 });
    });

    /**
     * Property: Game over state should be persistent through serialization
     */
    test('Property: Game over state serialization consistency', () => {
        fc.assert(fc.property(
            fc.boolean(), // gameOverState
            fc.integer({ min: 0, max: 100000 }), // score
            fc.integer({ min: 1, max: 20 }), // level
            fc.integer({ min: 0, max: 200 }), // lines
            (gameOverState, score, level, lines) => {
                gameState.reset();
                gameState.score = score;
                gameState.level = level;
                gameState.lines = lines;
                gameState.setGameOver(gameOverState);
                
                // Serialize and deserialize
                const serialized = gameState.serialize();
                const newGameState = new GameState(config);
                const success = newGameState.deserialize(serialized);
                
                expect(success).toBe(true);
                expect(newGameState.checkGameOver()).toBe(gameOverState);
                expect(newGameState.isGameOver).toBe(gameOverState);
                expect(newGameState.score).toBe(score);
                expect(newGameState.level).toBe(level);
                expect(newGameState.lines).toBe(lines);
            }
        ), { numRuns: 100 });
    });

    /**
     * Property: Game over should not affect scoring calculations
     */
    test('Property: Game over state independence from scoring', () => {
        fc.assert(fc.property(
            fc.boolean(), // gameOverState
            fc.integer({ min: 1, max: 4 }), // linesCleared
            (gameOverState, linesCleared) => {
                gameState.reset();
                gameState.setGameOver(gameOverState);
                
                const initialScore = gameState.score;
                const initialLines = gameState.lines;
                const initialLevel = gameState.level;
                
                // Update score should work regardless of game over state
                const result = gameState.updateScore(linesCleared);
                
                // Score should still be calculated correctly
                expect(result.score).toBeGreaterThan(0);
                expect(gameState.score).toBeGreaterThan(initialScore);
                expect(gameState.lines).toBe(initialLines + linesCleared);
                
                // Game over state should remain unchanged by scoring
                expect(gameState.checkGameOver()).toBe(gameOverState);
                expect(gameState.isGameOver).toBe(gameOverState);
            }
        ), { numRuns: 100 });
    });

    /**
     * Property: Reset should clear game over state
     */
    test('Property: Reset clears game over state', () => {
        fc.assert(fc.property(
            fc.boolean(), // initialGameOverState
            fc.integer({ min: 0, max: 100000 }), // score
            fc.integer({ min: 1, max: 20 }), // level
            fc.integer({ min: 0, max: 200 }), // lines
            (initialGameOverState, score, level, lines) => {
                // Set up game state with various values
                gameState.score = score;
                gameState.level = level;
                gameState.lines = lines;
                gameState.setGameOver(initialGameOverState);
                
                // Verify initial state
                expect(gameState.checkGameOver()).toBe(initialGameOverState);
                
                // Reset should clear everything including game over
                gameState.reset();
                
                expect(gameState.checkGameOver()).toBe(false);
                expect(gameState.isGameOver).toBe(false);
                expect(gameState.score).toBe(0);
                expect(gameState.level).toBe(1);
                expect(gameState.lines).toBe(0);
                expect(gameState.isPaused).toBe(false);
            }
        ), { numRuns: 100 });
    });

    /**
     * Property: Game over state should be independent of pause state
     */
    test('Property: Game over and pause state independence', () => {
        fc.assert(fc.property(
            fc.boolean(), // gameOverState
            fc.boolean(), // pauseState
            (gameOverState, pauseState) => {
                gameState.reset();
                gameState.setGameOver(gameOverState);
                gameState.setPaused(pauseState);
                
                // Both states should be independent
                expect(gameState.checkGameOver()).toBe(gameOverState);
                expect(gameState.isGameOver).toBe(gameOverState);
                expect(gameState.isPaused).toBe(pauseState);
                
                // Changing one should not affect the other
                gameState.setPaused(!pauseState);
                expect(gameState.checkGameOver()).toBe(gameOverState);
                
                gameState.setGameOver(!gameOverState);
                expect(gameState.isPaused).toBe(!pauseState);
            }
        ), { numRuns: 100 });
    });

    /**
     * Property: Game board top occupation simulation
     */
    test('Property: Top board occupation detection', () => {
        fc.assert(fc.property(
            fc.array(fc.integer({ min: 0, max: 9 }), { minLength: 1, maxLength: 5 }), // columns to fill
            fc.integer({ min: 15, max: 19 }), // fill height (near top)
            (columnsToFill, fillHeight) => {
                gameBoard.reset();
                
                // Fill specified columns up to fillHeight to simulate game over condition
                for (const col of columnsToFill) {
                    for (let row = gameBoard.height - 1; row >= fillHeight; row--) {
                        gameBoard.setCell(col, row, 1); // Fill with blocks
                    }
                }
                
                // Create a simple mock tetromino for testing spawn position
                const mockTetromino = {
                    x: Math.floor(gameBoard.width / 2) - 1,
                    y: 0,
                    getBlocks: () => [
                        { x: Math.floor(gameBoard.width / 2) - 1, y: 0 },
                        { x: Math.floor(gameBoard.width / 2), y: 0 },
                        { x: Math.floor(gameBoard.width / 2) - 1, y: 1 },
                        { x: Math.floor(gameBoard.width / 2), y: 1 }
                    ]
                };
                
                const canPlace = gameBoard.isValidPosition(mockTetromino);
                
                if (!canPlace) {
                    // This would be a game over condition
                    gameState.setGameOver(true);
                    expect(gameState.checkGameOver()).toBe(true);
                } else {
                    // Game can continue
                    gameState.setGameOver(false);
                    expect(gameState.checkGameOver()).toBe(false);
                }
                
                // Game over state should be consistent with ability to place pieces
                expect(gameState.checkGameOver()).toBe(!canPlace);
            }
        ), { numRuns: 50 });
    });
});