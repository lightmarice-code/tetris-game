/**
 * Property-based tests for Piece Locking and Generation
 * Using fast-check for property testing
 */

import fc from 'fast-check';
import { GameEngine } from '../../src/core/GameEngine.js';
import { GameConfig } from '../../src/config/GameConfig.js';
import { Tetromino, TETROMINO_DEFINITIONS } from '../../src/core/Tetromino.js';
import { GameBoard } from '../../src/core/GameBoard.js';

// Mock canvas for testing
const createMockCanvas = () => ({
    getContext: jest.fn(() => ({
        clearRect: jest.fn(),
        fillRect: jest.fn(),
        strokeRect: jest.fn(),
        fillText: jest.fn(),
        measureText: jest.fn(() => ({ width: 0 })),
        beginPath: jest.fn(),
        moveTo: jest.fn(),
        lineTo: jest.fn(),
        stroke: jest.fn(),
        fill: jest.fn(),
        save: jest.fn(),
        restore: jest.fn(),
        translate: jest.fn(),
        rotate: jest.fn(),
        scale: jest.fn()
    }))
});

describe('Piece Locking and Generation Property Tests', () => {
    /**
     * **Feature: tetris-game, Property 5: 方块固定和新方块生成**
     * **Validates: Requirements 2.2, 2.3**
     * 
     * For any tetromino that cannot continue falling, the system should lock it in place and immediately generate a new active tetromino
     */
    describe('Property 5: Piece Locking and New Piece Generation', () => {
        test('should lock piece when it cannot move down further', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 0, max: 6 }), // x position (safe range)
                    (x) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        const board = engine.getGameBoard();
                        
                        // Fill the bottom row to create a surface for the piece to land on
                        for (let i = 0; i < config.boardWidth; i++) {
                            board.setCell(i, config.boardHeight - 1, '#FF0000');
                        }
                        
                        // Get the current tetromino that was naturally spawned
                        const initialTetromino = engine.getCurrentTetromino();
                        
                        // Move it to a position where it can drop and lock
                        if (initialTetromino) {
                            engine.currentTetromino = new Tetromino(
                                initialTetromino.type,
                                x,
                                config.boardHeight - 3,
                                initialTetromino.rotation
                            );
                        }
                        
                        const tetrominoBeforeDrop = engine.getCurrentTetromino();
                        
                        // Use hard drop to force locking
                        const dropDistance = engine.hardDrop();
                        
                        // After hard drop, should have a new current tetromino
                        const newCurrentTetromino = engine.getCurrentTetromino();
                        const nextTetromino = engine.getNextTetromino();
                        const isGameOver = engine.isGameOver();
                        
                        // Should have a current tetromino (new one)
                        expect(newCurrentTetromino).toBeTruthy();
                        
                        // Should have a next tetromino
                        expect(nextTetromino).toBeTruthy();
                        
                        // If the drop was successful and game is not over, should have a new piece
                        if (dropDistance > 0 && !isGameOver && tetrominoBeforeDrop) {
                            // New tetromino should be different from the one before drop
                            expect(newCurrentTetromino).not.toBe(tetrominoBeforeDrop);
                            
                            // New tetromino should be at spawn position
                            expect(newCurrentTetromino.y).toBe(0);
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should generate new tetromino immediately after locking', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 1, max: 3 }), // number of locks to test
                    (numLocks) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        for (let i = 0; i < numLocks && !engine.isGameOver(); i++) {
                            const beforeCurrent = engine.getCurrentTetromino();
                            const beforeNext = engine.getNextTetromino();
                            const beforeNextType = beforeNext ? beforeNext.type : null;
                            
                            if (beforeCurrent) {
                                // Hard drop to lock immediately
                                const dropDistance = engine.hardDrop();
                                
                                const afterCurrent = engine.getCurrentTetromino();
                                const afterNext = engine.getNextTetromino();
                                
                                // Should have a new current tetromino
                                expect(afterCurrent).toBeTruthy();
                                
                                // Should have a new next tetromino
                                expect(afterNext).toBeTruthy();
                                
                                // If the drop was successful and game is not over
                                if (dropDistance > 0 && !engine.isGameOver()) {
                                    // The old "next" should now be "current"
                                    if (afterCurrent && beforeNextType) {
                                        expect(afterCurrent.type).toBe(beforeNextType);
                                    }
                                    
                                    // Should have generated a completely new "next" tetromino
                                    if (afterNext && beforeNext) {
                                        // It's a new instance (even if same type)
                                        expect(afterNext).not.toBe(beforeNext);
                                    }
                                }
                            }
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should maintain valid tetromino types after locking and generation', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 1, max: 5 }), // number of lock cycles
                    (numCycles) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        const validTypes = Object.keys(TETROMINO_DEFINITIONS);
                        
                        for (let i = 0; i < numCycles && !engine.isGameOver(); i++) {
                            const currentTetromino = engine.getCurrentTetromino();
                            const nextTetromino = engine.getNextTetromino();
                            
                            // Both should be valid tetromino types
                            if (currentTetromino) {
                                expect(validTypes).toContain(currentTetromino.type);
                                expect(currentTetromino).toBeInstanceOf(Tetromino);
                            }
                            
                            if (nextTetromino) {
                                expect(validTypes).toContain(nextTetromino.type);
                                expect(nextTetromino).toBeInstanceOf(Tetromino);
                            }
                            
                            // Force a hard drop to lock the piece
                            engine.hardDrop();
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should place locked pieces on the board correctly', () => {
            fc.assert(
                fc.property(
                    fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
                    fc.integer({ min: 0, max: 6 }), // x position (safe range)
                    (tetrominoType, x) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        const board = engine.getGameBoard();
                        const initialBoard = board.getBoard();
                        
                        // Count initial filled cells
                        let initialFilledCells = 0;
                        for (let y = 0; y < config.boardHeight; y++) {
                            for (let x = 0; x < config.boardWidth; x++) {
                                if (initialBoard[y][x] !== 0) {
                                    initialFilledCells++;
                                }
                            }
                        }
                        
                        // Create a tetromino near the bottom
                        const tetromino = new Tetromino(tetrominoType, x, config.boardHeight - 3, 0);
                        engine.currentTetromino = tetromino;
                        
                        // Hard drop to lock it
                        const dropDistance = engine.hardDrop();
                        
                        if (dropDistance > 0 && !engine.isGameOver()) {
                            const finalBoard = board.getBoard();
                            
                            // Count final filled cells
                            let finalFilledCells = 0;
                            for (let y = 0; y < config.boardHeight; y++) {
                                for (let x = 0; x < config.boardWidth; x++) {
                                    if (finalBoard[y][x] !== 0) {
                                        finalFilledCells++;
                                    }
                                }
                            }
                            
                            // Should have exactly 4 more filled cells (tetromino has 4 blocks)
                            expect(finalFilledCells).toBe(initialFilledCells + 4);
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should spawn new tetromino at correct position', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 1, max: 3 }), // number of spawns to test
                    (numSpawns) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        for (let i = 0; i < numSpawns && !engine.isGameOver(); i++) {
                            // Force spawn of new tetromino
                            engine.spawnNewTetromino();
                            
                            const currentTetromino = engine.getCurrentTetromino();
                            
                            if (currentTetromino) {
                                // Should spawn near the center horizontally
                                const expectedX = Math.floor(config.boardWidth / 2) - 2;
                                expect(currentTetromino.x).toBe(expectedX);
                                
                                // Should spawn at the top
                                expect(currentTetromino.y).toBe(0);
                                
                                // Should be a valid tetromino
                                expect(Object.keys(TETROMINO_DEFINITIONS)).toContain(currentTetromino.type);
                            }
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should handle rapid locking without losing pieces', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 2, max: 8 }), // number of rapid locks
                    (numLocks) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        let successfulLocks = 0;
                        
                        for (let i = 0; i < numLocks && !engine.isGameOver(); i++) {
                            const beforeCurrent = engine.getCurrentTetromino();
                            const beforeNext = engine.getNextTetromino();
                            
                            if (beforeCurrent) {
                                // Hard drop to lock immediately
                                engine.hardDrop();
                                
                                const afterCurrent = engine.getCurrentTetromino();
                                const afterNext = engine.getNextTetromino();
                                
                                // Should always have a current and next tetromino after locking
                                expect(afterCurrent).toBeTruthy();
                                expect(afterNext).toBeTruthy();
                                
                                // The previous "next" should become "current" (if not game over)
                                if (afterCurrent && beforeNext && !engine.isGameOver()) {
                                    expect(afterCurrent.type).toBe(beforeNext.type);
                                }
                                
                                successfulLocks++;
                            }
                        }
                        
                        // Should have successfully locked at least one piece
                        expect(successfulLocks).toBeGreaterThan(0);
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should maintain piece queue consistency', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 3, max: 10 }), // number of operations
                    (numOps) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        const validTypes = Object.keys(TETROMINO_DEFINITIONS);
                        
                        for (let i = 0; i < numOps && !engine.isGameOver(); i++) {
                            const current = engine.getCurrentTetromino();
                            const next = engine.getNextTetromino();
                            
                            // Both should always exist and be valid
                            expect(current).toBeTruthy();
                            expect(next).toBeTruthy();
                            
                            if (current && next) {
                                expect(validTypes).toContain(current.type);
                                expect(validTypes).toContain(next.type);
                                
                                // They should be different instances
                                expect(current).not.toBe(next);
                            }
                            
                            // Lock the current piece
                            engine.hardDrop();
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });

        test('should handle locking when board is nearly full', () => {
            fc.assert(
                fc.property(
                    fc.integer({ min: 15, max: 19 }), // fill height (near top)
                    (fillHeight) => {
                        const config = new GameConfig();
                        const canvas = createMockCanvas();
                        const engine = new GameEngine(canvas, config);
                        
                        const board = engine.getGameBoard();
                        
                        // Fill the board up to fillHeight
                        for (let y = fillHeight; y < config.boardHeight; y++) {
                            for (let x = 0; x < config.boardWidth - 1; x++) { // Leave one column empty
                                board.setCell(x, y, '#FF0000');
                            }
                        }
                        
                        const initialCurrent = engine.getCurrentTetromino();
                        
                        if (initialCurrent) {
                            // Try to lock the piece
                            engine.hardDrop();
                            
                            // After locking, should either have a new piece or game over
                            const finalCurrent = engine.getCurrentTetromino();
                            const isGameOver = engine.isGameOver();
                            
                            if (!isGameOver) {
                                // If not game over, should have a new current piece
                                expect(finalCurrent).toBeTruthy();
                                
                                if (finalCurrent) {
                                    // New piece should be different from the initial one
                                    expect(finalCurrent).not.toBe(initialCurrent);
                                }
                            }
                            
                            // Game state should be consistent
                            expect(typeof isGameOver).toBe('boolean');
                        }
                        
                        return true;
                    }
                ),
                { numRuns: 100 }
            );
        });
    });
});