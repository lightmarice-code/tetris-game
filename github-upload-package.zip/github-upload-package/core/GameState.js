import { ScoringSystem } from './ScoringSystem.js';

/**
 * GameState class manages the current state of the Tetris game
 * Handles score, level, lines cleared, and game over conditions
 */
export class GameState {
    constructor(config) {
        this.config = config;
        this.scoringSystem = new ScoringSystem(config);
        this.reset();
    }

    /**
     * Reset all game state to initial values
     */
    reset() {
        this.score = 0;
        this.level = 1;
        this.lines = 0;
        this.isGameOver = false;
        this.isPaused = false;
        this.dropTimer = 0;
        this.lastUpdateTime = 0;
    }

    /**
     * Update score based on number of lines cleared
     * @param {number} linesCleared - Number of lines cleared (1-4)
     * @returns {Object} Scoring information
     */
    updateScore(linesCleared) {
        if (linesCleared <= 0 || linesCleared > 4) {
            return { score: 0, levelUp: false };
        }

        const scoreEarned = this.scoringSystem.calculateScore(linesCleared, this.level);
        this.score += scoreEarned;
        this.lines += linesCleared;

        // Check for level up
        const levelUp = this.updateLevel();

        return {
            score: scoreEarned,
            levelUp,
            scoringInfo: this.scoringSystem.getScoringInfo(linesCleared, this.level)
        };
    }

    /**
     * Update game level based on lines cleared
     * @returns {boolean} True if level increased
     */
    updateLevel() {
        const newLevel = this.scoringSystem.calculateLevel(this.lines);
        const levelUp = newLevel > this.level;
        if (levelUp) {
            this.level = newLevel;
        }
        return levelUp;
    }

    /**
     * Get current drop interval based on level
     * @returns {number} Drop interval in milliseconds
     */
    getDropInterval() {
        return this.scoringSystem.calculateDropInterval(this.level);
    }

    /**
     * Check if game is over
     * @returns {boolean} True if game is over
     */
    checkGameOver() {
        return this.isGameOver;
    }

    /**
     * Set game over state
     * @param {boolean} gameOver - Game over state
     */
    setGameOver(gameOver = true) {
        this.isGameOver = gameOver;
    }

    /**
     * Pause/unpause the game
     * @param {boolean} paused - Pause state
     */
    setPaused(paused) {
        this.isPaused = paused;
    }

    /**
     * Serialize game state to JSON string
     * @returns {string} Serialized game state
     */
    serialize() {
        return JSON.stringify({
            score: this.score,
            level: this.level,
            lines: this.lines,
            isGameOver: this.isGameOver,
            isPaused: this.isPaused,
            dropTimer: this.dropTimer,
            lastUpdateTime: this.lastUpdateTime
        });
    }

    /**
     * Deserialize game state from JSON string
     * @param {string} data - Serialized game state
     * @returns {boolean} True if deserialization was successful
     */
    deserialize(data) {
        try {
            const state = JSON.parse(data);
            
            // Validate required properties
            if (typeof state.score !== 'number' || 
                typeof state.level !== 'number' || 
                typeof state.lines !== 'number') {
                return false;
            }

            this.score = state.score;
            this.level = state.level;
            this.lines = state.lines;
            this.isGameOver = Boolean(state.isGameOver);
            this.isPaused = Boolean(state.isPaused);
            this.dropTimer = state.dropTimer || 0;
            this.lastUpdateTime = state.lastUpdateTime || 0;

            return true;
        } catch (error) {
            console.error('Failed to deserialize game state:', error);
            return false;
        }
    }

    /**
     * Get current game state as object
     * @returns {Object} Current game state
     */
    getState() {
        return {
            score: this.score,
            level: this.level,
            lines: this.lines,
            isGameOver: this.isGameOver,
            isPaused: this.isPaused,
            dropInterval: this.getDropInterval()
        };
    }
}