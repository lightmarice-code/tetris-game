/**
 * Property-based tests for GameBoard collision detection
 * **Feature: tetris-game, Property 3: 碰撞检测阻止无效操作**
 * **Validates: Requirements 1.5**
 */

import fc from 'fast-check';
import { GameBoard } from '../../src/core/GameBoard.js';
import { Tetromino, TETROMINO_DEFINITIONS } from '../../src/core/Tetromino.js';

describe('GameBoard Collision Detection Properties', () => {
    /**
     * **Feature: tetris-game, Property 3: 碰撞检测阻止无效操作**
     * For any move or rotation operation that would cause collision,
     * the system should prevent the operation and keep the piece in original position
     */
    test('collision detection prevents invalid operations', () => {
        fc.assert(fc.property(
            // Generate random tetromino type
            fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
            // Generate random position
            fc.integer({ min: -5, max: 15 }),
            fc.integer({ min: -5, max: 25 }),
            // Generate random rotation
            fc.integer({ min: 0, max: 3 }),
            // Generate random move direction
            fc.constantFrom(
                { dx: -1, dy: 0, name: 'left' },
                { dx: 1, dy: 0, name: 'right' },
                { dx: 0, dy: 1, name: 'down' },
                { dx: 0, dy: -1, name: 'up' }
            ),
            (tetrominoType, x, y, rotation, move) => {
                const gameBoard = new GameBoard();
                const tetromino = new Tetromino(tetrominoType, x, y, rotation);
                
                // Check if the move would be valid
                const canMove = gameBoard.canMove(tetromino, move.dx, move.dy);
                const movedTetromino = tetromino.move(move.dx, move.dy);
                const isValidAfterMove = gameBoard.isValidPosition(movedTetromino);
                
                // Property: canMove should match isValidPosition for the moved piece
                expect(canMove).toBe(isValidAfterMove);
                
                // If move is invalid, original position should remain unchanged
                if (!canMove) {
                    // The tetromino object itself should be immutable
                    expect(tetromino.x).toBe(x);
                    expect(tetromino.y).toBe(y);
                    expect(tetromino.rotation).toBe(rotation);
                    expect(tetromino.type).toBe(tetrominoType);
                }
            }
        ), { numRuns: 100 });
    });

    /**
     * Test that boundary collisions are properly detected
     */
    test('boundary collision detection is consistent', () => {
        fc.assert(fc.property(
            fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
            fc.integer({ min: -10, max: 20 }),
            fc.integer({ min: -10, max: 30 }),
            fc.integer({ min: 0, max: 3 }),
            (tetrominoType, x, y, rotation) => {
                const gameBoard = new GameBoard();
                const tetromino = new Tetromino(tetrominoType, x, y, rotation);
                const collisionDetector = gameBoard.getCollisionDetector();
                
                const isValid = gameBoard.isValidPosition(tetromino);
                const hasBoundaryCollision = collisionDetector.hasBoundaryCollision(tetromino);
                const hasPieceCollision = collisionDetector.hasPieceCollision(tetromino);
                
                // Property: A position is valid if and only if it has no collisions
                expect(isValid).toBe(!hasBoundaryCollision && !hasPieceCollision);
            }
        ), { numRuns: 100 });
    });

    /**
     * Test that rotation collision detection works with SRS kicks
     */
    test('rotation collision detection with SRS kicks', () => {
        fc.assert(fc.property(
            fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
            fc.integer({ min: 0, max: 9 }),
            fc.integer({ min: 0, max: 19 }),
            fc.integer({ min: 0, max: 3 }),
            fc.boolean(),
            (tetrominoType, x, y, rotation, clockwise) => {
                const gameBoard = new GameBoard();
                const tetromino = new Tetromino(tetrominoType, x, y, rotation);
                
                // Only test if original position is valid
                if (!gameBoard.isValidPosition(tetromino)) {
                    return;
                }
                
                const rotatedTetromino = gameBoard.tryRotate(tetromino, clockwise);
                
                // Property: If rotation succeeds, the result must be in a valid position
                if (rotatedTetromino !== null) {
                    expect(gameBoard.isValidPosition(rotatedTetromino)).toBe(true);
                    
                    // The rotation state should have changed
                    const expectedRotation = clockwise ? 
                        (rotation + 1) % 4 : 
                        (rotation + 3) % 4;
                    expect(rotatedTetromino.rotation).toBe(expectedRotation);
                }
                
                // Property: Original tetromino should remain unchanged
                expect(tetromino.x).toBe(x);
                expect(tetromino.y).toBe(y);
                expect(tetromino.rotation).toBe(rotation);
                expect(tetromino.type).toBe(tetrominoType);
            }
        ), { numRuns: 100 });
    });

    /**
     * Test that hard drop always results in a valid position
     */
    test('hard drop results in valid lowest position', () => {
        fc.assert(fc.property(
            fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
            fc.integer({ min: 0, max: 9 }),
            fc.integer({ min: 0, max: 10 }),
            fc.integer({ min: 0, max: 3 }),
            (tetrominoType, x, y, rotation) => {
                const gameBoard = new GameBoard();
                const tetromino = new Tetromino(tetrominoType, x, y, rotation);
                
                // Only test if original position is valid
                if (!gameBoard.isValidPosition(tetromino)) {
                    return;
                }
                
                const droppedTetromino = gameBoard.getHardDropPosition(tetromino);
                
                // Property: Dropped position must be valid
                expect(gameBoard.isValidPosition(droppedTetromino)).toBe(true);
                
                // Property: Dropped position should be at or below original position
                expect(droppedTetromino.y).toBeGreaterThanOrEqual(tetromino.y);
                
                // Property: Horizontal position and rotation should be unchanged
                expect(droppedTetromino.x).toBe(tetromino.x);
                expect(droppedTetromino.rotation).toBe(tetromino.rotation);
                expect(droppedTetromino.type).toBe(tetromino.type);
                
                // Property: One more step down should be invalid
                const oneMoreDown = droppedTetromino.move(0, 1);
                expect(gameBoard.isValidPosition(oneMoreDown)).toBe(false);
            }
        ), { numRuns: 100 });
    });

    /**
     * Test collision detection with placed pieces
     */
    test('piece collision detection with placed pieces', () => {
        fc.assert(fc.property(
            fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
            fc.integer({ min: 0, max: 9 }),
            fc.integer({ min: 15, max: 19 }),
            fc.integer({ min: 0, max: 3 }),
            (tetrominoType, x, y, rotation) => {
                const gameBoard = new GameBoard();
                
                // Place a piece at the bottom
                const bottomPiece = new Tetromino('I', 0, 19, 0);
                if (gameBoard.isValidPosition(bottomPiece)) {
                    gameBoard.placeTetromino(bottomPiece);
                }
                
                const testTetromino = new Tetromino(tetrominoType, x, y, rotation);
                const isValid = gameBoard.isValidPosition(testTetromino);
                const collisionDetector = gameBoard.getCollisionDetector();
                const hasPieceCollision = collisionDetector.hasPieceCollision(testTetromino);
                const hasBoundaryCollision = collisionDetector.hasBoundaryCollision(testTetromino);
                
                // Property: Position is valid if and only if no collisions occur
                expect(isValid).toBe(!hasPieceCollision && !hasBoundaryCollision);
            }
        ), { numRuns: 100 });
    });
});