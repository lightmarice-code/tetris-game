/**
 * ScoringSystem class handles all scoring calculations and level progression
 * Implements the standard Tetris scoring system with level-based multipliers
 */
export class ScoringSystem {
    constructor(config) {
        this.config = config;
    }

    /**
     * Calculate score for cleared lines
     * @param {number} linesCleared - Number of lines cleared (1-4)
     * @param {number} level - Current game level
     * @returns {number} Score points earned
     */
    calculateScore(linesCleared, level) {
        if (linesCleared <= 0 || linesCleared > 4 || level < 1) {
            return 0;
        }

        let baseScore = 0;
        switch (linesCleared) {
            case 1:
                baseScore = this.config.scoring.single;
                break;
            case 2:
                baseScore = this.config.scoring.double;
                break;
            case 3:
                baseScore = this.config.scoring.triple;
                break;
            case 4:
                baseScore = this.config.scoring.tetris;
                break;
        }

        // Apply level multiplier - higher levels give more points
        return baseScore * level;
    }

    /**
     * Calculate new level based on total lines cleared
     * @param {number} totalLines - Total lines cleared in the game
     * @returns {number} New level (minimum 1)
     */
    calculateLevel(totalLines) {
        if (totalLines < 0) {
            return 1;
        }
        
        // Level increases every 10 lines, starting at level 1
        return Math.floor(totalLines / 10) + 1;
    }

    /**
     * Calculate drop interval for current level
     * @param {number} level - Current game level
     * @returns {number} Drop interval in milliseconds
     */
    calculateDropInterval(level) {
        if (level < 1) {
            level = 1;
        }

        // Each level reduces drop time by the multiplier
        const interval = this.config.dropInterval * Math.pow(this.config.levelSpeedMultiplier, level - 1);
        
        // Ensure minimum drop interval for playability
        return Math.max(50, Math.floor(interval));
    }

    /**
     * Check if level should increase based on lines cleared
     * @param {number} currentLevel - Current level
     * @param {number} totalLines - Total lines cleared
     * @returns {boolean} True if level should increase
     */
    shouldLevelUp(currentLevel, totalLines) {
        const expectedLevel = this.calculateLevel(totalLines);
        return expectedLevel > currentLevel;
    }

    /**
     * Get scoring information for display
     * @param {number} linesCleared - Number of lines cleared
     * @param {number} level - Current level
     * @returns {Object} Scoring information
     */
    getScoringInfo(linesCleared, level) {
        const score = this.calculateScore(linesCleared, level);
        let lineType = '';
        
        switch (linesCleared) {
            case 1:
                lineType = 'Single';
                break;
            case 2:
                lineType = 'Double';
                break;
            case 3:
                lineType = 'Triple';
                break;
            case 4:
                lineType = 'Tetris';
                break;
            default:
                lineType = 'None';
        }

        return {
            score,
            lineType,
            linesCleared,
            level,
            baseScore: this.getBaseScore(linesCleared),
            multiplier: level
        };
    }

    /**
     * Get base score for number of lines (without level multiplier)
     * @param {number} linesCleared - Number of lines cleared
     * @returns {number} Base score
     */
    getBaseScore(linesCleared) {
        switch (linesCleared) {
            case 1:
                return this.config.scoring.single;
            case 2:
                return this.config.scoring.double;
            case 3:
                return this.config.scoring.triple;
            case 4:
                return this.config.scoring.tetris;
            default:
                return 0;
        }
    }

    /**
     * Calculate lines needed for next level
     * @param {number} currentLevel - Current level
     * @returns {number} Lines needed for next level
     */
    getLinesForNextLevel(currentLevel) {
        const linesForCurrentLevel = (currentLevel - 1) * 10;
        return linesForCurrentLevel + 10;
    }

    /**
     * Get progress towards next level
     * @param {number} totalLines - Total lines cleared
     * @param {number} currentLevel - Current level
     * @returns {Object} Progress information
     */
    getLevelProgress(totalLines, currentLevel) {
        const linesForCurrentLevel = (currentLevel - 1) * 10;
        const linesForNextLevel = currentLevel * 10;
        const progressLines = totalLines - linesForCurrentLevel;
        const neededLines = linesForNextLevel - totalLines;

        return {
            progressLines: Math.max(0, progressLines),
            neededLines: Math.max(0, neededLines),
            totalNeeded: 10,
            percentage: Math.min(100, (progressLines / 10) * 100)
        };
    }
}