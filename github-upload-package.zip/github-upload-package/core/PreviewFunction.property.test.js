/**
 * Property-based tests for Preview Function Correctness
 * **Feature: tetris-game, Property 14: 预览功能正确性**
 * **Validates: Requirements 5.4**
 */

import fc from 'fast-check';
import { Renderer } from '../../src/core/Renderer.js';
import { Tetromino, TETROMINO_DEFINITIONS } from '../../src/core/Tetromino.js';
import { GameConfig } from '../../src/config/GameConfig.js';

// Mock DOM elements for testing
const createMockDOM = () => {
    // Create mock context that persists across calls
    const mockMainCtx = {
        fillStyle: '',
        fillRect: jest.fn(),
        strokeStyle: '',
        strokeRect: jest.fn(),
        lineWidth: 1,
        globalAlpha: 1,
        imageSmoothingEnabled: false,
        save: jest.fn(),
        restore: jest.fn(),
        beginPath: jest.fn(),
        moveTo: jest.fn(),
        lineTo: jest.fn(),
        stroke: jest.fn(),
        font: '',
        textAlign: '',
        textBaseline: '',
        fillText: jest.fn()
    };

    const mockNextPieceCtx = {
        _fillStyle: '',
        get fillStyle() { return this._fillStyle; },
        set fillStyle(value) { 
            this._fillStyle = value;
            this.fillStyleSetter(value);
        },
        fillStyleSetter: jest.fn(),
        fillRect: jest.fn(),
        _strokeStyle: '',
        get strokeStyle() { return this._strokeStyle; },
        set strokeStyle(value) { 
            this._strokeStyle = value;
            this.strokeStyleSetter(value);
        },
        strokeStyleSetter: jest.fn(),
        strokeRect: jest.fn(),
        lineWidth: 1,
        globalAlpha: 1,
        imageSmoothingEnabled: false,
        save: jest.fn(),
        restore: jest.fn()
    };

    // Create mock canvas elements
    const mockCanvas = {
        width: 300,
        height: 600,
        getContext: () => mockMainCtx
    };

    const mockNextPieceCanvas = {
        width: 80,
        height: 80,
        getContext: () => mockNextPieceCtx
    };

    return { mockCanvas, mockNextPieceCanvas, mockMainCtx, mockNextPieceCtx };
};

describe('Preview Function Correctness Properties', () => {
    let mockDOM;
    let renderer;
    let config;

    beforeEach(() => {
        mockDOM = createMockDOM();
        config = new GameConfig();
        renderer = new Renderer(mockDOM.mockCanvas, mockDOM.mockNextPieceCanvas, config);
    });

    afterEach(() => {
        // Clear the persistent mock functions
        if (mockDOM && mockDOM.mockNextPieceCtx) {
            mockDOM.mockNextPieceCtx.fillRect.mockClear();
            mockDOM.mockNextPieceCtx.strokeRect.mockClear();
            mockDOM.mockNextPieceCtx.fillStyleSetter.mockClear();
            mockDOM.mockNextPieceCtx.strokeStyleSetter.mockClear();
            mockDOM.mockNextPieceCtx.save.mockClear();
            mockDOM.mockNextPieceCtx.restore.mockClear();
        }
    });

    /**
     * **Feature: tetris-game, Property 14: 预览功能正确性**
     * For any game state, the preview area displayed piece should match the next piece that will appear
     */
    test('preview area displays correct next piece', () => {
        fc.assert(fc.property(
            // Generate random tetromino type
            fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
            // Generate random position (though position shouldn't matter for preview)
            fc.integer({ min: 0, max: 9 }),
            fc.integer({ min: 0, max: 19 }),
            // Generate random rotation
            fc.integer({ min: 0, max: 3 }),
            (tetrominoType, x, y, rotation) => {
                // Clear mocks at the start of each iteration
                mockDOM.mockNextPieceCtx.fillRect.mockClear();
                mockDOM.mockNextPieceCtx.strokeRect.mockClear();
                mockDOM.mockNextPieceCtx.fillStyleSetter.mockClear();
                
                const nextTetromino = new Tetromino(tetrominoType, x, y, rotation);
                
                // Draw the next piece preview
                renderer.drawNextPiece(nextTetromino);
                
                // Get the context to verify drawing calls
                const ctx = mockDOM.mockNextPieceCtx;
                
                // Property: The preview should draw blocks for the tetromino shape
                const shape = nextTetromino.getShape();
                const color = nextTetromino.getColor();
                
                // Count expected filled blocks in the shape
                let expectedBlocks = 0;
                for (let row = 0; row < shape.length; row++) {
                    for (let col = 0; col < shape[row].length; col++) {
                        if (shape[row][col] === 1) {
                            expectedBlocks++;
                        }
                    }
                }
                
                // Property: fillRect should be called for each block in the shape
                // (once for clear, once for main fill, twice for highlight per block)
                expect(ctx.fillRect).toHaveBeenCalledTimes(1 + expectedBlocks * 3);
                
                // Property: strokeRect should be called for each block (border)
                expect(ctx.strokeRect).toHaveBeenCalledTimes(expectedBlocks);
            }
        ), { numRuns: 100 });
    });

    /**
     * Test that preview clears canvas before drawing
     */
    test('preview clears canvas before drawing new piece', () => {
        fc.assert(fc.property(
            fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
            fc.integer({ min: 0, max: 3 }),
            (tetrominoType, rotation) => {
                // Clear mocks at the start of each iteration
                mockDOM.mockNextPieceCtx.fillRect.mockClear();
                mockDOM.mockNextPieceCtx.strokeRect.mockClear();
                mockDOM.mockNextPieceCtx.fillStyleSetter.mockClear();
                
                const nextTetromino = new Tetromino(tetrominoType, 0, 0, rotation);
                
                // Draw the next piece preview
                renderer.drawNextPiece(nextTetromino);
                
                // Get the context to verify clearing
                const ctx = mockDOM.mockNextPieceCtx;
                
                // Property: Canvas should be cleared before drawing
                // The first fillRect call should be for clearing (full canvas size)
                const fillRectCalls = ctx.fillRect.mock.calls;
                expect(fillRectCalls.length).toBeGreaterThan(0);
                
                // First call should clear the entire canvas
                const firstCall = fillRectCalls[0];
                expect(firstCall[0]).toBe(0); // x = 0
                expect(firstCall[1]).toBe(0); // y = 0
                expect(firstCall[2]).toBe(mockDOM.mockNextPieceCanvas.width);  // width
                expect(firstCall[3]).toBe(mockDOM.mockNextPieceCanvas.height); // height
            }
        ), { numRuns: 100 });
    });

    /**
     * Test that null/undefined next piece is handled gracefully
     */
    test('null next piece is handled gracefully', () => {
        fc.assert(fc.property(
            fc.constantFrom(null, undefined),
            (nullTetromino) => {
                // Clear mocks at the start of each iteration
                mockDOM.mockNextPieceCtx.fillRect.mockClear();
                mockDOM.mockNextPieceCtx.strokeRect.mockClear();
                mockDOM.mockNextPieceCtx.fillStyleSetter.mockClear();
                
                // Property: Drawing null/undefined should not throw
                expect(() => {
                    renderer.drawNextPiece(nullTetromino);
                }).not.toThrow();
                
                // Get the context to verify minimal drawing
                const ctx = mockDOM.mockNextPieceCtx;
                
                // Property: Should only clear the canvas, no shape drawing
                const fillRectCalls = ctx.fillRect.mock.calls;
                expect(fillRectCalls.length).toBe(1); // Only the clear call
                
                // Property: No stroke calls for shapes
                expect(ctx.strokeRect).not.toHaveBeenCalled();
            }
        ), { numRuns: 100 });
    });

    /**
     * Test that preview rendering is consistent across multiple calls
     */
    test('preview rendering is consistent across multiple calls', () => {
        fc.assert(fc.property(
            fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
            fc.integer({ min: 0, max: 3 }),
            (tetrominoType, rotation) => {
                // Clear mocks at the start of each iteration
                mockDOM.mockNextPieceCtx.fillRect.mockClear();
                mockDOM.mockNextPieceCtx.strokeRect.mockClear();
                mockDOM.mockNextPieceCtx.fillStyleSetter.mockClear();
                
                const nextTetromino = new Tetromino(tetrominoType, 0, 0, rotation);
                
                // Draw the same piece multiple times
                renderer.drawNextPiece(nextTetromino);
                const firstCallCount = mockDOM.mockNextPieceCtx.fillRect.mock.calls.length;
                
                // Clear mock and draw again
                mockDOM.mockNextPieceCtx.fillRect.mockClear();
                mockDOM.mockNextPieceCtx.strokeRect.mockClear();
                mockDOM.mockNextPieceCtx.fillStyleSetter.mockClear();
                renderer.drawNextPiece(nextTetromino);
                const secondCallCount = mockDOM.mockNextPieceCtx.fillRect.mock.calls.length;
                
                // Property: Same piece should result in same number of draw calls
                expect(secondCallCount).toBe(firstCallCount);
            }
        ), { numRuns: 100 });
    });

    /**
     * Test that different tetromino types produce different preview patterns
     */
    test('different tetromino types produce different patterns', () => {
        fc.assert(fc.property(
            fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
            fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
            (type1, type2) => {
                // Skip if same type
                if (type1 === type2) return;
                
                // Clear mocks at the start of each iteration
                mockDOM.mockNextPieceCtx.fillRect.mockClear();
                mockDOM.mockNextPieceCtx.strokeRect.mockClear();
                mockDOM.mockNextPieceCtx.fillStyleSetter.mockClear();
                
                const tetromino1 = new Tetromino(type1, 0, 0, 0);
                const tetromino2 = new Tetromino(type2, 0, 0, 0);
                
                // Draw first piece
                renderer.drawNextPiece(tetromino1);
                const calls1 = [...mockDOM.mockNextPieceCtx.fillRect.mock.calls];
                
                // Clear and draw second piece
                mockDOM.mockNextPieceCtx.fillRect.mockClear();
                mockDOM.mockNextPieceCtx.strokeRect.mockClear();
                mockDOM.mockNextPieceCtx.fillStyleSetter.mockClear();
                renderer.drawNextPiece(tetromino2);
                const calls2 = [...mockDOM.mockNextPieceCtx.fillRect.mock.calls];
                
                // Property: Different types should produce different patterns
                // (unless they happen to have the same shape, which is unlikely)
                const shape1 = tetromino1.getShape();
                const shape2 = tetromino2.getShape();
                
                // Count blocks in each shape
                let blocks1 = 0, blocks2 = 0;
                for (let row = 0; row < 4; row++) {
                    for (let col = 0; col < 4; col++) {
                        if (shape1[row][col] === 1) blocks1++;
                        if (shape2[row][col] === 1) blocks2++;
                    }
                }
                
                // If different number of blocks, should have different call counts
                if (blocks1 !== blocks2) {
                    expect(calls1.length).not.toBe(calls2.length);
                }
            }
        ), { numRuns: 100 });
    });

    /**
     * Test that preview respects tetromino rotation states
     */
    test('preview respects tetromino rotation states', () => {
        fc.assert(fc.property(
            fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS).filter(type => type !== 'O')), // O piece looks same in all rotations
            fc.integer({ min: 0, max: 3 }),
            fc.integer({ min: 0, max: 3 }),
            (tetrominoType, rotation1, rotation2) => {
                // Skip if same rotation
                if (rotation1 === rotation2) return;
                
                // Clear mocks at the start of each iteration
                mockDOM.mockNextPieceCtx.fillRect.mockClear();
                mockDOM.mockNextPieceCtx.strokeRect.mockClear();
                mockDOM.mockNextPieceCtx.fillStyleSetter.mockClear();
                
                const tetromino1 = new Tetromino(tetrominoType, 0, 0, rotation1);
                const tetromino2 = new Tetromino(tetrominoType, 0, 0, rotation2);
                
                // Get shapes to compare
                const shape1 = tetromino1.getShape();
                const shape2 = tetromino2.getShape();
                
                // Check if shapes are actually different
                let shapesAreDifferent = false;
                for (let row = 0; row < 4 && !shapesAreDifferent; row++) {
                    for (let col = 0; col < 4 && !shapesAreDifferent; col++) {
                        if (shape1[row][col] !== shape2[row][col]) {
                            shapesAreDifferent = true;
                        }
                    }
                }
                
                // Only test if shapes are actually different
                if (!shapesAreDifferent) return;
                
                // Draw first rotation
                renderer.drawNextPiece(tetromino1);
                const calls1 = [...mockDOM.mockNextPieceCtx.fillRect.mock.calls];
                
                // Clear and draw second rotation
                mockDOM.mockNextPieceCtx.fillRect.mockClear();
                mockDOM.mockNextPieceCtx.strokeRect.mockClear();
                mockDOM.mockNextPieceCtx.fillStyleSetter.mockClear();
                renderer.drawNextPiece(tetromino2);
                const calls2 = [...mockDOM.mockNextPieceCtx.fillRect.mock.calls];
                
                // Property: Different rotations should produce different drawing patterns
                // At minimum, the positions of the fillRect calls should be different
                let positionsAreDifferent = false;
                if (calls1.length === calls2.length) {
                    for (let i = 1; i < calls1.length; i++) { // Skip first clear call
                        if (calls1[i][0] !== calls2[i][0] || calls1[i][1] !== calls2[i][1]) {
                            positionsAreDifferent = true;
                            break;
                        }
                    }
                }
                
                expect(positionsAreDifferent || calls1.length !== calls2.length).toBe(true);
            }
        ), { numRuns: 100 });
    });

    /**
     * Test that preview uses correct colors for each tetromino type
     */
    test('preview uses correct colors for tetromino types', () => {
        fc.assert(fc.property(
            fc.constantFrom(...Object.keys(TETROMINO_DEFINITIONS)),
            fc.integer({ min: 0, max: 3 }),
            (tetrominoType, rotation) => {
                // Clear mocks at the start of each iteration
                mockDOM.mockNextPieceCtx.fillRect.mockClear();
                mockDOM.mockNextPieceCtx.strokeRect.mockClear();
                mockDOM.mockNextPieceCtx.fillStyleSetter.mockClear();
                
                const nextTetromino = new Tetromino(tetrominoType, 0, 0, rotation);
                const expectedColor = nextTetromino.getColor();
                
                // Draw the next piece preview
                renderer.drawNextPiece(nextTetromino);
                
                // Get the context to verify color usage
                const ctx = mockDOM.mockNextPieceCtx;
                
                // Property: The correct color should be used for drawing
                expect(ctx.fillStyleSetter).toHaveBeenCalledWith(expectedColor);
                
                // Property: Color should match the tetromino definition
                const definition = TETROMINO_DEFINITIONS[tetrominoType];
                expect(expectedColor).toBe(definition.color);
            }
        ), { numRuns: 100 });
    });
});