/**
 * GameBoard class representing the 10x20 Tetris game board
 * Handles collision detection, piece placement, and line clearing
 */

import { CollisionDetector } from './CollisionDetector.js';

export class GameBoard {
    /**
     * Create a new game board
     * @param {number} width - Board width in cells (default 10)
     * @param {number} height - Board height in cells (default 20)
     */
    constructor(width = 10, height = 20) {
        this.width = width;
        this.height = height;
        this.board = this.createEmptyBoard();
        this.collisionDetector = new CollisionDetector(this);
    }

    /**
     * Create an empty board filled with zeros
     * @returns {number[][]} 2D array representing empty board
     */
    createEmptyBoard() {
        return Array(this.height).fill(null).map(() => Array(this.width).fill(0));
    }

    /**
     * Check if a position is within board boundaries
     * @param {number} x - X coordinate
     * @param {number} y - Y coordinate
     * @returns {boolean} True if position is within bounds
     */
    isInBounds(x, y) {
        return x >= 0 && x < this.width && y >= 0 && y < this.height;
    }

    /**
     * Check if a cell is empty
     * @param {number} x - X coordinate
     * @param {number} y - Y coordinate
     * @returns {boolean} True if cell is empty (0) or out of bounds
     */
    isEmpty(x, y) {
        if (!this.isInBounds(x, y)) {
            return false;
        }
        return this.board[y][x] === 0;
    }

    /**
     * Check if a tetromino can be placed at its current position
     * @param {Tetromino} tetromino - The tetromino to check
     * @returns {boolean} True if position is valid (no collision)
     */
    isValidPosition(tetromino) {
        const blocks = tetromino.getBlocks();
        
        for (const block of blocks) {
            // Check if block is out of bounds
            if (!this.isInBounds(block.x, block.y)) {
                return false;
            }
            
            // Check if block collides with existing pieces
            if (this.board[block.y][block.x] !== 0) {
                return false;
            }
        }
        
        return true;
    }

    /**
     * Place a tetromino on the board permanently
     * @param {Tetromino} tetromino - The tetromino to place
     * @throws {Error} If placement position is invalid
     */
    placeTetromino(tetromino) {
        if (!this.isValidPosition(tetromino)) {
            throw new Error('Cannot place tetromino at invalid position');
        }
        
        const blocks = tetromino.getBlocks();
        const color = tetromino.getColor();
        
        for (const block of blocks) {
            this.board[block.y][block.x] = color;
        }
    }

    /**
     * Get all completed line indices
     * @returns {number[]} Array of row indices that are complete
     */
    getCompletedLines() {
        const completedLines = [];
        
        for (let y = 0; y < this.height; y++) {
            if (this.isLineComplete(y)) {
                completedLines.push(y);
            }
        }
        
        return completedLines;
    }

    /**
     * Check if a line is completely filled
     * @param {number} y - Row index to check
     * @returns {boolean} True if line is complete
     */
    isLineComplete(y) {
        if (y < 0 || y >= this.height) {
            return false;
        }
        
        for (let x = 0; x < this.width; x++) {
            if (this.board[y][x] === 0) {
                return false;
            }
        }
        
        return true;
    }

    /**
     * Clear completed lines and move rows down
     * @returns {number} Number of lines cleared
     */
    clearLines() {
        const completedLines = this.getCompletedLines();
        
        if (completedLines.length === 0) {
            return 0;
        }
        
        // More efficient approach: rebuild the board without completed lines
        this.clearMultipleLines(completedLines);
        
        return completedLines.length;
    }

    /**
     * Clear multiple lines efficiently by rebuilding the board
     * @param {number[]} lineIndices - Array of line indices to clear
     */
    clearMultipleLines(lineIndices) {
        if (lineIndices.length === 0) {
            return;
        }
        
        const linesToClear = new Set(lineIndices);
        const newBoard = [];
        
        // Add empty lines at the top for each cleared line
        for (let i = 0; i < lineIndices.length; i++) {
            newBoard.push(Array(this.width).fill(0));
        }
        
        // Copy non-cleared lines to the new board
        for (let y = 0; y < this.height; y++) {
            if (!linesToClear.has(y)) {
                newBoard.push([...this.board[y]]);
            }
        }
        
        this.board = newBoard;
    }

    /**
     * Remove a line and shift all lines above it down
     * @param {number} lineIndex - Index of line to remove
     */
    removeLine(lineIndex) {
        // Remove the line
        this.board.splice(lineIndex, 1);
        
        // Add new empty line at the top
        this.board.unshift(Array(this.width).fill(0));
    }

    /**
     * Count the number of filled cells in a line
     * @param {number} y - Row index
     * @returns {number} Number of filled cells
     */
    getLineFillCount(y) {
        if (y < 0 || y >= this.height) {
            return 0;
        }
        
        let count = 0;
        for (let x = 0; x < this.width; x++) {
            if (this.board[y][x] !== 0) {
                count++;
            }
        }
        return count;
    }

    /**
     * Check if any lines are complete
     * @returns {boolean} True if at least one line is complete
     */
    hasCompletedLines() {
        return this.getCompletedLines().length > 0;
    }

    /**
     * Get the number of complete lines
     * @returns {number} Count of complete lines
     */
    getCompletedLineCount() {
        return this.getCompletedLines().length;
    }

    /**
     * Simulate line clearing and return the result without modifying the board
     * @returns {{linesCleared: number, newBoard: number[][]}} Simulation result
     */
    simulateLineClear() {
        const completedLines = this.getCompletedLines();
        
        if (completedLines.length === 0) {
            return {
                linesCleared: 0,
                newBoard: this.getBoard()
            };
        }
        
        const linesToClear = new Set(completedLines);
        const newBoard = [];
        
        // Add empty lines at the top for each cleared line
        for (let i = 0; i < completedLines.length; i++) {
            newBoard.push(Array(this.width).fill(0));
        }
        
        // Copy non-cleared lines to the new board
        for (let y = 0; y < this.height; y++) {
            if (!linesToClear.has(y)) {
                newBoard.push([...this.board[y]]);
            }
        }
        
        return {
            linesCleared: completedLines.length,
            newBoard: newBoard
        };
    }

    /**
     * Remove specific lines from the board
     * @param {number[]} lineIndices - Array of line indices to remove
     */
    removeLines(lineIndices) {
        if (lineIndices.length === 0) {
            return;
        }
        
        const linesToRemove = new Set(lineIndices);
        const newBoard = [];
        
        // Add empty lines at the top for each removed line
        for (let i = 0; i < lineIndices.length; i++) {
            newBoard.push(Array(this.width).fill(0));
        }
        
        // Copy non-removed lines to the new board
        for (let y = 0; y < this.height; y++) {
            if (!linesToRemove.has(y)) {
                newBoard.push([...this.board[y]]);
            }
        }
        
        this.board = newBoard;
    }

    /**
     * Get the current board state
     * @returns {number[][]} Copy of the board array
     */
    getBoard() {
        return this.board.map(row => [...row]);
    }

    /**
     * Reset the board to empty state
     */
    reset() {
        this.board = this.createEmptyBoard();
    }

    /**
     * Get a cell value at specific coordinates
     * @param {number} x - X coordinate
     * @param {number} y - Y coordinate
     * @returns {number|string} Cell value (0 for empty, color string for filled)
     */
    getCell(x, y) {
        if (!this.isInBounds(x, y)) {
            return null;
        }
        return this.board[y][x];
    }

    /**
     * Set a cell value at specific coordinates
     * @param {number} x - X coordinate
     * @param {number} y - Y coordinate
     * @param {number|string} value - Value to set
     */
    setCell(x, y, value) {
        if (this.isInBounds(x, y)) {
            this.board[y][x] = value;
        }
    }

    /**
     * Clone the game board
     * @returns {GameBoard} New GameBoard instance with same state
     */
    clone() {
        const newBoard = new GameBoard(this.width, this.height);
        newBoard.board = this.board.map(row => [...row]);
        return newBoard;
    }

    /**
     * Get the collision detector for this board
     * @returns {CollisionDetector} The collision detector instance
     */
    getCollisionDetector() {
        return this.collisionDetector;
    }

    /**
     * Check if a move is valid using collision detection
     * @param {Tetromino} tetromino - The tetromino to move
     * @param {number} dx - Horizontal movement
     * @param {number} dy - Vertical movement
     * @returns {boolean} True if move is valid
     */
    canMove(tetromino, dx, dy) {
        return this.collisionDetector.canMove(tetromino, dx, dy);
    }

    /**
     * Try to rotate a tetromino with SRS wall kicks
     * @param {Tetromino} tetromino - The tetromino to rotate
     * @param {boolean} clockwise - Direction of rotation
     * @returns {Tetromino|null} Rotated tetromino if successful, null otherwise
     */
    tryRotate(tetromino, clockwise = true) {
        return this.collisionDetector.tryRotateWithKicks(tetromino, clockwise);
    }

    /**
     * Get hard drop position for a tetromino
     * @param {Tetromino} tetromino - The tetromino to drop
     * @returns {Tetromino} Tetromino at lowest valid position
     */
    getHardDropPosition(tetromino) {
        return this.collisionDetector.getHardDropPosition(tetromino);
    }

    /**
     * Check if game over condition is met
     * @param {Tetromino} tetromino - The tetromino trying to spawn
     * @returns {boolean} True if game is over
     */
    isGameOver(tetromino) {
        return this.collisionDetector.isGameOver(tetromino);
    }
}