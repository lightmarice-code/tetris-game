package com.tetris.game;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
