// Game configuration and constants
export class GameConfig {
    constructor() {
        this.boardWidth = 10;
        this.boardHeight = 20;
        this.dropInterval = 1000; // milliseconds
        this.levelSpeedMultiplier = 0.9;
        this.scoring = {
            single: 100,
            double: 300,
            triple: 500,
            tetris: 800
        };
    }
}