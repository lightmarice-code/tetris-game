import { GameConfig } from '../../src/config/GameConfig.js';

describe('GameConfig', () => {
  let config;

  beforeEach(() => {
    config = new GameConfig();
  });

  test('should have correct default values', () => {
    expect(config.boardWidth).toBe(10);
    expect(config.boardHeight).toBe(20);
    expect(config.dropInterval).toBe(1000);
    expect(config.levelSpeedMultiplier).toBe(0.9);
  });

  test('should have correct scoring configuration', () => {
    expect(config.scoring.single).toBe(100);
    expect(config.scoring.double).toBe(300);
    expect(config.scoring.triple).toBe(500);
    expect(config.scoring.tetris).toBe(800);
  });
});