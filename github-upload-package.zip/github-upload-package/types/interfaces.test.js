import { INPUT_ACTIONS, TETROMINO_TYPES } from '../../src/types/interfaces.js';

describe('Interfaces and Constants', () => {
  test('INPUT_ACTIONS should have all required actions', () => {
    expect(INPUT_ACTIONS.MOVE_LEFT).toBe('moveLeft');
    expect(INPUT_ACTIONS.MOVE_RIGHT).toBe('moveRight');
    expect(INPUT_ACTIONS.SOFT_DROP).toBe('softDrop');
    expect(INPUT_ACTIONS.HARD_DROP).toBe('hardDrop');
    expect(INPUT_ACTIONS.ROTATE_CW).toBe('rotateCW');
    expect(INPUT_ACTIONS.ROTATE_CCW).toBe('rotateCCW');
    expect(INPUT_ACTIONS.PAUSE).toBe('pause');
    expect(INPUT_ACTIONS.RESTART).toBe('restart');
  });

  test('TETROMINO_TYPES should contain all 7 types', () => {
    expect(TETROMINO_TYPES).toHaveLength(7);
    expect(TETROMINO_TYPES).toContain('I');
    expect(TETROMINO_TYPES).toContain('O');
    expect(TETROMINO_TYPES).toContain('T');
    expect(TETROMINO_TYPES).toContain('S');
    expect(TETROMINO_TYPES).toContain('Z');
    expect(TETROMINO_TYPES).toContain('J');
    expect(TETROMINO_TYPES).toContain('L');
  });
});