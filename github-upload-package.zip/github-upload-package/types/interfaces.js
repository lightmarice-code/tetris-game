/**
 * Core type definitions and interfaces for the Tetris game
 */

/**
 * @typedef {Object} ITetrominoType
 * @property {string} name - Tetromino type name ('I', 'O', 'T', 'S', 'Z', 'J', 'L')
 * @property {string} color - Hex color value
 * @property {number[][][]} shapes - 4 rotation states of the shape
 * @property {number[][]} kickData - SRS rotation kick wall data
 */

/**
 * @typedef {Object} IGameConfig
 * @property {number} boardWidth - Game board width (default 10)
 * @property {number} boardHeight - Game board height (default 20)
 * @property {number} dropInterval - Initial drop interval in milliseconds
 * @property {number} levelSpeedMultiplier - Level speed multiplier
 * @property {Object} scoring - Scoring configuration
 * @property {number} scoring.single - Single line clear score
 * @property {number} scoring.double - Double line clear score
 * @property {number} scoring.triple - Triple line clear score
 * @property {number} scoring.tetris - Tetris (4 lines) clear score
 */

/**
 * @typedef {Object} IGameState
 * @property {number[][]} board - Game board 2D array
 * @property {Object|null} currentTetromino - Current active tetromino
 * @property {Object|null} nextTetromino - Next tetromino to appear
 * @property {number} score - Current score
 * @property {number} level - Current level
 * @property {number} lines - Total lines cleared
 * @property {boolean} isPlaying - Is game currently playing
 * @property {boolean} isPaused - Is game paused
 * @property {number} dropTimer - Drop timer counter
 * @property {number} lastUpdateTime - Last update timestamp
 */

/**
 * Input action constants
 */
export const INPUT_ACTIONS = {
    MOVE_LEFT: 'moveLeft',
    MOVE_RIGHT: 'moveRight',
    SOFT_DROP: 'softDrop',
    HARD_DROP: 'hardDrop',
    ROTATE_CW: 'rotateCW',
    ROTATE_CCW: 'rotateCCW',
    PAUSE: 'pause',
    RESTART: 'restart'
};

/**
 * Tetromino type names
 */
export const TETROMINO_TYPES = ['I', 'O', 'T', 'S', 'Z', 'J', 'L'];