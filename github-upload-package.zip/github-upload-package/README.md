# 🎮 俄罗斯方块游戏 - Tetris Game

一个完整的HTML5俄罗斯方块游戏，支持Web和Android平台。

## 🚀 在线体验

[点击这里在线游戏](https://your-username.github.io/tetris-game)

## 📱 Android APK下载

在[Releases页面](https://github.com/your-username/tetris-game/releases)下载最新的Android APK文件。

## ✨ 游戏特性

- 🎯 经典俄罗斯方块玩法
- 📱 完美支持移动设备触摸控制
- 🎨 现代化UI设计
- 🔊 游戏音效和背景音乐
- 📊 分数和等级系统
- ⏸️ 暂停和重新开始功能
- 🌐 支持PWA（渐进式Web应用）

## 🎮 游戏控制

### 桌面端
- `←` `→` 左右移动
- `↓` 加速下落
- `↑` 旋转方块
- `空格` 瞬间下落
- `P` 或 `ESC` 暂停游戏
- `R` 重新开始

### 移动端
- 触摸屏幕上的控制按钮
- 支持手势操作

## 🛠️ 技术栈

- **前端**: HTML5, CSS3, JavaScript (ES6+)
- **构建工具**: Vite
- **测试框架**: Jest + fast-check
- **移动端**: Capacitor + Android
- **CI/CD**: GitHub Actions

## 🏗️ 本地开发

```bash
# 克隆仓库
git clone https://github.com/your-username/tetris-game.git
cd tetris-game

# 安装依赖
npm install

# 启动开发服务器
npm run dev

# 构建生产版本
npm run build

# 运行测试
npm test
```

## 📱 Android开发

### 使用Android Studio
```bash
# 构建Web应用
npm run build

# 同步到Android项目
npx cap sync android

# 打开Android Studio
npx cap open android
```

### 使用预配置项目
直接在Android Studio中打开 `simple-android-build/` 目录。

## 🚀 部署

### GitHub Pages
推送到main分支会自动部署到GitHub Pages。

### Android APK
推送代码会自动构建Android APK并发布到Releases。

## 📋 项目结构

```
tetris-game/
├── src/                    # 游戏源代码
│   ├── core/              # 核心游戏逻辑
│   ├── config/            # 游戏配置
│   └── index.js           # 入口文件
├── assets/                # 静态资源
├── tests/                 # 测试文件
├── simple-android-build/  # Android Studio项目
├── .github/workflows/     # GitHub Actions配置
└── dist/                  # 构建输出
```

## 🧪 测试

```bash
# 运行所有测试
npm test

# 运行测试并生成覆盖率报告
npm run test:coverage

# 监听模式运行测试
npm run test:watch
```

## 📄 许可证

MIT License - 详见 [LICENSE](LICENSE) 文件

## 🤝 贡献

欢迎提交Issue和Pull Request！

## 📞 联系

如有问题或建议，请创建Issue或联系开发者。

---

**享受游戏！** 🎮
