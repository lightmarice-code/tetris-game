// Main entry point for the Tetris game
import { GameEngine } from './core/GameEngine.js';
import { InputManager } from './core/InputManager.js';
import { GameConfig } from './config/GameConfig.js';

// Global variables for responsive design
let game = null;
let inputManager = null;

// Initialize the game when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    try {
        const canvas = document.getElementById('gameCanvas');
        const config = new GameConfig();
        
        // Validate required elements
        if (!canvas) {
            throw new Error('Game canvas not found');
        }
        
        const nextPieceCanvas = document.getElementById('nextPieceCanvas');
        if (!nextPieceCanvas) {
            throw new Error('Next piece canvas not found');
        }
        
        // Check browser compatibility
        checkBrowserCompatibility();
        
        // Initialize game engine
        console.log('🎮 Creating GameEngine...');
        game = new GameEngine(canvas, config);
        window.game = game; // Make sure it's accessible globally
        
        // Initialize input manager
        console.log('🎮 Creating InputManager...');
        inputManager = new InputManager(game);
        window.inputManager = inputManager; // Make accessible globally
        
        // Add emergency direct keyboard handler
        console.log('🚨 Adding emergency keyboard handler...');
        
        // Debug canvas info
        console.log('🖼️ Canvas info:', {
            canvas: !!canvas,
            width: canvas.width,
            height: canvas.height,
            clientWidth: canvas.clientWidth,
            clientHeight: canvas.clientHeight,
            style: canvas.style.cssText
        });
        document.addEventListener('keydown', function(event) {
            // Direct game control
            if (!game) return;
            
            switch(event.code) {
                case 'ArrowLeft':
                    event.preventDefault();
                    game.moveLeft();
                    break;
                case 'ArrowRight':
                    event.preventDefault();
                    game.moveRight();
                    break;
                case 'ArrowUp':
                    event.preventDefault();
                    game.rotate();
                    break;
                case 'ArrowDown':
                    event.preventDefault();
                    game.softDrop();
                    break;
                case 'Space':
                    event.preventDefault();
                    game.hardDrop();
                    break;
                case 'KeyR':
                    event.preventDefault();
                    game.reset();
                    game.start();
                    break;
                case 'KeyP':
                case 'Escape':
                    event.preventDefault();
                    if (game.isGamePaused()) {
                        game.resume();
                    } else {
                        game.pause();
                    }
                    break;
            }
        }, true); // Use capture phase
        
        // Ensure page has focus for keyboard events
        document.addEventListener('click', function() {
            console.log('👆 Page clicked, ensuring focus...');
            document.body.focus();
        });
        
        // Set initial focus
        document.body.setAttribute('tabindex', '0');
        document.body.focus();
        console.log('🎯 Initial focus set');
        
        // Setup responsive design
        setupResponsiveDesign();
        
        // Setup error handling
        setupGlobalErrorHandling();
        
        // Adjust performance for device
        game.adjustForDevice();
        
        // Setup performance monitoring
        setupPerformanceMonitoring();
        
        // Optimize for mobile
        optimizeForMobile();
        
        // Start the game
        console.log('🚀 Starting Tetris game...');
        game.start();
        
        // Verify game started
        setTimeout(() => {
            console.log('🔍 Game verification:', {
                gameExists: !!game,
                isRunning: game ? game.isGameRunning() : 'N/A',
                isPaused: game ? game.isGamePaused() : 'N/A',
                isGameOver: game ? game.isGameOver() : 'N/A'
            });
        }, 1000);
        
        // Debug: Check if game is running
        setTimeout(() => {
            console.log('=== GAME DIAGNOSIS ===');
            console.log('Game exists:', !!game);
            console.log('Is running:', game ? game.isGameRunning() : 'N/A');
            console.log('Is paused:', game ? game.isGamePaused() : 'N/A');
            console.log('Is game over:', game ? game.isGameOver() : 'N/A');
            console.log('Animation frame ID:', game ? game.animationFrameId : 'N/A');
            console.log('Current tetromino:', game && game.getCurrentTetromino() ? `${game.getCurrentTetromino().type} at (${game.getCurrentTetromino().x},${game.getCurrentTetromino().y})` : 'null');
            console.log('Drop timer:', game ? game.dropTimer : 'N/A');
            console.log('Drop interval:', game ? game.gameState.getDropInterval() : 'N/A');
            console.log('Frame count:', game ? game.frameCount : 'N/A');
            console.log('======================');
        }, 2000);
        
        // Add manual drop test
        window.testDrop = function() {
            console.log('Manual drop test...');
            if (game && game.handleAutomaticDrop) {
                game.handleAutomaticDrop();
            }
        };
        
        // Add game status check
        window.checkGame = function() {
            const dropInterval = game.gameState.getDropInterval();
            const progress = (game.dropTimer / dropInterval * 100).toFixed(1);
            console.log('Current game status:', {
                isRunning: game.isGameRunning(),
                isPaused: game.isGamePaused(),
                isGameOver: game.isGameOver(),
                dropTimer: game.dropTimer.toFixed(2),
                dropInterval: dropInterval,
                dropProgress: progress + '%',
                frameCount: game.frameCount || 0,
                animationFrameId: game.animationFrameId,
                currentPiece: game.getCurrentTetromino() ? `${game.getCurrentTetromino().type} at (${game.getCurrentTetromino().x},${game.getCurrentTetromino().y})` : 'null'
            });
        };
        
        // Add force drop function for testing
        window.forceDrop = function() {
            if (game) {
                console.log('Forcing drop...');
                game.dropTimer = game.gameState.getDropInterval() + 1;
                console.log('Drop timer set to:', game.dropTimer);
            }
        };
        
        // Add restart function
        window.restartGame = function() {
            if (game) {
                console.log('Restarting game...');
                game.reset();
                game.start();
            }
        };
        
        // Comprehensive monitoring function
        window.monitor = function() {
            if (!game) {
                console.log('Game object does not exist!');
                return;
            }
            
            console.log('=== GAME MONITOR ===');
            console.log('Game object exists:', !!game);
            console.log('Is running:', game.isGameRunning());
            console.log('Is paused:', game.isGamePaused());
            console.log('Is game over:', game.isGameOver());
            console.log('Animation frame ID:', game.animationFrameId);
            console.log('Frame count:', game.frameCount || 0);
            
            const dropInterval = game.gameState.getDropInterval();
            const progress = (game.dropTimer / dropInterval * 100).toFixed(1);
            console.log(`Drop timer: ${game.dropTimer.toFixed(2)}ms / ${dropInterval}ms (${progress}%)`);
            
            const current = game.getCurrentTetromino();
            console.log('Current piece:', current ? `${current.type} at (${current.x},${current.y})` : 'null');
            
            const next = game.getNextTetromino();
            console.log('Next piece:', next ? next.type : 'null');
            console.log('==================');
        };
        
        // Force a manual drop for testing
        window.testDrop = function() {
            if (game && game.handleAutomaticDrop) {
                console.log('Forcing manual drop...');
                game.handleAutomaticDrop();
            } else {
                console.log('Cannot force drop - game or method not available');
            }
        };
        
        console.log('Tetris game initialized successfully');
        
    } catch (error) {
        console.error('Failed to initialize game:', error);
        showInitializationError(error);
    }
});

/**
 * Setup responsive design features
 */
function setupResponsiveDesign() {
    // Update touch controls visibility on load
    if (inputManager) {
        inputManager.updateTouchControlsVisibility();
    }
    
    // Handle window resize
    window.addEventListener('resize', handleResize);
    
    // Handle orientation change
    window.addEventListener('orientationchange', handleOrientationChange);
    
    // Handle device pixel ratio changes (for high DPI displays)
    if (window.matchMedia) {
        const mediaQuery = window.matchMedia('(min-resolution: 2dppx)');
        mediaQuery.addListener(handlePixelRatioChange);
    }
}

/**
 * Handle window resize events
 */
function handleResize() {
    // Debounce resize events
    clearTimeout(window.resizeTimeout);
    window.resizeTimeout = setTimeout(() => {
        // Update touch controls visibility
        if (inputManager) {
            inputManager.updateTouchControlsVisibility();
            inputManager.updateTouchZones();
        }
        
        // Update canvas size if needed
        updateCanvasSize();
        
        // Trigger a render update
        if (game && game.renderer) {
            game.renderer.needsRedraw = true;
        }
    }, 250);
}

/**
 * Handle orientation change events
 */
function handleOrientationChange() {
    // Wait for orientation change to complete
    setTimeout(() => {
        handleResize();
    }, 500);
}

/**
 * Handle pixel ratio changes for high DPI displays
 */
function handlePixelRatioChange() {
    if (game && game.renderer) {
        game.renderer.updatePixelRatio();
    }
}

/**
 * Update canvas size based on container and screen size
 */
function updateCanvasSize() {
    const canvas = document.getElementById('gameCanvas');
    if (!canvas) return;
    
    const container = canvas.parentElement;
    if (!container) return;
    
    // Get container dimensions
    const containerRect = container.getBoundingClientRect();
    const maxWidth = Math.min(containerRect.width, window.innerWidth * 0.9);
    const maxHeight = Math.min(containerRect.height, window.innerHeight * 0.6);
    
    // Calculate optimal canvas size maintaining aspect ratio
    const aspectRatio = 300 / 600; // Original width/height ratio
    let newWidth, newHeight;
    
    if (maxWidth / maxHeight > aspectRatio) {
        // Height is the limiting factor
        newHeight = maxHeight;
        newWidth = newHeight * aspectRatio;
    } else {
        // Width is the limiting factor
        newWidth = maxWidth;
        newHeight = newWidth / aspectRatio;
    }
    
    // Ensure minimum size
    newWidth = Math.max(newWidth, 200);
    newHeight = Math.max(newHeight, 400);
    
    // Update canvas style size (CSS pixels)
    canvas.style.width = `${newWidth}px`;
    canvas.style.height = `${newHeight}px`;
    
    // Update canvas internal resolution if needed
    const pixelRatio = window.devicePixelRatio || 1;
    const displayWidth = newWidth * pixelRatio;
    const displayHeight = newHeight * pixelRatio;
    
    if (canvas.width !== displayWidth || canvas.height !== displayHeight) {
        canvas.width = displayWidth;
        canvas.height = displayHeight;
        
        // Update game engine canvas size
        if (game && game.renderer) {
            game.renderer.updateCanvasSize(displayWidth, displayHeight);
        }
    }
}

/**
 * Global restart function for game over screen
 */
window.restartGame = function() {
    if (game) {
        game.reset();
        game.start();
    }
};

/**
 * Check if device is mobile
 */
function isMobileDevice() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ||
           ('ontouchstart' in window) ||
           (navigator.maxTouchPoints > 0);
}

/**
 * Check if screen is in mobile size range
 */
function isMobileSize() {
    return window.innerWidth <= 768;
}

/**
 * Get optimal font size based on screen size
 */
function getOptimalFontSize() {
    const baseSize = 16;
    const screenWidth = window.innerWidth;
    
    if (screenWidth <= 320) {
        return baseSize * 0.8;
    } else if (screenWidth <= 480) {
        return baseSize * 0.9;
    } else if (screenWidth <= 768) {
        return baseSize;
    } else {
        return baseSize * 1.1;
    }
}

/**
 * Setup global error handling
 */
function setupGlobalErrorHandling() {
    // Handle uncaught errors
    window.addEventListener('error', (event) => {
        console.error('Global error:', event.error);
        handleGlobalError(event.error);
    });
    
    // Handle unhandled promise rejections
    window.addEventListener('unhandledrejection', (event) => {
        console.error('Unhandled promise rejection:', event.reason);
        handleGlobalError(event.reason);
    });
}

/**
 * Handle global errors
 * @param {Error} error - The error that occurred
 */
function handleGlobalError(error) {
    // If game exists, let it handle the error
    if (game && game.handleError) {
        game.handleError(error, 'global');
    } else {
        // Fallback error handling
        showInitializationError(error);
    }
}

/**
 * Show initialization error to user
 * @param {Error} error - The initialization error
 */
function showInitializationError(error) {
    const errorContainer = document.createElement('div');
    errorContainer.className = 'initialization-error';
    errorContainer.innerHTML = `
        <div class="error-content">
            <h2>游戏初始化失败</h2>
            <p>游戏无法正常启动，请检查浏览器兼容性或刷新页面重试。</p>
            <details>
                <summary>错误详情</summary>
                <pre>${error.message}</pre>
            </details>
            <button onclick="location.reload()">刷新页面</button>
        </div>
    `;
    
    // Add error styles
    errorContainer.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
        color: white;
        font-family: Arial, sans-serif;
    `;
    
    const errorContent = errorContainer.querySelector('.error-content');
    errorContent.style.cssText = `
        background: #333;
        padding: 2rem;
        border-radius: 8px;
        max-width: 500px;
        text-align: center;
    `;
    
    document.body.appendChild(errorContainer);
}

/**
 * Validate game state and attempt recovery
 */
function validateGameState() {
    if (!game) {
        console.warn('Game instance not found');
        return false;
    }
    
    if (!inputManager) {
        console.warn('Input manager not found');
        return false;
    }
    
    // Check if game is in a valid state
    const gameState = game.getGameState();
    if (!gameState) {
        console.warn('Invalid game state');
        return false;
    }
    
    return true;
}

/**
 * Attempt to recover from errors
 */
function attemptRecovery() {
    try {
        if (game && game.isGameRunning()) {
            game.pause();
            setTimeout(() => {
                if (game && !game.isGameOver()) {
                    game.resume();
                }
            }, 1000);
        }
    } catch (error) {
        console.error('Recovery attempt failed:', error);
    }
}

/**
 * Enhanced restart function with error handling
 */
window.restartGame = function() {
    try {
        if (game) {
            // Hide any error messages
            const errorMessages = document.querySelectorAll('.error-message, .initialization-error');
            errorMessages.forEach(msg => msg.remove());
            
            // Reset game
            game.reset();
            game.start();
            
            // Reset input manager if needed
            if (inputManager) {
                inputManager.clearPressedKeys();
            }
            
            console.log('Game restarted successfully');
        } else {
            // Try to reinitialize the game
            location.reload();
        }
    } catch (error) {
        console.error('Failed to restart game:', error);
        location.reload();
    }
};

/**
 * Enhanced pause/resume function
 */
window.togglePause = function() {
    try {
        if (!game) {
            return;
        }
        
        if (game.isGamePaused()) {
            game.resume();
        } else if (game.isGameRunning()) {
            game.pause();
        }
    } catch (error) {
        console.error('Failed to toggle pause:', error);
        handleGlobalError(error);
    }
};

/**
 * Get game statistics
 */
window.getGameStats = function() {
    if (!game) {
        return null;
    }
    
    try {
        const gameState = game.getGameState();
        const errorStats = game.getErrorStats ? game.getErrorStats() : {};
        
        return {
            ...gameState,
            errorStats,
            isRunning: game.isGameRunning(),
            isPaused: game.isGamePaused(),
            isGameOver: game.isGameOver()
        };
    } catch (error) {
        console.error('Failed to get game stats:', error);
        return null;
    }
};

/**
 * Check browser compatibility and show warnings if needed
 */
function checkBrowserCompatibility() {
    const issues = [];
    
    // Check for required APIs
    if (!window.requestAnimationFrame) {
        issues.push('requestAnimationFrame not supported');
        // Polyfill
        window.requestAnimationFrame = window.webkitRequestAnimationFrame ||
                                     window.mozRequestAnimationFrame ||
                                     window.oRequestAnimationFrame ||
                                     window.msRequestAnimationFrame ||
                                     function(callback) { return setTimeout(callback, 16); };
    }
    
    if (!window.cancelAnimationFrame) {
        window.cancelAnimationFrame = window.webkitCancelAnimationFrame ||
                                    window.mozCancelAnimationFrame ||
                                    window.oCancelAnimationFrame ||
                                    window.msCancelAnimationFrame ||
                                    function(id) { clearTimeout(id); };
    }
    
    // Check Canvas support
    const testCanvas = document.createElement('canvas');
    if (!testCanvas.getContext || !testCanvas.getContext('2d')) {
        issues.push('Canvas 2D not supported');
    }
    
    // Check localStorage support
    try {
        localStorage.setItem('test', 'test');
        localStorage.removeItem('test');
    } catch (e) {
        issues.push('localStorage not available');
    }
    
    // Check touch events support
    if (!('ontouchstart' in window) && !navigator.maxTouchPoints) {
        console.info('Touch events not supported - keyboard only');
    }
    
    // Show compatibility warnings
    if (issues.length > 0) {
        console.warn('Browser compatibility issues:', issues);
        showCompatibilityWarning(issues);
    }
}

/**
 * Show compatibility warning to user
 * @param {string[]} issues - Array of compatibility issues
 */
function showCompatibilityWarning(issues) {
    const warningDiv = document.createElement('div');
    warningDiv.className = 'compatibility-warning';
    warningDiv.innerHTML = `
        <div class="warning-content">
            <h3>浏览器兼容性警告</h3>
            <p>您的浏览器可能不完全支持此游戏的所有功能：</p>
            <ul>
                ${issues.map(issue => `<li>${issue}</li>`).join('')}
            </ul>
            <p>建议使用最新版本的 Chrome、Firefox 或 Safari 浏览器。</p>
            <button onclick="this.parentElement.parentElement.remove()">继续游戏</button>
        </div>
    `;
    
    // Add warning styles
    warningDiv.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(255, 165, 0, 0.9);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 9999;
        color: white;
        font-family: Arial, sans-serif;
    `;
    
    const warningContent = warningDiv.querySelector('.warning-content');
    warningContent.style.cssText = `
        background: #ff8c00;
        padding: 2rem;
        border-radius: 8px;
        max-width: 500px;
        text-align: center;
    `;
    
    document.body.appendChild(warningDiv);
    
    // Auto-remove after 10 seconds
    setTimeout(() => {
        if (warningDiv.parentElement) {
            warningDiv.remove();
        }
    }, 10000);
}

/**
 * Monitor performance and adjust settings
 */
function monitorPerformance() {
    if (!game) return;
    
    const metrics = game.getPerformanceMetrics();
    
    // Adjust performance if FPS is low
    if (metrics.currentFPS < 30 && metrics.currentFPS > 0) {
        console.warn('Low FPS detected, optimizing performance');
        game.optimizePerformance();
    }
    
    // Check memory usage
    game.checkMemoryUsage();
}

/**
 * Setup performance monitoring
 */
function setupPerformanceMonitoring() {
    // Monitor performance every 5 seconds
    setInterval(monitorPerformance, 5000);
    
    // Monitor page visibility to pause game when hidden
    document.addEventListener('visibilitychange', () => {
        if (game) {
            console.log('Page visibility changed:', document.hidden ? 'hidden' : 'visible');
            if (document.hidden) {
                if (game.isGameRunning() && !game.isGamePaused()) {
                    console.log('Pausing game due to page hidden');
                    game.pause();
                }
            } else {
                // Resume if page becomes visible and game was running
                if (game.isGameRunning() && game.isGamePaused()) {
                    console.log('Resuming game due to page visible');
                    game.resume();
                }
            }
        }
    });
}

/**
 * Optimize for mobile devices
 */
function optimizeForMobile() {
    if (!isMobileDevice()) return;
    
    // Prevent zoom on double tap
    let lastTouchEnd = 0;
    document.addEventListener('touchend', (event) => {
        const now = Date.now();
        if (now - lastTouchEnd <= 300) {
            event.preventDefault();
        }
        lastTouchEnd = now;
    }, false);
    
    // Prevent scrolling
    document.addEventListener('touchmove', (event) => {
        event.preventDefault();
    }, { passive: false });
    
    // Add mobile-specific CSS
    const mobileCSS = document.createElement('style');
    mobileCSS.textContent = `
        @media (max-width: 768px) {
            body {
                overflow: hidden;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
                user-select: none;
            }
            
            .game-container {
                flex-direction: column;
                align-items: center;
            }
            
            .game-info {
                flex-direction: row;
                flex-wrap: wrap;
                justify-content: center;
                min-width: auto;
            }
            
            .info-panel {
                margin: 5px;
                padding: 10px;
                min-width: 80px;
            }
        }
    `;
    document.head.appendChild(mobileCSS);
}

// Export functions for testing
export {
    setupResponsiveDesign,
    handleResize,
    handleOrientationChange,
    updateCanvasSize,
    isMobileDevice,
    isMobileSize,
    getOptimalFontSize,
    setupGlobalErrorHandling,
    handleGlobalError,
    showInitializationError,
    validateGameState,
    attemptRecovery,
    checkBrowserCompatibility,
    showCompatibilityWarning,
    monitorPerformance,
    setupPerformanceMonitoring,
    optimizeForMobile
};