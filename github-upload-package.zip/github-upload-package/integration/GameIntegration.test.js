/**
 * Integration tests for the complete Tetris game
 * Tests end-to-end game flow and cross-component interactions
 */

import { GameEngine } from '../../src/core/GameEngine.js';
import { InputManager } from '../../src/core/InputManager.js';
import { GameConfig } from '../../src/config/GameConfig.js';
import { Tetromino } from '../../src/core/Tetromino.js';

// Mock DOM elements for testing
const createMockCanvas = () => ({
    getContext: jest.fn(() => ({
        clearRect: jest.fn(),
        fillRect: jest.fn(),
        strokeRect: jest.fn(),
        fillText: jest.fn(),
        save: jest.fn(),
        restore: jest.fn(),
        beginPath: jest.fn(),
        moveTo: jest.fn(),
        lineTo: jest.fn(),
        stroke: jest.fn(),
        arc: jest.fn()
    })),
    width: 300,
    height: 600,
    style: {},
    getBoundingClientRect: () => ({
        left: 0,
        top: 0,
        width: 300,
        height: 600
    }),
    addEventListener: jest.fn(),
    removeEventListener: jest.fn()
});

const createMockNextPieceCanvas = () => ({
    getContext: jest.fn(() => ({
        clearRect: jest.fn(),
        fillRect: jest.fn(),
        strokeRect: jest.fn(),
        save: jest.fn(),
        restore: jest.fn()
    })),
    width: 80,
    height: 80
});

// Mock DOM methods
const mockGetElementById = jest.fn();
const mockAddEventListener = jest.fn();
const mockRemoveEventListener = jest.fn();

// Setup DOM mocks
beforeAll(() => {
    global.document = {
        getElementById: mockGetElementById,
        addEventListener: mockAddEventListener,
        removeEventListener: mockRemoveEventListener,
        querySelectorAll: jest.fn(() => []),
        createElement: jest.fn(() => ({
            style: {},
            classList: {
                add: jest.fn(),
                remove: jest.fn()
            },
            appendChild: jest.fn()
        }))
    };
    
    global.window = {
        addEventListener: mockAddEventListener,
        removeEventListener: mockRemoveEventListener,
        requestAnimationFrame: jest.fn(cb => setTimeout(cb, 16)),
        cancelAnimationFrame: jest.fn(),
        performance: {
            now: jest.fn(() => Date.now())
        },
        devicePixelRatio: 1,
        innerWidth: 1024,
        innerHeight: 768,
        matchMedia: jest.fn(() => ({
            addListener: jest.fn()
        }))
    };
    
    // Mock next piece canvas
    mockGetElementById.mockImplementation((id) => {
        if (id === 'nextPieceCanvas') {
            return createMockNextPieceCanvas();
        }
        return null;
    });
});

describe('Game Integration Tests', () => {
    let gameEngine;
    let inputManager;
    let mockCanvas;
    let config;

    beforeEach(() => {
        jest.clearAllMocks();
        mockCanvas = createMockCanvas();
        config = new GameConfig();
        gameEngine = new GameEngine(mockCanvas, config);
        inputManager = new InputManager(gameEngine);
    });

    afterEach(() => {
        if (inputManager) {
            inputManager.destroy();
        }
    });

    describe('Complete Game Session', () => {
        test('should handle a complete game session from start to game over', () => {
            // Start the game
            gameEngine.start();
            expect(gameEngine.isGameRunning()).toBe(true);
            expect(gameEngine.getCurrentTetromino()).toBeTruthy();
            expect(gameEngine.getNextTetromino()).toBeTruthy();

            // Simulate game play - move pieces and fill lines
            const initialScore = gameEngine.getGameState().score;
            
            // Fill the bottom rows to trigger line clears
            const gameBoard = gameEngine.getGameBoard();
            for (let y = 15; y < 20; y++) {
                for (let x = 0; x < 9; x++) { // Leave one empty space
                    gameBoard.setCell(x, y, '#FF0000');
                }
            }

            // Place a piece to complete lines
            const currentTetromino = gameEngine.getCurrentTetromino();
            if (currentTetromino) {
                // Move piece to complete the line
                gameEngine.moveLeft();
                gameEngine.hardDrop();
            }

            // Simulate line clearing by directly calling the method
            gameEngine.gameState.updateScore(1);
            
            // Verify line clearing and scoring
            const newScore = gameEngine.getGameState().score;
            expect(newScore).toBeGreaterThan(initialScore);

            // Fill the board to trigger game over
            for (let y = 0; y < 20; y++) {
                for (let x = 0; x < 10; x++) {
                    gameBoard.setCell(x, y, '#FF0000');
                }
            }

            // Trigger game over by trying to spawn a new piece
            gameEngine.spawnNewTetromino();
            gameEngine.checkGameOver();

            expect(gameEngine.isGameOver()).toBe(true);
            expect(gameEngine.isGameRunning()).toBe(false);
        });

        test('should maintain game state consistency throughout session', () => {
            gameEngine.start();
            
            const initialState = gameEngine.getGameState();
            expect(initialState.score).toBe(0);
            expect(initialState.level).toBe(1);
            expect(initialState.lines).toBe(0);
            expect(initialState.isGameOver).toBe(false);
            expect(initialState.isPaused).toBe(false);

            // Pause and resume
            gameEngine.pause();
            expect(gameEngine.isGamePaused()).toBe(true);
            
            gameEngine.resume();
            expect(gameEngine.isGamePaused()).toBe(false);
            expect(gameEngine.isGameRunning()).toBe(true);

            // Reset game
            gameEngine.reset();
            const resetState = gameEngine.getGameState();
            expect(resetState.score).toBe(0);
            expect(resetState.level).toBe(1);
            expect(resetState.lines).toBe(0);
            expect(resetState.isGameOver).toBe(false);
            expect(resetState.isPaused).toBe(false);
        });
    });

    describe('Input-Game Engine Integration', () => {
        test('should correctly handle keyboard input through input manager', () => {
            gameEngine.start();
            const initialPosition = gameEngine.getCurrentTetromino().x;

            // Mock keyboard events
            const leftKeyEvent = new KeyboardEvent('keydown', { code: 'ArrowLeft' });
            const rightKeyEvent = new KeyboardEvent('keydown', { code: 'ArrowRight' });
            const rotateKeyEvent = new KeyboardEvent('keydown', { code: 'ArrowUp' });

            // Simulate key presses
            inputManager.handleKeyDown(leftKeyEvent);
            expect(gameEngine.getCurrentTetromino().x).toBeLessThan(initialPosition);

            inputManager.handleKeyDown(rightKeyEvent);
            expect(gameEngine.getCurrentTetromino().x).toBe(initialPosition);

            const initialRotation = gameEngine.getCurrentTetromino().rotation;
            inputManager.handleKeyDown(rotateKeyEvent);
            // Rotation might not change if blocked, but method should be called
            expect(gameEngine.getCurrentTetromino().rotation).toBeGreaterThanOrEqual(0);
        });

        test('should handle touch input equivalently to keyboard input', () => {
            gameEngine.start();
            const initialPosition = gameEngine.getCurrentTetromino().x;

            // Test left swipe
            inputManager.touchStartPos = { x: 200, y: 300 };
            inputManager.touchCurrentPos = { x: 150, y: 300 };
            inputManager.processTouch(-50, 0, 50, 100);
            
            expect(gameEngine.getCurrentTetromino().x).toBeLessThan(initialPosition);

            // Test right swipe
            inputManager.touchStartPos = { x: 100, y: 300 };
            inputManager.touchCurrentPos = { x: 150, y: 300 };
            inputManager.processTouch(50, 0, 50, 100);
            
            expect(gameEngine.getCurrentTetromino().x).toBe(initialPosition);
        });

        test('should handle pause/resume through input manager', () => {
            gameEngine.start();
            expect(gameEngine.isGameRunning()).toBe(true);
            expect(gameEngine.isGamePaused()).toBe(false);

            // Test pause/resume directly through game engine
            gameEngine.pause();
            expect(gameEngine.isGamePaused()).toBe(true);

            gameEngine.resume();
            expect(gameEngine.isGamePaused()).toBe(false);
        });
    });

    describe('Renderer Integration', () => {
        test('should render game state correctly', () => {
            gameEngine.start();
            const renderer = gameEngine.getRenderer();
            
            expect(renderer).toBeTruthy();
            expect(typeof renderer.canRender).toBe('function');

            // Test rendering with current game state
            const renderData = {
                gameBoard: gameEngine.getGameBoard(),
                currentTetromino: gameEngine.getCurrentTetromino(),
                ghostTetromino: gameEngine.ghostTetromino,
                nextTetromino: gameEngine.getNextTetromino(),
                gameState: gameEngine.getGameState()
            };

            // Should not throw errors
            expect(() => {
                renderer.render(renderData);
            }).not.toThrow();

            expect(() => {
                renderer.renderWithAnimations(renderData);
            }).not.toThrow();
        });

        test('should handle animation states correctly', () => {
            gameEngine.start();
            const renderer = gameEngine.getRenderer();

            // Test line clear animation
            expect(gameEngine.isLineClearAnimationActive()).toBe(false);
            
            // Simulate line clear
            gameEngine.startLineClearAnimation([19]);
            expect(gameEngine.isLineClearAnimationActive()).toBe(true);
            expect(gameEngine.getAnimationProgress()).toBe(0);

            // Simulate animation completion
            gameEngine.finishLineClear();
            expect(gameEngine.isLineClearAnimationActive()).toBe(false);
        });
    });

    describe('Error Handling Integration', () => {
        test('should handle errors gracefully without crashing', () => {
            gameEngine.start();

            // Simulate various error conditions
            const originalConsoleError = console.error;
            console.error = jest.fn();

            // Test error in game loop
            const mockError = new Error('Test error');
            gameEngine.handleError(mockError, 'gameLoop');
            
            expect(console.error).toHaveBeenCalled();
            expect(gameEngine.getErrorStats().errorCount).toBe(1);

            // Test error recovery
            expect(gameEngine.isGameRunning()).toBe(true); // Should still be running

            console.error = originalConsoleError;
        });

        test('should stop game after too many errors', () => {
            gameEngine.start();
            
            const originalConsoleError = console.error;
            console.error = jest.fn();

            // Simulate many errors
            for (let i = 0; i < 15; i++) {
                gameEngine.handleError(new Error(`Test error ${i}`), 'test');
            }

            expect(gameEngine.isGameRunning()).toBe(false);
            expect(gameEngine.getErrorStats().errorCount).toBeGreaterThanOrEqual(10);

            console.error = originalConsoleError;
        });
    });

    describe('Performance and Memory', () => {
        test('should not leak memory during normal gameplay', () => {
            gameEngine.start();
            
            // Simulate extended gameplay
            for (let i = 0; i < 100; i++) {
                gameEngine.update(16); // 60 FPS
                gameEngine.render(Date.now());
            }

            // Check that game state is still consistent
            expect(gameEngine.getCurrentTetromino()).toBeTruthy();
            expect(gameEngine.getNextTetromino()).toBeTruthy();
            expect(gameEngine.getGameBoard()).toBeTruthy();
        });

        test('should handle rapid input without performance degradation', () => {
            gameEngine.start();
            const startTime = Date.now();

            // Simulate rapid input
            for (let i = 0; i < 1000; i++) {
                gameEngine.moveLeft();
                gameEngine.moveRight();
                gameEngine.rotate();
            }

            const endTime = Date.now();
            const duration = endTime - startTime;

            // Should complete within reasonable time (less than 1 second)
            expect(duration).toBeLessThan(1000);
            expect(gameEngine.getCurrentTetromino()).toBeTruthy();
        });
    });

    describe('Cross-Component Data Flow', () => {
        test('should maintain data consistency across all components', () => {
            gameEngine.start();
            
            const gameState = gameEngine.getGameState();
            const gameBoard = gameEngine.getGameBoard();
            const currentTetromino = gameEngine.getCurrentTetromino();
            const nextTetromino = gameEngine.getNextTetromino();

            // Verify all components have consistent data
            expect(gameState.currentTetromino).toBe(currentTetromino);
            expect(gameState.nextTetromino).toBe(nextTetromino);
            expect(gameState.board).toEqual(gameBoard.getBoard());

            // Make changes and verify consistency
            gameEngine.moveLeft();
            const newGameState = gameEngine.getGameState();
            expect(newGameState.currentTetromino).toBe(gameEngine.getCurrentTetromino());
        });

        test('should properly coordinate between game engine and renderer', () => {
            gameEngine.start();
            const renderer = gameEngine.getRenderer();

            // Verify renderer has access to all necessary data
            const renderData = {
                gameBoard: gameEngine.getGameBoard(),
                currentTetromino: gameEngine.getCurrentTetromino(),
                ghostTetromino: gameEngine.ghostTetromino,
                nextTetromino: gameEngine.getNextTetromino(),
                gameState: gameEngine.getGameState()
            };

            expect(renderData.gameBoard).toBeTruthy();
            expect(renderData.currentTetromino).toBeTruthy();
            expect(renderData.nextTetromino).toBeTruthy();
            expect(renderData.gameState).toBeTruthy();

            // Test that renderer can handle the data
            expect(() => {
                renderer.updateUI(renderData.gameState);
            }).not.toThrow();
        });
    });

    describe('Game State Transitions', () => {
        test('should handle all game state transitions correctly', () => {
            // Initial state
            expect(gameEngine.isGameRunning()).toBe(false);
            expect(gameEngine.isGamePaused()).toBe(false);
            expect(gameEngine.isGameOver()).toBe(false);

            // Start game
            gameEngine.start();
            expect(gameEngine.isGameRunning()).toBe(true);
            expect(gameEngine.isGamePaused()).toBe(false);
            expect(gameEngine.isGameOver()).toBe(false);

            // Pause game
            gameEngine.pause();
            expect(gameEngine.isGameRunning()).toBe(true);
            expect(gameEngine.isGamePaused()).toBe(true);
            expect(gameEngine.isGameOver()).toBe(false);

            // Resume game
            gameEngine.resume();
            expect(gameEngine.isGameRunning()).toBe(true);
            expect(gameEngine.isGamePaused()).toBe(false);
            expect(gameEngine.isGameOver()).toBe(false);

            // Trigger game over
            const gameBoard = gameEngine.getGameBoard();
            for (let y = 0; y < 20; y++) {
                for (let x = 0; x < 10; x++) {
                    gameBoard.setCell(x, y, '#FF0000');
                }
            }
            gameEngine.spawnNewTetromino();
            gameEngine.checkGameOver();

            expect(gameEngine.isGameRunning()).toBe(false);
            expect(gameEngine.isGamePaused()).toBe(false);
            expect(gameEngine.isGameOver()).toBe(true);

            // Reset game
            gameEngine.reset();
            expect(gameEngine.isGameRunning()).toBe(false);
            expect(gameEngine.isGamePaused()).toBe(false);
            expect(gameEngine.isGameOver()).toBe(false);
        });
    });
});