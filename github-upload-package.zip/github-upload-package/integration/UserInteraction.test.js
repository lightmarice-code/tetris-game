/**
 * Integration tests for user interaction flows
 * Tests complete user scenarios and interaction patterns
 */

import { GameEngine } from '../../src/core/GameEngine.js';
import { InputManager } from '../../src/core/InputManager.js';
import { GameConfig } from '../../src/config/GameConfig.js';

// Mock DOM elements
const createMockCanvas = () => ({
    getContext: jest.fn(() => ({
        clearRect: jest.fn(),
        fillRect: jest.fn(),
        strokeRect: jest.fn(),
        fillText: jest.fn(),
        save: jest.fn(),
        restore: jest.fn(),
        beginPath: jest.fn(),
        moveTo: jest.fn(),
        lineTo: jest.fn(),
        stroke: jest.fn(),
        arc: jest.fn()
    })),
    width: 300,
    height: 600,
    style: {},
    getBoundingClientRect: () => ({
        left: 0,
        top: 0,
        width: 300,
        height: 600
    }),
    addEventListener: jest.fn(),
    removeEventListener: jest.fn()
});

const createMockNextPieceCanvas = () => ({
    getContext: jest.fn(() => ({
        clearRect: jest.fn(),
        fillRect: jest.fn(),
        strokeRect: jest.fn(),
        save: jest.fn(),
        restore: jest.fn()
    })),
    width: 80,
    height: 80
});

// Setup DOM mocks
beforeAll(() => {
    global.document = {
        getElementById: jest.fn((id) => {
            if (id === 'nextPieceCanvas') {
                return createMockNextPieceCanvas();
            }
            return null;
        }),
        addEventListener: jest.fn(),
        removeEventListener: jest.fn(),
        querySelectorAll: jest.fn(() => []),
        createElement: jest.fn(() => ({
            style: {},
            classList: {
                add: jest.fn(),
                remove: jest.fn()
            },
            appendChild: jest.fn()
        }))
    };
    
    global.window = {
        addEventListener: jest.fn(),
        removeEventListener: jest.fn(),
        requestAnimationFrame: jest.fn(cb => setTimeout(cb, 16)),
        cancelAnimationFrame: jest.fn(),
        performance: {
            now: jest.fn(() => Date.now())
        },
        devicePixelRatio: 1,
        innerWidth: 1024,
        innerHeight: 768,
        matchMedia: jest.fn(() => ({
            addListener: jest.fn()
        }))
    };
});

describe('User Interaction Integration Tests', () => {
    let gameEngine;
    let inputManager;
    let mockCanvas;
    let config;

    beforeEach(() => {
        jest.clearAllMocks();
        mockCanvas = createMockCanvas();
        config = new GameConfig();
        gameEngine = new GameEngine(mockCanvas, config);
        inputManager = new InputManager(gameEngine);
    });

    afterEach(() => {
        if (inputManager) {
            inputManager.destroy();
        }
    });

    describe('Typical User Game Session', () => {
        test('should handle a typical beginner game session', () => {
            // Start game
            gameEngine.start();
            expect(gameEngine.isGameRunning()).toBe(true);

            // Beginner typically makes basic moves
            const initialX = gameEngine.getCurrentTetromino().x;
            
            // Move left a few times
            gameEngine.moveLeft();
            gameEngine.moveLeft();
            expect(gameEngine.getCurrentTetromino().x).toBeLessThan(initialX);

            // Try to rotate
            const initialRotation = gameEngine.getCurrentTetromino().rotation;
            gameEngine.rotate();
            // Rotation may or may not succeed depending on position

            // Let piece drop naturally by updating game
            for (let i = 0; i < 100; i++) {
                gameEngine.update(config.dropInterval + 10);
            }

            // Should have spawned new pieces
            expect(gameEngine.getCurrentTetromino()).toBeTruthy();
            expect(gameEngine.getNextTetromino()).toBeTruthy();
        });

        test('should handle an experienced player session with rapid inputs', () => {
            gameEngine.start();
            
            // Experienced player makes rapid, precise movements
            const moves = [
                () => gameEngine.moveLeft(),
                () => gameEngine.moveLeft(),
                () => gameEngine.rotate(),
                () => gameEngine.moveRight(),
                () => gameEngine.hardDrop(),
                () => gameEngine.moveRight(),
                () => gameEngine.rotate(),
                () => gameEngine.hardDrop()
            ];

            // Execute moves rapidly
            moves.forEach((move, index) => {
                setTimeout(move, index * 10);
            });

            // Wait for all moves to complete
            setTimeout(() => {
                expect(gameEngine.isGameRunning()).toBe(true);
                expect(gameEngine.getCurrentTetromino()).toBeTruthy();
            }, 100);
        });

        test('should handle pause/resume during active gameplay', () => {
            gameEngine.start();
            
            // Play for a bit
            gameEngine.moveLeft();
            gameEngine.rotate();
            gameEngine.update(100);

            const stateBeforePause = {
                score: gameEngine.getGameState().score,
                level: gameEngine.getGameState().level,
                tetrominoPosition: {
                    x: gameEngine.getCurrentTetromino().x,
                    y: gameEngine.getCurrentTetromino().y
                }
            };

            // Pause game
            gameEngine.pause();
            expect(gameEngine.isGamePaused()).toBe(true);

            // Try to make moves while paused (should not work)
            gameEngine.moveLeft();
            gameEngine.rotate();
            gameEngine.update(100);

            // State should be unchanged
            expect(gameEngine.getGameState().score).toBe(stateBeforePause.score);
            expect(gameEngine.getCurrentTetromino().x).toBe(stateBeforePause.tetrominoPosition.x);

            // Resume and continue playing
            gameEngine.resume();
            expect(gameEngine.isGamePaused()).toBe(false);
            
            gameEngine.moveRight();
            expect(gameEngine.getCurrentTetromino().x).toBeGreaterThan(stateBeforePause.tetrominoPosition.x);
        });
    });

    describe('Input Sequence Testing', () => {
        test('should handle complex input sequences correctly', () => {
            gameEngine.start();
            
            // Complex sequence: move, rotate, move, drop
            const initialState = {
                x: gameEngine.getCurrentTetromino().x,
                y: gameEngine.getCurrentTetromino().y,
                rotation: gameEngine.getCurrentTetromino().rotation
            };

            // Execute sequence
            gameEngine.moveLeft();
            gameEngine.moveLeft();
            gameEngine.rotate();
            gameEngine.moveRight();
            const dropDistance = gameEngine.hardDrop();

            // Verify sequence was executed
            expect(dropDistance).toBeGreaterThan(0);
            // New piece should have spawned
            expect(gameEngine.getCurrentTetromino()).toBeTruthy();
            expect(gameEngine.getCurrentTetromino().y).toBeLessThan(initialState.y + dropDistance);
        });

        test('should handle input debouncing correctly', () => {
            gameEngine.start();
            const initialX = gameEngine.getCurrentTetromino().x;

            // Rapid repeated inputs (should be debounced)
            for (let i = 0; i < 10; i++) {
                gameEngine.moveLeft();
            }

            // Should not have moved 10 times due to debouncing
            expect(gameEngine.getCurrentTetromino().x).toBeGreaterThan(initialX - 10);
        });

        test('should handle simultaneous input types', () => {
            gameEngine.start();
            
            // Simulate keyboard and touch inputs happening close together
            const keyboardResult = gameEngine.moveLeft();
            const touchResult = gameEngine.moveRight();

            // Both should be processed
            expect(typeof keyboardResult).toBe('boolean');
            expect(typeof touchResult).toBe('boolean');
        });
    });

    describe('Game Progression Scenarios', () => {
        test('should handle level progression correctly', () => {
            gameEngine.start();
            const initialLevel = gameEngine.getGameState().level;
            const initialDropInterval = gameEngine.gameState.getDropInterval();

            // Simulate clearing enough lines to level up
            const gameState = gameEngine.gameState;
            gameState.lines = 10; // Trigger level up
            gameState.updateLevel();

            expect(gameEngine.getGameState().level).toBeGreaterThan(initialLevel);
            expect(gameEngine.gameState.getDropInterval()).toBeLessThan(initialDropInterval);
        });

        test('should handle scoring progression', () => {
            gameEngine.start();
            const initialScore = gameEngine.getGameState().score;

            // Simulate line clears
            gameEngine.gameState.updateScore(1); // Single line
            expect(gameEngine.getGameState().score).toBeGreaterThan(initialScore);

            const scoreAfterSingle = gameEngine.getGameState().score;
            gameEngine.gameState.updateScore(4); // Tetris
            expect(gameEngine.getGameState().score).toBeGreaterThan(scoreAfterSingle);
        });

        test('should handle game over scenario gracefully', () => {
            gameEngine.start();
            
            // Fill the board to trigger game over
            const gameBoard = gameEngine.getGameBoard();
            for (let y = 0; y < 5; y++) {
                for (let x = 0; x < 10; x++) {
                    gameBoard.setCell(x, y, '#FF0000');
                }
            }

            // Try to spawn new piece (should trigger game over)
            gameEngine.spawnNewTetromino();
            gameEngine.checkGameOver();

            expect(gameEngine.isGameOver()).toBe(true);
            expect(gameEngine.isGameRunning()).toBe(false);

            // Inputs should not work when game is over
            const result = gameEngine.moveLeft();
            expect(result).toBe(false);
        });
    });

    describe('Touch Input Integration', () => {
        test('should handle touch gestures correctly', () => {
            gameEngine.start();
            const initialX = gameEngine.getCurrentTetromino().x;

            // Simulate touch swipe left
            inputManager.touchStartPos = { x: 200, y: 300 };
            inputManager.touchCurrentPos = { x: 150, y: 300 };
            inputManager.processTouch(-50, 0, 50, 100);

            expect(gameEngine.getCurrentTetromino().x).toBeLessThan(initialX);

            // Simulate tap for rotation
            inputManager.touchStartPos = { x: 150, y: 100 };
            inputManager.touchCurrentPos = { x: 150, y: 100 };
            inputManager.processTouch(0, 0, 5, 100);

            // Rotation should have been attempted
            expect(gameEngine.getCurrentTetromino()).toBeTruthy();
        });

        test('should handle touch zone detection', () => {
            gameEngine.start();
            
            // Test different touch zones
            const leftZone = { x: 50, y: 300 };
            const rightZone = { x: 250, y: 300 };
            const centerZone = { x: 150, y: 300 };

            expect(inputManager.isInZone(leftZone, inputManager.touchZones.leftZone)).toBe(true);
            expect(inputManager.isInZone(rightZone, inputManager.touchZones.rightZone)).toBe(true);
            expect(inputManager.isInZone(centerZone, inputManager.touchZones.centerZone)).toBe(true);
        });
    });

    describe('Error Recovery Scenarios', () => {
        test('should recover from temporary errors', () => {
            gameEngine.start();
            
            // Simulate recoverable error
            const originalConsoleError = console.error;
            console.error = jest.fn();

            gameEngine.handleError(new Error('Temporary error'), 'render');
            
            // Game should still be running
            expect(gameEngine.isGameRunning()).toBe(true);
            expect(gameEngine.getErrorStats().errorCount).toBe(1);

            // Should be able to continue playing
            const result = gameEngine.moveLeft();
            expect(typeof result).toBe('boolean');

            console.error = originalConsoleError;
        });

        test('should handle input manager errors gracefully', () => {
            gameEngine.start();
            
            // Simulate input error
            const originalHandleInput = inputManager.handleInput;
            inputManager.handleInput = jest.fn(() => {
                throw new Error('Input error');
            });

            // Should not crash the game (wrap in try-catch to handle the error)
            let errorThrown = false;
            try {
                inputManager.executeAction('moveLeft');
            } catch (error) {
                errorThrown = true;
            }
            
            // The error should be thrown but caught, not crash the game
            expect(errorThrown).toBe(true);

            inputManager.handleInput = originalHandleInput;
        });
    });

    describe('Performance Under Load', () => {
        test('should maintain performance with rapid input', () => {
            gameEngine.start();
            const startTime = Date.now();

            // Simulate rapid input for 100ms
            const endTime = startTime + 100;
            let inputCount = 0;

            while (Date.now() < endTime) {
                gameEngine.moveLeft();
                gameEngine.moveRight();
                gameEngine.rotate();
                inputCount += 3;
            }

            const actualDuration = Date.now() - startTime;
            
            // Should handle at least 100 inputs per second
            expect(inputCount / (actualDuration / 1000)).toBeGreaterThan(100);
            expect(gameEngine.isGameRunning()).toBe(true);
        });

        test('should handle continuous gameplay without degradation', () => {
            gameEngine.start();
            
            // Simulate 1000 game updates (about 16 seconds at 60fps)
            for (let i = 0; i < 1000; i++) {
                gameEngine.update(16);
                
                // Occasionally make moves
                if (i % 10 === 0) {
                    gameEngine.moveLeft();
                }
                if (i % 15 === 0) {
                    gameEngine.rotate();
                }
            }

            // Game should still be functional
            expect(gameEngine.isGameRunning()).toBe(true);
            expect(gameEngine.getCurrentTetromino()).toBeTruthy();
            expect(gameEngine.getNextTetromino()).toBeTruthy();
        });
    });

    describe('Multi-Component Coordination', () => {
        test('should coordinate input, game logic, and rendering', () => {
            gameEngine.start();
            const renderer = gameEngine.getRenderer();

            // Make input
            gameEngine.moveLeft();
            
            // Update game logic
            gameEngine.update(16);
            
            // Render
            const renderData = {
                gameBoard: gameEngine.getGameBoard(),
                currentTetromino: gameEngine.getCurrentTetromino(),
                ghostTetromino: gameEngine.ghostTetromino,
                nextTetromino: gameEngine.getNextTetromino(),
                gameState: gameEngine.getGameState()
            };

            expect(() => {
                renderer.render(renderData);
            }).not.toThrow();

            // All components should have consistent state
            expect(renderData.currentTetromino).toBe(gameEngine.getCurrentTetromino());
            expect(renderData.gameState.score).toBe(gameEngine.getGameState().score);
        });

        test('should handle component initialization order', () => {
            // Test different initialization orders
            const canvas1 = createMockCanvas();
            const engine1 = new GameEngine(canvas1, new GameConfig());
            const input1 = new InputManager(engine1);

            expect(engine1.isGameRunning()).toBe(false);
            expect(input1.gameEngine).toBe(engine1);

            // Should work regardless of order
            engine1.start();
            expect(engine1.isGameRunning()).toBe(true);

            input1.destroy();
        });
    });
});